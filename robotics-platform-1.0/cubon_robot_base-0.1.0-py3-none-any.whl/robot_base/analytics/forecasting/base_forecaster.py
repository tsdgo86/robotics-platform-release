"""
Base Forecaster — Time-Series Capacity/Demand Forecasting
================================================================
Interface cho khả năng "Predict" trong hệ D2 (Predict-Detect-Simulate --
xem `docs/robotis_implementation/implementation_plan_v2` mục D2): dự
báo logistics capacity/demand từ chuỗi lịch sử.

`ExponentialSmoothingForecaster` là reference implementation
dependency-free (Holt's linear trend / double exponential smoothing --
thuật toán forecasting cổ điển, không cần statsmodels/Prophet) -- đủ để
test toàn bộ pipeline Predict-Detect-Simulate end-to-end. Prophet/LSTM
thật (tech stack D2 đề xuất) sẽ implement lại BaseForecaster trong một
môi trường có torch/prophet, không phải trong robot_base core.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional

logger = logging.getLogger(__name__)


@dataclass
class ForecastResult:
    horizon: int
    values: List[float]
    method: str


class BaseForecaster(ABC):
    """Interface for time-series forecasting."""

    @abstractmethod
    def fit(self, series: List[float]) -> None:
        """Fit the model on historical observations, in chronological order."""
        pass

    @abstractmethod
    def predict(self, horizon: int) -> ForecastResult:
        """Forecast `horizon` future steps beyond the fitted series."""
        pass


class ExponentialSmoothingForecaster(BaseForecaster):
    """
    Holt's linear trend method (double exponential smoothing):

        level_t = alpha * y_t + (1 - alpha) * (level_{t-1} + trend_{t-1})
        trend_t = beta * (level_t - level_{t-1}) + (1 - beta) * trend_{t-1}
        forecast(h) = level_T + h * trend_T

    alpha: level smoothing factor (0, 1]. beta: trend smoothing factor (0, 1].
    """

    def __init__(self, alpha: float = 0.5, beta: float = 0.3) -> None:
        if not (0.0 < alpha <= 1.0):
            raise ValueError("alpha must be in (0, 1]")
        if not (0.0 < beta <= 1.0):
            raise ValueError("beta must be in (0, 1]")
        self._alpha = alpha
        self._beta = beta
        self._level: Optional[float] = None
        self._trend: Optional[float] = None
        self._fitted = False

    def fit(self, series: List[float]) -> None:
        if len(series) < 2:
            raise ValueError("ExponentialSmoothingForecaster needs at least 2 observations to fit")
        level = series[0]
        trend = series[1] - series[0]
        for y in series[1:]:
            prev_level = level
            level = self._alpha * y + (1 - self._alpha) * (level + trend)
            trend = self._beta * (level - prev_level) + (1 - self._beta) * trend
        self._level = level
        self._trend = trend
        self._fitted = True
        logger.info(f"[ExponentialSmoothingForecaster] Fitted: level={level:.3f} trend={trend:.3f}")

    def predict(self, horizon: int) -> ForecastResult:
        if not self._fitted:
            raise RuntimeError("fit() must be called before predict()")
        if horizon < 1:
            raise ValueError("horizon must be >= 1")
        values = [self._level + h * self._trend for h in range(1, horizon + 1)]
        return ForecastResult(horizon=horizon, values=values, method="exponential_smoothing")
