"""
Bottleneck Detector — Capacity vs. Forecasted Demand
==========================================================
Khả năng "Detect" trong D2 (xem
`docs/robotis_implementation/implementation_plan_v2` mục D2): so sánh
forecast (từ BaseForecaster) với capacity đã biết, gắn cờ các bước thời
gian nghẽn (bottleneck) và đề xuất hành động thô -- input cho
LogisticsAdvisor cùng kết quả simulate.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import List

from robot_base.analytics.forecasting.base_forecaster import ForecastResult

logger = logging.getLogger(__name__)

DEFAULT_WARN_UTILIZATION_PCT = 85.0


@dataclass
class BottleneckReport:
    capacity: float
    breaches: List[int] = field(default_factory=list)  # 1-based forecast steps where demand > capacity
    peak_demand: float = 0.0
    peak_step: int = 0
    utilization_pct: List[float] = field(default_factory=list)

    @property
    def has_bottleneck(self) -> bool:
        return len(self.breaches) > 0


class BottleneckDetector:
    def __init__(self, capacity: float, warn_utilization_pct: float = DEFAULT_WARN_UTILIZATION_PCT) -> None:
        if capacity <= 0:
            raise ValueError("capacity must be > 0")
        self._capacity = capacity
        self._warn_utilization_pct = warn_utilization_pct

    def detect(self, forecast: ForecastResult) -> BottleneckReport:
        breaches: List[int] = []
        utilization: List[float] = []
        peak_demand = 0.0
        peak_step = 0
        for step, demand in enumerate(forecast.values, start=1):
            util_pct = (demand / self._capacity) * 100.0
            utilization.append(util_pct)
            if demand > peak_demand:
                peak_demand, peak_step = demand, step
            if demand > self._capacity:
                breaches.append(step)
                logger.warning(
                    f"[BottleneckDetector] step={step} demand={demand:.2f} > capacity={self._capacity}"
                )
        return BottleneckReport(
            capacity=self._capacity,
            breaches=breaches,
            peak_demand=peak_demand,
            peak_step=peak_step,
            utilization_pct=utilization,
        )

    def recommend_actions(self, report: BottleneckReport) -> List[str]:
        if report.has_bottleneck:
            return [
                f"ADD_CAPACITY: forecast exceeds capacity at step(s) {report.breaches} "
                f"(peak demand={report.peak_demand:.1f} at step {report.peak_step}, capacity={report.capacity})"
            ]
        if report.utilization_pct and max(report.utilization_pct) >= self._warn_utilization_pct:
            return [
                f"MONITOR: utilization reaches {max(report.utilization_pct):.1f}% "
                f"(warn threshold={self._warn_utilization_pct}%) -- no breach yet but approaching capacity"
            ]
        return ["NO_ACTION: forecasted demand stays within capacity"]
