"""robot_base.analytics -- forecasting, bottleneck detection, and cross-cutting advisory logic (D2)."""

from robot_base.analytics.bottleneck_detector import BottleneckDetector, BottleneckReport
from robot_base.analytics.logistics_advisor import LogisticsAdvisor, LogisticsAdvisoryReport

__all__ = [
    "BottleneckDetector",
    "BottleneckReport",
    "LogisticsAdvisor",
    "LogisticsAdvisoryReport",
]
