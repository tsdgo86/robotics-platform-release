"""
Logistics Advisor — Predict → Detect → Simulate → Recommend (D2)
======================================================================
Top-level orchestration cho D2 (xem
`docs/robotis_implementation/implementation_plan_v2` mục D2): "Build a
system with three capabilities: Predict logistics capacity, Detect
bottlenecks, and Simulate what-if scenarios to recommend actions."

Ghép `BaseForecaster` (Predict) + `BottleneckDetector` (Detect) +
`DiscreteEventLogisticsSimulator` (Simulate) thành một report duy nhất
-- khớp với deliverable "Predict–Detect–Simulate system" và là nguồn dữ
liệu cho "Control Room dashboard" (D2).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import List, Optional

from robot_base.analytics.bottleneck_detector import BottleneckDetector, BottleneckReport
from robot_base.analytics.forecasting.base_forecaster import BaseForecaster
from robot_base.simulation.logistics_simulator import (
    DiscreteEventLogisticsSimulator,
    SimulationResult,
    StationSpec,
)

logger = logging.getLogger(__name__)


@dataclass
class LogisticsAdvisoryReport:
    bottleneck: BottleneckReport
    baseline_simulation: SimulationResult
    scenario_simulations: List[SimulationResult] = field(default_factory=list)
    recommended_actions: List[str] = field(default_factory=list)


class LogisticsAdvisor:
    def __init__(
        self,
        forecaster: BaseForecaster,
        detector: BottleneckDetector,
        simulator: DiscreteEventLogisticsSimulator,
    ) -> None:
        self._forecaster = forecaster
        self._detector = detector
        self._simulator = simulator

    def analyze(
        self,
        historical_demand: List[float],
        horizon: int,
        num_items: int,
        arrival_interval_s: float,
        what_if_stations: Optional[List[List[StationSpec]]] = None,
    ) -> LogisticsAdvisoryReport:
        # 1. Predict
        self._forecaster.fit(historical_demand)
        forecast = self._forecaster.predict(horizon)

        # 2. Detect
        bottleneck = self._detector.detect(forecast)
        actions = self._detector.recommend_actions(bottleneck)

        # 3. Simulate (baseline + optional what-if scenarios)
        baseline_sim = self._simulator.run(num_items, arrival_interval_s, scenario_name="baseline")

        scenario_sims: List[SimulationResult] = []
        for i, stations in enumerate(what_if_stations or []):
            scenario_sim = DiscreteEventLogisticsSimulator(stations).run(
                num_items, arrival_interval_s, scenario_name=f"what_if_{i + 1}"
            )
            scenario_sims.append(scenario_sim)
            if scenario_sim.throughput_items_per_hour > baseline_sim.throughput_items_per_hour:
                actions.append(
                    f"CONSIDER {scenario_sim.scenario_name}: throughput "
                    f"{scenario_sim.throughput_items_per_hour:.1f}/hr vs baseline "
                    f"{baseline_sim.throughput_items_per_hour:.1f}/hr"
                )

        return LogisticsAdvisoryReport(
            bottleneck=bottleneck,
            baseline_simulation=baseline_sim,
            scenario_simulations=scenario_sims,
            recommended_actions=actions,
        )
