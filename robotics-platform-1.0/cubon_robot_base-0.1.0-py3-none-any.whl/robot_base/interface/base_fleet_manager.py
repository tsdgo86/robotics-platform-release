from abc import ABC, abstractmethod
from typing import List
from robot_base.core.base_task import BaseTask


class BaseFleetManager(ABC):
    """Fleet management interface."""

    @abstractmethod
    async def get_available_robots(self) -> List[str]:
        pass

    @abstractmethod
    async def assign_task(self, robot_id: str, task: BaseTask) -> bool:
        pass

    @abstractmethod
    async def update_robot_status(self, robot_id: str, status: str) -> None:
        pass
