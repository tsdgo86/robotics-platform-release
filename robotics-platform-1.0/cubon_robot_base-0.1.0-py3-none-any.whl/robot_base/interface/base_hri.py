from abc import ABC, abstractmethod
from robot_base.core.base_task import BaseTask


class BaseHRI(ABC):
    """Human-Robot Interaction -- voice, gesture, text, teleop."""

    @abstractmethod
    async def parse_command(self, raw_input: str) -> BaseTask:
        pass

    @abstractmethod
    async def request_confirmation(self, task: BaseTask) -> bool:
        pass

    @abstractmethod
    async def handle_stop_command(self) -> None:
        pass
