"""
Dynamic package/package_dir mapping for robot_base.

This pyproject.toml lives inside the package directory itself (robot_base/core,
robot_base/safety, ... are siblings of this file), instead of the conventional
nested <project-root>/robot_base/ layout that setuptools/poetry package
discovery assumes. Rather than moving ~100 files into a nested directory,
this maps each real subpackage found in "." onto the "robot_base.*" import
name -- a prefix mapping pyproject.toml's declarative packages.find cannot
express on its own.
"""
from setuptools import setup, find_packages

_subpackages = find_packages(where=".", exclude=["tests", "tests.*"])

setup(
    packages=["robot_base"] + [f"robot_base.{name}" for name in _subpackages],
    package_dir={
        "robot_base": ".",
        **{f"robot_base.{name}": name.replace(".", "/") for name in _subpackages},
    },
)
