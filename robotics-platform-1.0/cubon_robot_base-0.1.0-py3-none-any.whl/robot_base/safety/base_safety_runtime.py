from abc import ABC, abstractmethod
from typing import Any


class BaseSafetyRuntime(ABC):
    """Interface for safety runtime -- mandatory for all robots."""

    @abstractmethod
    async def check_emergency_stop(self) -> bool:
        pass

    @abstractmethod
    async def check_collision_risk(self, world_state: Any) -> bool:
        pass

    @abstractmethod
    async def check_force_limits(self, sensor_data: Any) -> bool:
        pass

    @abstractmethod
    async def approve_action(self, task_or_command: Any) -> bool:
        """Gatekeeper -- reject action if unsafe."""
        pass

    @abstractmethod
    async def trigger_safe_stop(self, reason: str) -> None:
        pass
