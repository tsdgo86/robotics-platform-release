"""
Watchdog Monitor — Heartbeat / Liveness Supervision
=====================================================
Giám sát heartbeat của các thành phần runtime (control loop, perception
node, comms bridge, dynamixel adapter, ...). Nếu một component không
"beat" trong khoảng timeout cấu hình, watchdog coi đó là treo / mất kết
nối và escalate qua callback `on_timeout` -- thường là
`BaseSafetyRuntime.trigger_safe_stop()` của robot cụ thể.

Độc lập với AI Agent / Orchestrator và với logic an toàn khác: watchdog
không quan tâm nội dung task, chỉ quan tâm "component còn sống hay
không". Đây là lý do nó nằm cạnh HumanZoneChecker -- một module an toàn
độc lập khác được các *SafetyRuntime cụ thể (Arm/Humanoid) compose vào,
chứ không kế thừa BaseSafetyRuntime.

Checklist mapping: H-030 (watchdog), A-031..A-038 (arm watchdog/safety
timeout chain).
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional, Union

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT_S = 1.0
DEFAULT_CHECK_INTERVAL_S = 0.1

# Callback invoked when a component goes stale: (name, seconds_since_last_beat).
# May be sync or async -- run() awaits it if it returns a coroutine.
OnTimeoutCallback = Callable[[str, float], Union[None, Awaitable[None]]]


@dataclass
class WatchdogConfig:
    default_timeout_s: float = DEFAULT_TIMEOUT_S
    check_interval_s: float = DEFAULT_CHECK_INTERVAL_S


@dataclass
class ComponentHeartbeat:
    name: str
    timeout_s: float
    last_beat_time: float = field(default_factory=time.time)
    missed_count: int = 0
    timed_out: bool = False


class WatchdogMonitor:
    """
    Tracks liveness of named components via heartbeat() calls.

    Usage
    -----
    watchdog = WatchdogMonitor(on_timeout=safety_runtime.trigger_safe_stop)
    watchdog.register_component("perception_loop", timeout_s=0.5)
    ...
    watchdog.heartbeat("perception_loop")   # called every tick by the loop
    ...
    asyncio.create_task(watchdog.run())     # background staleness sweep
    """

    def __init__(
        self,
        config: Optional[WatchdogConfig] = None,
        on_timeout: Optional[OnTimeoutCallback] = None,
    ) -> None:
        self._config = config or WatchdogConfig()
        self._on_timeout = on_timeout
        self._components: Dict[str, ComponentHeartbeat] = {}
        self._timeout_log: List[Dict[str, Any]] = []

    # ── Registration ──────────────────────────────────────────────────────────

    def register_component(self, name: str, timeout_s: Optional[float] = None) -> None:
        self._components[name] = ComponentHeartbeat(
            name=name,
            timeout_s=timeout_s if timeout_s is not None else self._config.default_timeout_s,
        )
        logger.info(
            f"[Watchdog] Registered component '{name}' "
            f"(timeout={self._components[name].timeout_s}s)"
        )

    def unregister_component(self, name: str) -> None:
        self._components.pop(name, None)

    # ── Heartbeat ─────────────────────────────────────────────────────────────

    def heartbeat(self, name: str) -> None:
        """Record a liveness beat for `name`. Auto-registers if unknown."""
        comp = self._components.get(name)
        if comp is None:
            self.register_component(name)
            comp = self._components[name]
        comp.last_beat_time = time.time()
        comp.missed_count = 0
        if comp.timed_out:
            logger.info(f"[Watchdog] Component '{name}' recovered")
        comp.timed_out = False

    # ── Staleness check ──────────────────────────────────────────────────────

    def check_once(self, now: Optional[float] = None) -> List[str]:
        """
        Synchronous staleness sweep -- returns names of components that
        newly went stale in this call (transition only, not repeated on
        every subsequent check while still stale).
        """
        now = now if now is not None else time.time()
        newly_timed_out: List[str] = []
        for comp in self._components.values():
            age = now - comp.last_beat_time
            if age > comp.timeout_s:
                comp.missed_count += 1
                if not comp.timed_out:
                    comp.timed_out = True
                    newly_timed_out.append(comp.name)
                    self._log_timeout(comp.name, age)
        return newly_timed_out

    async def run(self) -> None:
        """Background polling loop. Call heartbeat() from other tasks."""
        try:
            while True:
                stale = self.check_once()
                for name in stale:
                    comp = self._components[name]
                    age = time.time() - comp.last_beat_time
                    await self._escalate(name, age)
                await asyncio.sleep(self._config.check_interval_s)
        except asyncio.CancelledError:
            pass

    async def _escalate(self, name: str, age_s: float) -> None:
        logger.warning(f"[Watchdog] TIMEOUT component='{name}' age={age_s:.2f}s")
        if self._on_timeout is None:
            return
        result = self._on_timeout(name, age_s)
        if asyncio.iscoroutine(result):
            await result

    # ── Diagnostics ───────────────────────────────────────────────────────────

    def _log_timeout(self, name: str, age_s: float) -> None:
        entry = {"time": time.time(), "component": name, "age_s": age_s}
        self._timeout_log.append(entry)
        if len(self._timeout_log) > 200:
            self._timeout_log.pop(0)

    def get_status(self) -> Dict[str, Any]:
        now = time.time()
        return {
            "components": {
                name: {
                    "timed_out": c.timed_out,
                    "missed_count": c.missed_count,
                    "last_beat_age_s": now - c.last_beat_time,
                    "timeout_s": c.timeout_s,
                }
                for name, c in self._components.items()
            },
            "timeouts_total": len(self._timeout_log),
            "last_timeout": self._timeout_log[-1] if self._timeout_log else None,
        }
