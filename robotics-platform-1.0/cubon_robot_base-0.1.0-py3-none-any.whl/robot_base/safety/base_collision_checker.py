from abc import ABC, abstractmethod
from typing import Any


class BaseCollisionChecker(ABC):
    """Interface for collision checking in motion planning."""

    @abstractmethod
    async def validate_collision_free(self, trajectory: Any) -> bool:
        pass
