"""
Humanoid Safety Runtime — Independent Safety Layer for Humanoid Robots
========================================================================
Lớp an toàn độc lập hoàn toàn với AI Agent, tương đương ArmSafetyValidator
nhưng cho Humanoid: cân bằng/tư thế, vùng người, joint/velocity/torque
limits, pin & nhiệt.

AI KHÔNG được phép bypass Safety Runtime.
Mọi skill/action request phải qua approve_skill() (hoặc approve_action())
trước khi executor được gọi.

Checks thực hiện:
1. Emergency stop state
2. Balance / tilt (fall risk) -- từ IMU trong sensor_data
3. Human zone (alert/stop tier qua HumanZoneChecker) + restricted zones
4. Path clear trước khi di chuyển (NAVIGATE_TO)
5. Joint position limits (toàn thân)
6. Velocity limits
7. Joint torque limits
8. Battery / thermal low-power safe-shutdown
9. Self-collision hình học thật (capsule distance qua HumanoidCollisionChecker),
   CHỈ chạy khi sensor_data["joint_positions"] có đủ góc khớp -- cùng dict
   dùng cho check #5, feed thẳng qua forward kinematics (DEFAULT_HUMANOID_CHAIN)
   sang collision checker. Nếu thiếu góc khớp, bị coi là insufficient data
   (fail-closed), KHÔNG bỏ qua như đã pass.

Implements robot_base.safety.BaseSafetyRuntime.

Checklist mapping (docs/Checklist_Chuc_nang_Humanoid...xlsx):
H-008 joint limits, H-013 safe start/stop, H-030 watchdog (partial --
watchdog itself is a separate concern, see robot_base/core/lifecycle),
H-040 thermal, H-041 low-power/safe shutdown, H-042 e-stop, H-046
speed/force limits, H-047 collision/human detection, H-068 human override.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from robot_base.core.kinematics import KinematicChain, MissingJointAngleError, compute_joint_positions
from robot_base.core.humanoid_kinematic_chain import DEFAULT_HUMANOID_CHAIN
from robot_base.safety.base_safety_runtime import BaseSafetyRuntime
from robot_base.safety.humanoid_collision_checker import HumanoidCollisionChecker
from robot_base.safety.human_zone_checker import HumanZoneChecker

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Hard Safety Limits for Generic Humanoid
# (Conservative defaults, aligned with LimX Oli baseline in the checklist —
#  override via HumanoidSafetyConfig for the actual robot in use.)
# ─────────────────────────────────────────────────────────────────────────────

MAX_TILT_DEG          = 25.0   # deg    — roll/pitch beyond this = fall risk
MAX_JOINT_VELOCITY    = 3.14   # rad/s  — hard cap per joint
MAX_JOINT_TORQUE_NM   = 150.0  # N·m    — conservative per-joint cap (Oli: 150/250 N·m)
MIN_BATTERY_PCT       = 15.0   # %      — below this, reject new missions
CRITICAL_BATTERY_PCT  = 5.0    # %      — below this, force safe shutdown
MAX_TEMPERATURE_C     = 70.0   # °C     — compute/motor derate threshold

# Default 31-DoF joint layout (legs 6x2, arms 7x2, waist 3, neck 2),
# matching the lower baseline in checklist H-002 (Oli: 31/33/43 Active DoF).
DEFAULT_JOINT_LIMITS: Dict[str, Tuple[float, float]] = {
    **{f"left_{j}":  (-3.14, 3.14) for j in (
        "hip_pitch", "hip_roll", "hip_yaw", "knee", "ankle_pitch", "ankle_roll",
    )},
    **{f"right_{j}": (-3.14, 3.14) for j in (
        "hip_pitch", "hip_roll", "hip_yaw", "knee", "ankle_pitch", "ankle_roll",
    )},
    **{f"left_{j}":  (-3.14, 3.14) for j in (
        "shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow",
        "wrist_pitch", "wrist_roll", "wrist_yaw",
    )},
    **{f"right_{j}": (-3.14, 3.14) for j in (
        "shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow",
        "wrist_pitch", "wrist_roll", "wrist_yaw",
    )},
    "waist_pitch": (-0.79, 0.79),
    "waist_roll":  (-0.52, 0.52),
    "waist_yaw":   (-1.57, 1.57),
    "neck_pitch":  (-0.79, 0.79),
    "neck_yaw":    (-1.57, 1.57),
}


# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class HumanoidSafetyConfig:
    joint_limits:         Dict[str, Tuple[float, float]] = field(default_factory=lambda: dict(DEFAULT_JOINT_LIMITS))
    max_tilt_deg:         float = MAX_TILT_DEG
    max_joint_vel:        float = MAX_JOINT_VELOCITY
    max_joint_torque_nm:  float = MAX_JOINT_TORQUE_NM
    min_battery_pct:      float = MIN_BATTERY_PCT
    critical_battery_pct: float = CRITICAL_BATTERY_PCT
    max_temperature_c:    float = MAX_TEMPERATURE_C
    person_alert_m:       float = 1.5
    person_stop_m:        float = 0.8
    estop_active:         bool  = False


# ─────────────────────────────────────────────────────────────────────────────
# Humanoid Safety Runtime
# ─────────────────────────────────────────────────────────────────────────────

class HumanoidSafetyRuntime(BaseSafetyRuntime):
    """
    Full safety runtime for humanoid skills/actions.

    Two entry points:
    - approve_skill(request, context, definition): full pipeline used by
      factory_hacks.skills.runtime.SkillRuntime (duck-typed via
      SafetyValidatorProtocol -- request/context/definition are any
      objects exposing .params / .sensor_data / .world_state / .name).
    - approve_action(task_or_command): the generic single-arg entry point
      required by BaseSafetyRuntime.

    Convention for all check_* methods (BaseSafetyRuntime contract):
    return True means "no violation / safe to proceed".
    """

    def __init__(
        self,
        config: Optional[HumanoidSafetyConfig] = None,
        collision_checker: Optional[HumanoidCollisionChecker] = None,
        kinematic_chain: Optional[KinematicChain] = None,
    ) -> None:
        self._config          = config or HumanoidSafetyConfig()
        self._estop_active    = self._config.estop_active
        self._zone_checker    = HumanZoneChecker(
            person_alert_m=self._config.person_alert_m,
            person_stop_m=self._config.person_stop_m,
        )
        self._collision_checker = collision_checker or HumanoidCollisionChecker()
        self._kinematic_chain   = kinematic_chain or DEFAULT_HUMANOID_CHAIN
        self._violation_log:  List[Dict[str, Any]] = []
        self._last_safe_time: float = time.time()
        self._check_count:    int   = 0

    # ── Public: called by SkillRuntime (not by AI) ────────────────────────────

    async def approve_skill(
        self,
        request: Any,
        context: Any,
        definition: Any,
    ) -> Tuple[bool, List[str]]:
        """
        Gate function for SkillRuntime.
        Returns (approved, list_of_violations).
        """
        self._check_count += 1
        violations: List[str] = []

        sensor_data = context.sensor_data
        world_state = context.world_state

        # 1. Emergency stop -- always wins, checked first
        if self._estop_active:
            violations.append("ESTOP_ACTIVE")
            return False, violations

        # 2. Battery / thermal -- critical battery forces rejection outright
        violations.extend(self._check_power_thermal(sensor_data))

        # 3. Balance / tilt (fall risk)
        violations.extend(self._check_balance(sensor_data))

        # 4. Human zone -- stop-tier violation blocks motion skills
        zone_status = self._zone_checker.check(world_state)
        if zone_status.stop_triggered and definition.name in (
            "NAVIGATE_TO", "INSPECT_ZONE",
        ):
            violations.append("HUMAN_IN_STOP_ZONE")
        violations.extend(v for v in zone_status.violations if "RESTRICTED_ZONE" in v)

        # 5. Path clear (movement skills only)
        if definition.name == "NAVIGATE_TO" and not world_state.get("path_clear", True):
            violations.append("PATH_BLOCKED")

        # 6. Joint position limits
        violations.extend(self._check_joint_limits(sensor_data))

        # 7. Velocity limits
        violations.extend(self._check_velocity_limits(sensor_data))

        # 8. Joint torque limits
        violations.extend(self._check_torque_limits(sensor_data))

        # 9. Self-collision (geometric, via forward kinematics -- only if
        #    joint angles were supplied; see _check_self_collision)
        violations.extend(self._check_self_collision(sensor_data))

        if violations:
            for v in violations:
                self._log_violation(v, f"skill={request.skill_name} req={request.request_id}")
            return False, violations

        self._last_safe_time = time.time()
        return True, []

    # ── BaseSafetyRuntime interface ───────────────────────────────────────────

    async def check_emergency_stop(self) -> bool:
        """True when NOT emergency-stopped (safe to proceed)."""
        return not self._estop_active

    async def check_collision_risk(self, world_state: Any) -> bool:
        """
        True when no human-zone / restricted-zone violation detected. This
        is the flag/proximity-based check only -- the ABC signature takes
        world_state, not sensor_data, so it cannot also run the geometric
        self-collision check, which needs joint angles. See
        approve_skill()/approve_action(), which run both.
        """
        status = self._zone_checker.check(world_state)
        return not status.stop_triggered

    async def check_force_limits(self, sensor_data: Any) -> bool:
        """True when joint torque readings are within configured limits."""
        return len(self._check_torque_limits(sensor_data)) == 0

    async def approve_action(self, task_or_command: Any) -> bool:
        """
        Generic single-object entry point required by BaseSafetyRuntime.
        Prefer approve_skill() for full-pipeline validation with detailed
        violation reporting -- this is a reduced-info fallback for callers
        that only have a dict-like command payload with optional keys:
        sensor_data, world_state.
        """
        if self._estop_active:
            return False
        cmd = task_or_command if isinstance(task_or_command, dict) else {}
        sensor_data = cmd.get("sensor_data", {})
        world_state = cmd.get("world_state", {})

        violations: List[str] = []
        violations.extend(self._check_power_thermal(sensor_data))
        violations.extend(self._check_balance(sensor_data))
        violations.extend(self._check_joint_limits(sensor_data))
        violations.extend(self._check_velocity_limits(sensor_data))
        violations.extend(self._check_torque_limits(sensor_data))
        violations.extend(self._check_self_collision(sensor_data))
        zone_status = self._zone_checker.check(world_state)
        if zone_status.stop_triggered:
            violations.append("HUMAN_IN_STOP_ZONE")
        return len(violations) == 0

    async def trigger_safe_stop(self, reason: str) -> None:
        self.trigger_estop(reason)

    # ── Emergency Stop ────────────────────────────────────────────────────────

    def trigger_estop(self, reason: str = "") -> None:
        """Engage emergency stop. Humanoid will reject ALL further skill requests."""
        logger.warning(f"[HumanoidSafety] E-STOP triggered: {reason}")
        self._estop_active = True
        self._log_violation("ESTOP_TRIGGERED", reason)

    def clear_estop(self, reason: str = "") -> None:
        """Clear emergency stop after manual inspection/confirmation."""
        logger.info(f"[HumanoidSafety] E-STOP cleared: {reason}")
        self._estop_active = False

    def set_estop(self, active: bool) -> None:
        """Direct setter for tests / bridge."""
        self._estop_active = active

    # ── Individual Checks (operate on plain dicts) ────────────────────────────

    def _check_balance(self, sensor_data: Dict[str, Any]) -> List[str]:
        """Reject if IMU-reported tilt exceeds fall-risk threshold."""
        violations = []
        for axis_key in ("imu_roll_deg", "imu_pitch_deg"):
            val = sensor_data.get(axis_key)
            if val is not None and abs(float(val)) > self._config.max_tilt_deg:
                violations.append(
                    f"BALANCE_TILT {axis_key}={val:.1f} max={self._config.max_tilt_deg}"
                )
        if sensor_data.get("fall_detected"):
            violations.append("FALL_DETECTED")
        return violations

    def _check_power_thermal(self, sensor_data: Dict[str, Any]) -> List[str]:
        violations = []
        battery_pct = sensor_data.get("battery_soc_pct")
        if battery_pct is not None:
            if float(battery_pct) <= self._config.critical_battery_pct:
                violations.append(f"BATTERY_CRITICAL ({battery_pct:.1f}% <= {self._config.critical_battery_pct}%)")
            elif float(battery_pct) <= self._config.min_battery_pct:
                violations.append(f"BATTERY_LOW ({battery_pct:.1f}% <= {self._config.min_battery_pct}%)")

        temp_c = sensor_data.get("temperature_c")
        if temp_c is not None and float(temp_c) > self._config.max_temperature_c:
            violations.append(f"THERMAL_LIMIT ({temp_c:.1f}C > {self._config.max_temperature_c}C)")
        return violations

    def _check_joint_limits(self, sensor_data: Dict[str, Any]) -> List[str]:
        violations = []
        joint_positions = sensor_data.get("joint_positions", {})
        for joint_name, (lo, hi) in self._config.joint_limits.items():
            pos = joint_positions.get(joint_name)
            if pos is None:
                continue
            if not (lo <= pos <= hi):
                violations.append(
                    f"JOINT_LIMIT joint={joint_name} pos={pos:.3f} "
                    f"allowed=[{lo:.2f}, {hi:.2f}]"
                )
        return violations

    def _check_velocity_limits(self, sensor_data: Dict[str, Any]) -> List[str]:
        violations = []
        joint_velocities = sensor_data.get("joint_velocities", {})
        for joint_name, vel in joint_velocities.items():
            if abs(vel) > self._config.max_joint_vel:
                violations.append(
                    f"JOINT_VEL_LIMIT joint={joint_name} vel={vel:.2f} "
                    f"max={self._config.max_joint_vel}"
                )
        return violations

    def _check_torque_limits(self, sensor_data: Dict[str, Any]) -> List[str]:
        violations = []
        joint_torques = sensor_data.get("joint_torques", {})
        for joint_name, torque in joint_torques.items():
            if abs(torque) > self._config.max_joint_torque_nm:
                violations.append(
                    f"JOINT_TORQUE_LIMIT joint={joint_name} torque={torque:.1f}Nm "
                    f"max={self._config.max_joint_torque_nm}Nm"
                )
        return violations

    def _check_self_collision(self, sensor_data: Dict[str, Any]) -> List[str]:
        """
        Real geometric self-collision check via forward kinematics.

        No-op (empty list) when sensor_data has no joint_positions -- this
        augments the zone/flag-based checks, it doesn't replace them (those
        also cover human proximity and restricted zones, which FK/
        self-collision knows nothing about).

        Uses strict FK: if joint_positions is present but INCOMPLETE (some
        joints missing), that is reported as a violation rather than
        silently computing a self-collision check against a partially
        guessed (angle=0.0) pose -- a wrong pose could hide a real
        collision, which is unacceptable for a safety check.
        """
        joint_angles = sensor_data.get("joint_positions")
        if not joint_angles:
            return []
        try:
            link_positions = compute_joint_positions(
                self._kinematic_chain, joint_angles, strict=True
            )
        except MissingJointAngleError as e:
            return [f"COLLISION_CHECK_INCOMPLETE_POSE ({e})"]
        _, violations = self._collision_checker.check_pose(link_positions)
        return violations

    # ── Diagnostics ───────────────────────────────────────────────────────────

    def _log_violation(self, code: str, detail: str) -> None:
        entry = {"time": time.time(), "code": code, "detail": detail}
        self._violation_log.append(entry)
        if len(self._violation_log) > 200:
            self._violation_log.pop(0)
        logger.warning(f"[HumanoidSafety] [{code}] {detail}")

    def get_violation_log(self) -> List[Dict[str, Any]]:
        return list(self._violation_log)

    def get_status(self) -> Dict[str, Any]:
        return {
            "estop_active":      self._estop_active,
            "last_safe_time":    self._last_safe_time,
            "check_count":       self._check_count,
            "violations_total":  len(self._violation_log),
            "last_violation":    self._violation_log[-1] if self._violation_log else None,
            "zone_status":       self._zone_checker.get_status(),
        }
