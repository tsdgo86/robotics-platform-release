"""
Human Zone Checker — Safety Zone Monitor
=========================================
Kiểm tra proximity của người (human) trong vùng làm việc của robot.

Dùng chung cho cả Robot Arm và Humanoid:
- Robot Arm: dừng nếu người vào workspace
- Humanoid: phát alert + dừng nếu khoảng cách < PERSON_STOP_M

Tích hợp với WorldModel để check real-time.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Thresholds
# ─────────────────────────────────────────────────────────────────────────────

PERSON_ALERT_M  = 1.5   # emit warning when person within this distance
PERSON_STOP_M   = 0.8   # stop robot when person within this distance (arm)
ZONE_LABELS     = {"restricted", "danger", "safety_zone", "red_zone"}


@dataclass
class HumanZoneStatus:
    """Result of a human zone check."""
    safe:            bool
    nearest_dist_m:  Optional[float]
    alert_triggered: bool
    stop_triggered:  bool
    violations:      List[str]


class HumanZoneChecker:
    """
    Checks if humans are in safety-critical zones.

    Parameters
    ----------
    person_alert_m : distance for WARNING
    person_stop_m  : distance for STOP (arm workspace)
    """

    def __init__(
        self,
        person_alert_m: float = PERSON_ALERT_M,
        person_stop_m:  float = PERSON_STOP_M,
    ) -> None:
        self._alert_m = person_alert_m
        self._stop_m  = person_stop_m
        self._alert_count = 0
        self._stop_count  = 0

    def check(self, world_state: Dict[str, Any]) -> HumanZoneStatus:
        """
        Evaluate world state for human proximity violations.

        world_state keys used:
          - "nearest_person_m"  : float — distance to nearest person
          - "person_too_close"  : bool
          - "human_in_workspace": bool
          - "restricted_zones"  : List[str] — labels of active zones
        """
        violations: List[str] = []
        nearest = world_state.get("nearest_person_m")
        person_close = world_state.get("person_too_close", False)
        human_in_ws  = world_state.get("human_in_workspace", False)

        alert_triggered = False
        stop_triggered  = False

        # Check nearest distance
        if nearest is not None:
            if nearest <= self._stop_m or human_in_ws:
                stop_triggered = True
                violations.append(
                    f"PERSON_IN_STOP_ZONE dist={nearest:.2f}m "
                    f"(limit={self._stop_m}m)"
                )
                self._stop_count += 1
                logger.warning(
                    f"[HumanZone] STOP ZONE violation: person at {nearest:.2f}m"
                )

            elif nearest <= self._alert_m or person_close:
                alert_triggered = True
                violations.append(
                    f"PERSON_IN_ALERT_ZONE dist={nearest:.2f}m "
                    f"(limit={self._alert_m}m)"
                )
                self._alert_count += 1
                logger.warning(
                    f"[HumanZone] ALERT: person at {nearest:.2f}m"
                )

        # Check restricted zone occupancy
        active_zones = world_state.get("restricted_zones", [])
        for zone in active_zones:
            if zone.lower() in ZONE_LABELS:
                stop_triggered = True
                violations.append(f"RESTRICTED_ZONE_OCCUPIED: {zone}")
                logger.warning(f"[HumanZone] Restricted zone occupied: {zone}")

        safe = not (stop_triggered or (alert_triggered and human_in_ws))
        return HumanZoneStatus(
            safe=safe,
            nearest_dist_m=nearest,
            alert_triggered=alert_triggered,
            stop_triggered=stop_triggered,
            violations=violations,
        )

    def get_status(self) -> Dict[str, Any]:
        return {
            "alert_count": self._alert_count,
            "stop_count":  self._stop_count,
            "alert_m":     self._alert_m,
            "stop_m":      self._stop_m,
        }
