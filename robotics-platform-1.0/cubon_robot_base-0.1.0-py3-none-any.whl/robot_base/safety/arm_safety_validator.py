"""
Arm Safety Validator — Independent Safety Layer for Robot Arm
=============================================================
Lớp an toàn độc lập hoàn toàn với AI Agent.

AI KHÔNG được phép bypass Safety Validator.
Mọi skill/action request phải qua approve_skill() (hoặc approve_action())
trước khi executor được gọi.

Checks thực hiện:
1. Emergency stop state
2. Workspace boundary (x/y/z limits)
3. Joint position limits (tất cả joints)
4. Velocity limits
5. Force/torque limits
6. Collision risk (workspace occupied) -- flag-based, từ world_state
   (path_clear / human_in_workspace).
7. Self-collision hình học thật (capsule distance qua ArmCollisionChecker),
   CHỈ chạy khi sensor_data["joint_positions"] có đủ góc khớp -- cùng dict
   dùng cho check #3, feed thẳng qua forward kinematics (DEFAULT_ARM_CHAIN)
   sang collision checker. Nếu thiếu góc khớp, bị coi là insufficient data
   (fail-closed), KHÔNG bỏ qua như đã pass.
8. Sensor validity (camera, force sensor live)

Implements robot_base.safety.BaseSafetyRuntime.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from robot_base.core.kinematics import KinematicChain, MissingJointAngleError, compute_joint_positions
from robot_base.core.arm_kinematic_chain import DEFAULT_ARM_CHAIN
from robot_base.safety.arm_collision_checker import ArmCollisionChecker
from robot_base.safety.base_safety_runtime import BaseSafetyRuntime

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Hard Safety Limits for Generic Robot Arm
# (These are conservative defaults — override via ArmSafetyConfig)
# ─────────────────────────────────────────────────────────────────────────────

DEFAULT_WORKSPACE = {
    "x_min": -1.2, "x_max": 1.2,
    "y_min": -1.2, "y_max": 1.2,
    "z_min":  0.0, "z_max": 1.5,
}

MAX_JOINT_VELOCITY   = 3.14   # rad/s  — hard cap per joint
MAX_FORCE_N          = 80.0   # N      — gripper + end-effector force
MAX_TORQUE_NM        = 30.0   # Nm     — wrist torque limit
MIN_CONFIDENCE       = 0.75   # vision — reject if detection confidence below this

# Joint position limits [lo_rad, hi_rad] for a generic 6-DOF arm
DEFAULT_JOINT_LIMITS: Dict[str, Tuple[float, float]] = {
    "joint_1": (-3.14, 3.14),
    "joint_2": (-2.09, 2.09),
    "joint_3": (-3.14, 3.14),
    "joint_4": (-3.14, 3.14),
    "joint_5": (-2.09, 2.09),
    "joint_6": (-3.14, 3.14),
}


# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ArmSafetyConfig:
    workspace:       Dict[str, float]         = field(default_factory=lambda: dict(DEFAULT_WORKSPACE))
    joint_limits:    Dict[str, Tuple[float, float]] = field(default_factory=lambda: dict(DEFAULT_JOINT_LIMITS))
    max_joint_vel:   float = MAX_JOINT_VELOCITY
    max_force_n:     float = MAX_FORCE_N
    max_torque_nm:   float = MAX_TORQUE_NM
    min_confidence:  float = MIN_CONFIDENCE
    estop_active:    bool  = False


# ─────────────────────────────────────────────────────────────────────────────
# Arm Safety Validator
# ─────────────────────────────────────────────────────────────────────────────

class ArmSafetyValidator(BaseSafetyRuntime):
    """
    Full safety validator for robot arm skills/actions.

    Two entry points:
    - approve_skill(request, context, definition): full pipeline used by
      factory_hacks.skills.runtime.SkillRuntime (duck-typed via
      SafetyValidatorProtocol -- request/context/definition are any
      objects exposing .params / .sensor_data / .world_state / .name).
    - approve_action(task_or_command): the generic single-arg entry point
      required by BaseSafetyRuntime, for callers without a skill pipeline.

    Convention for all check_* methods (BaseSafetyRuntime contract):
    return True means "no violation / safe to proceed".
    """

    def __init__(
        self,
        config: Optional[ArmSafetyConfig] = None,
        collision_checker: Optional[ArmCollisionChecker] = None,
        kinematic_chain: Optional[KinematicChain] = None,
    ) -> None:
        self._config          = config or ArmSafetyConfig()
        self._estop_active    = self._config.estop_active
        self._collision_checker = collision_checker or ArmCollisionChecker()
        self._kinematic_chain   = kinematic_chain or DEFAULT_ARM_CHAIN
        self._violation_log:  List[Dict[str, Any]] = []
        self._last_safe_time: float = time.time()
        self._check_count:    int   = 0

    # ── Public: called by SkillRuntime (not by AI) ────────────────────────────

    async def approve_skill(
        self,
        request: Any,
        context: Any,
        definition: Any,
    ) -> Tuple[bool, List[str]]:
        """
        Gate function for SkillRuntime.
        Returns (approved, list_of_violations).
        """
        self._check_count += 1
        violations: List[str] = []

        sensor_data = context.sensor_data
        world_state = context.world_state

        # 1. Emergency stop
        if self._estop_active:
            violations.append("ESTOP_ACTIVE")
            return False, violations

        # 2. Sensor validity
        violations.extend(self._check_sensor_validity(sensor_data))

        # 3. Vision confidence (for skills that need detection)
        if definition.name in ("DETECT_OBJECT", "CLASSIFY_PRODUCT", "ESTIMATE_POSE"):
            violations.extend(self._check_vision_confidence(sensor_data))

        # 4. Target pose workspace boundary
        for pose_key in ("target_pose", "source_pose", "object_pose"):
            if pose_key in request.params:
                violations.extend(self._check_workspace(request.params[pose_key]))

        # 5. Joint position limits
        violations.extend(self._check_joint_limits(sensor_data))

        # 6. Velocity limits
        violations.extend(self._check_velocity_limits(sensor_data))

        # 7. Force / torque
        violations.extend(self._check_force_limits_internal(sensor_data))

        # 8. Collision risk (basic — world state check)
        violations.extend(self._check_collision_risk_internal(world_state))

        # 9. Self-collision (geometric, via forward kinematics -- only if
        #    joint angles were supplied; see _check_self_collision)
        violations.extend(self._check_self_collision(sensor_data))

        if violations:
            for v in violations:
                self._log_violation(v, f"skill={request.skill_name} req={request.request_id}")
            return False, violations

        self._last_safe_time = time.time()
        return True, []

    # ── BaseSafetyRuntime interface ───────────────────────────────────────────

    async def check_emergency_stop(self) -> bool:
        """True when NOT emergency-stopped (safe to proceed)."""
        return not self._estop_active

    async def check_collision_risk(self, world_state: Any) -> bool:
        """
        True when no collision risk detected. This is the flag-based check
        (path_clear / human_in_workspace from world_state) only -- the ABC
        signature takes world_state, not sensor_data, so it cannot also run
        the geometric self-collision check, which needs joint angles. See
        approve_skill()/approve_action(), which run both.
        """
        return len(self._check_collision_risk_internal(world_state)) == 0

    async def check_force_limits(self, sensor_data: Any) -> bool:
        """True when force/torque readings are within configured limits."""
        return len(self._check_force_limits_internal(sensor_data)) == 0

    async def approve_action(self, task_or_command: Any) -> bool:
        """
        Generic single-object entry point required by BaseSafetyRuntime.
        Prefer approve_skill() for full-pipeline validation (workspace,
        joints, velocity, force, vision confidence, collision) with
        detailed violation reporting -- this is a reduced-info fallback
        for callers that only have a dict-like command payload with
        optional keys: sensor_data, world_state, target_pose.
        """
        if self._estop_active:
            return False
        cmd = task_or_command if isinstance(task_or_command, dict) else {}
        sensor_data = cmd.get("sensor_data", {})
        world_state = cmd.get("world_state", {})

        violations: List[str] = []
        violations.extend(self._check_joint_limits(sensor_data))
        violations.extend(self._check_velocity_limits(sensor_data))
        violations.extend(self._check_force_limits_internal(sensor_data))
        violations.extend(self._check_collision_risk_internal(world_state))
        violations.extend(self._check_self_collision(sensor_data))
        pose = cmd.get("target_pose")
        if pose:
            violations.extend(self._check_workspace(pose))
        return len(violations) == 0

    async def trigger_safe_stop(self, reason: str) -> None:
        self.trigger_estop(reason)

    # ── Emergency Stop ────────────────────────────────────────────────────────

    def trigger_estop(self, reason: str = "") -> None:
        """Engage emergency stop. Arm will reject ALL further skill requests."""
        logger.warning(f"[ArmSafety] E-STOP triggered: {reason}")
        self._estop_active = True
        self._log_violation("ESTOP_TRIGGERED", reason)

    def clear_estop(self, reason: str = "") -> None:
        """Clear emergency stop after manual inspection/confirmation."""
        logger.info(f"[ArmSafety] E-STOP cleared: {reason}")
        self._estop_active = False

    def set_estop(self, active: bool) -> None:
        """Direct setter for tests / bridge."""
        self._estop_active = active

    # ── Individual Checks (operate on plain dicts) ────────────────────────────

    def _check_sensor_validity(self, sensor_data: Dict[str, Any]) -> List[str]:
        violations = []
        ts = sensor_data.get("timestamp")
        if ts is not None:
            age = time.time() - float(ts)
            if age > 2.0:
                violations.append(f"STALE_SENSOR_DATA (age={age:.1f}s)")
        return violations

    def _check_vision_confidence(self, sensor_data: Dict[str, Any]) -> List[str]:
        violations = []
        confidence = sensor_data.get("detection_confidence")
        if confidence is not None and float(confidence) < self._config.min_confidence:
            violations.append(
                f"LOW_VISION_CONFIDENCE ({confidence:.2f} < {self._config.min_confidence})"
            )
        return violations

    def _check_workspace(self, pose: Dict[str, Any]) -> List[str]:
        """Check if a target pose is within workspace boundaries."""
        violations = []
        ws = self._config.workspace
        for axis, lo_key, hi_key in [("x", "x_min", "x_max"), ("y", "y_min", "y_max"), ("z", "z_min", "z_max")]:
            val = pose.get(axis)
            if val is None:
                continue
            lo, hi = ws.get(lo_key, -999), ws.get(hi_key, 999)
            if not (lo <= val <= hi):
                violations.append(
                    f"WORKSPACE_VIOLATION axis={axis} val={val:.3f} "
                    f"allowed=[{lo}, {hi}]"
                )
        return violations

    def _check_joint_limits(self, sensor_data: Dict[str, Any]) -> List[str]:
        """Validate joint positions from sensor data against config limits."""
        violations = []
        joint_positions = sensor_data.get("joint_positions", {})
        for joint_name, (lo, hi) in self._config.joint_limits.items():
            pos = joint_positions.get(joint_name)
            if pos is None:
                continue
            if not (lo <= pos <= hi):
                violations.append(
                    f"JOINT_LIMIT joint={joint_name} pos={pos:.3f} "
                    f"allowed=[{lo:.2f}, {hi:.2f}]"
                )
        return violations

    def _check_velocity_limits(self, sensor_data: Dict[str, Any]) -> List[str]:
        violations = []
        joint_velocities = sensor_data.get("joint_velocities", {})
        for joint_name, vel in joint_velocities.items():
            if abs(vel) > self._config.max_joint_vel:
                violations.append(
                    f"JOINT_VEL_LIMIT joint={joint_name} vel={vel:.2f} "
                    f"max={self._config.max_joint_vel}"
                )
        return violations

    def _check_force_limits_internal(self, sensor_data: Dict[str, Any]) -> List[str]:
        violations = []
        force_n   = sensor_data.get("force_n")
        torque_nm = sensor_data.get("torque_nm")
        if force_n is not None and abs(force_n) > self._config.max_force_n:
            violations.append(f"FORCE_LIMIT ({force_n:.1f}N > {self._config.max_force_n}N)")
        if torque_nm is not None and abs(torque_nm) > self._config.max_torque_nm:
            violations.append(f"TORQUE_LIMIT ({torque_nm:.1f}Nm > {self._config.max_torque_nm}Nm)")
        return violations

    def _check_collision_risk_internal(self, world_state: Dict[str, Any]) -> List[str]:
        """Basic collision check via world state (path_clear flag)."""
        violations = []
        path_clear = world_state.get("path_clear", True)
        if not path_clear:
            violations.append("COLLISION_RISK path_clear=False")
        human_in_workspace = world_state.get("human_in_workspace", False)
        if human_in_workspace:
            violations.append("HUMAN_IN_WORKSPACE")
        return violations

    def _check_self_collision(self, sensor_data: Dict[str, Any]) -> List[str]:
        """
        Real geometric self-collision check via forward kinematics.

        No-op (empty list) when sensor_data has no joint_positions -- this
        augments the flag-based _check_collision_risk_internal, it doesn't
        replace it (that one also covers human-in-workspace, which FK/
        self-collision knows nothing about).

        Uses strict FK: if joint_positions is present but INCOMPLETE (some
        joints missing), that is reported as a violation rather than
        silently computing a self-collision check against a partially
        guessed (angle=0.0) pose -- a wrong pose could hide a real
        collision, which is unacceptable for a safety check.
        """
        joint_angles = sensor_data.get("joint_positions")
        if not joint_angles:
            return []
        try:
            link_positions = compute_joint_positions(
                self._kinematic_chain, joint_angles, strict=True
            )
        except MissingJointAngleError as e:
            return [f"COLLISION_CHECK_INCOMPLETE_POSE ({e})"]
        _, violations = self._collision_checker.check_pose(link_positions)
        return violations

    # ── Diagnostics ───────────────────────────────────────────────────────────

    def _log_violation(self, code: str, detail: str) -> None:
        entry = {"time": time.time(), "code": code, "detail": detail}
        self._violation_log.append(entry)
        if len(self._violation_log) > 200:
            self._violation_log.pop(0)
        logger.warning(f"[ArmSafety] [{code}] {detail}")

    def get_violation_log(self) -> List[Dict[str, Any]]:
        return list(self._violation_log)

    def get_status(self) -> Dict[str, Any]:
        return {
            "estop_active":      self._estop_active,
            "last_safe_time":    self._last_safe_time,
            "check_count":       self._check_count,
            "violations_total":  len(self._violation_log),
            "last_violation":    self._violation_log[-1] if self._violation_log else None,
        }
