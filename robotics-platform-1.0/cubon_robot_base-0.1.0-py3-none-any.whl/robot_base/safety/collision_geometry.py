"""
Collision Geometry — Shared Capsule-Distance Primitives
==========================================================
Toán học hình học dùng chung cho collision checking thật (không phải flag
boolean): mỗi link được xấp xỉ bằng một capsule (đoạn thẳng 3D + bán kính).
Self-collision = khoảng cách nhỏ nhất giữa hai capsule không kề nhau nhỏ
hơn tổng bán kính (+ margin). Environment collision = khoảng cách từ
capsule tới một điểm/obstacle nhỏ hơn (bán kính link + bán kính obstacle
+ margin).

QUAN TRỌNG -- giới hạn thật của cách tiếp cận này:
- Đây là xấp xỉ capsule/segment, KHÔNG phải mesh collision đầy đủ. Với
  hình học phức tạp (bàn tay nhiều ngón, chi tiết mặt sau robot...) capsule
  có thể báo sai âm tính (miss) hoặc dương tính giả (false positive) so
  với mesh thật.
- Checker này KHÔNG tự tính forward kinematics -- nó nhận vào vị trí
  Cartesian (x, y, z) của từng joint. robot_base.core.kinematics
  (compute_joint_positions + DEFAULT_ARM_CHAIN/DEFAULT_HUMANOID_CHAIN) nay
  có thể tính vị trí đó từ góc khớp, nhưng vẫn KHÔNG parse URDF thật -- các
  offset link trong *_kinematic_chain.py là placeholder, cần thay bằng số
  đo thật khi có URDF chính thức.
- Nếu thiếu dữ liệu vị trí cho một link, link đó bị coi là "không thể xác
  minh" -- checker KHÔNG ngầm coi là an toàn (fail-closed), khác với
  _check_collision_risk_internal cũ chỉ tin một flag path_clear.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Union

# A joint position in a common Cartesian frame (e.g., robot base_link frame).
Point3 = Tuple[float, float, float]

# Link pose as supplied by the caller: either a single point (treated as a
# zero-length capsule / sphere) or a (start, end) pair (a true capsule).
LinkPose = Union[Point3, Tuple[Point3, Point3]]

# One waypoint of a trajectory: link_name -> LinkPose (or joint_name -> Point3,
# see JointChainCollisionChecker, which derives link poses from joint pairs).
PoseSnapshot = Dict[str, "Point3"]


def _as_segment(pose: LinkPose) -> Tuple[Point3, Point3]:
    if isinstance(pose[0], (int, float)):
        p = pose  # type: ignore[assignment]
        return p, p
    a, b = pose  # type: ignore[misc]
    return a, b


def _sub(a: Point3, b: Point3) -> Point3:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _dot(a: Point3, b: Point3) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _add(a: Point3, s: float, b: Point3) -> Point3:
    return (a[0] + s * b[0], a[1] + s * b[1], a[2] + s * b[2])


def segment_distance(p1: Point3, p2: Point3, q1: Point3, q2: Point3) -> float:
    """
    Minimum distance between two 3D line segments [p1,p2] and [q1,q2].
    Standard closest-point-between-segments algorithm (degenerates
    correctly to point-to-point / point-to-segment when a segment has
    zero length, i.e. a link supplied as a single point).
    """
    d1 = _sub(p2, p1)
    d2 = _sub(q2, q1)
    r = _sub(p1, q1)
    a = _dot(d1, d1)
    e = _dot(d2, d2)
    f = _dot(d2, r)

    EPS = 1e-12
    if a <= EPS and e <= EPS:
        # Both degenerate to points.
        return math.dist(p1, q1)

    if a <= EPS:
        s = 0.0
        t = max(0.0, min(1.0, f / e))
    else:
        c = _dot(d1, r)
        if e <= EPS:
            t = 0.0
            s = max(0.0, min(1.0, -c / a))
        else:
            b = _dot(d1, d2)
            denom = a * e - b * b
            s = max(0.0, min(1.0, (b * f - c * e) / denom)) if denom > EPS else 0.0
            t = (b * s + f) / e
            if t < 0.0:
                t = 0.0
                s = max(0.0, min(1.0, -c / a))
            elif t > 1.0:
                t = 1.0
                s = max(0.0, min(1.0, (b - c) / a))

    closest_p = _add(p1, s, d1)
    closest_q = _add(q1, t, d2)
    return math.dist(closest_p, closest_q)


def point_segment_distance(point: Point3, p1: Point3, p2: Point3) -> float:
    """Distance from a point to a segment -- special case of segment_distance."""
    return segment_distance(point, point, p1, p2)


@dataclass(frozen=True)
class LinkSegment:
    """
    One rigid link, approximated as a capsule between two named joints.

    name     : link identifier, used in violation messages
    joint_a  : name of the proximal joint (must be a key in the supplied
               joint-position dict)
    joint_b  : name of the distal joint
    radius_m : capsule radius (half-thickness of the real link + safety
               margin baked in by the caller)
    """
    name:     str
    joint_a:  str
    joint_b:  str
    radius_m: float
