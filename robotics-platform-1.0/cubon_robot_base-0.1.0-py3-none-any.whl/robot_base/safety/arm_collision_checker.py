"""
Arm Collision Checker — Concrete BaseCollisionChecker for a generic 6-DOF arm
================================================================================
Link topology matches the joint naming in arm_safety_validator.DEFAULT_JOINT_LIMITS
(joint_1..joint_6). Radii are conservative placeholders for a mid-size
industrial/collaborative arm -- replace with real link dimensions from the
robot's URDF when available.
"""

from __future__ import annotations

from typing import Optional, Sequence, Set, Tuple

from robot_base.safety.collision_geometry import LinkSegment
from robot_base.safety.joint_chain_collision_checker import JointChainCollisionChecker

# joint_1 = base, joint_6 = wrist, end_effector = TCP.
DEFAULT_ARM_LINKS = [
    LinkSegment("link_1_2",  "joint_1", "joint_2",      radius_m=0.08),
    LinkSegment("link_2_3",  "joint_2", "joint_3",      radius_m=0.07),
    LinkSegment("link_3_4",  "joint_3", "joint_4",      radius_m=0.05),
    LinkSegment("link_4_5",  "joint_4", "joint_5",      radius_m=0.04),
    LinkSegment("link_5_6",  "joint_5", "joint_6",      radius_m=0.035),
    LinkSegment("link_6_ee", "joint_6", "end_effector", radius_m=0.03),
]


class ArmCollisionChecker(JointChainCollisionChecker):
    """
    Self-collision + environment-collision checker for a 6-DOF arm.

    Requires joint_positions keyed by "joint_1".."joint_6", "end_effector"
    (Cartesian, in the arm's base frame) -- these are NOT the joint angles
    used by ArmSafetyValidator's joint-limit check, they are 3D positions
    from forward kinematics.
    """

    def __init__(
        self,
        links: Optional[Sequence[LinkSegment]] = None,
        allowed_collision_pairs: Optional[Set[Tuple[str, str]]] = None,
        obstacle_radius_m: float = 0.3,
        margin_m: float = 0.05,
    ) -> None:
        super().__init__(
            links or DEFAULT_ARM_LINKS,
            allowed_collision_pairs=allowed_collision_pairs,
            obstacle_radius_m=obstacle_radius_m,
            margin_m=margin_m,
        )
