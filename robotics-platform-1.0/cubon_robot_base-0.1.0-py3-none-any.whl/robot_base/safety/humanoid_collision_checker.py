"""
Humanoid Collision Checker — Concrete BaseCollisionChecker for a bipedal humanoid
====================================================================================
Link topology uses coarse per-limb joint ANCHOR points (one 3D point per
physical joint center, e.g. "left_hip", "left_knee"), which is a smaller
set than HumanoidSafetyRuntime.DEFAULT_JOINT_LIMITS (one entry per rotational
DoF, e.g. "left_hip_pitch"/"left_hip_roll"/"left_hip_yaw" -- those share one
physical joint center for collision purposes). Radii are conservative
placeholders -- replace with real link dimensions from the robot's URDF
when available.

allowed_collision_pairs includes torso<->limb-root pairs that are
physically adjacent but don't share a joint name in this simplified
topology (hips/shoulders attach to the torso/pelvis, but are named
distinctly). This is a manually curated starting point, same spirit as a
MoveIt SRDF "disable_collisions" matrix -- it should be refined against
the real URDF and a calibration pass in the robot's neutral pose.
"""

from __future__ import annotations

from typing import Optional, Sequence, Set, Tuple

from robot_base.safety.collision_geometry import LinkSegment
from robot_base.safety.joint_chain_collision_checker import JointChainCollisionChecker

DEFAULT_HUMANOID_LINKS = [
    # Legs
    LinkSegment("left_thigh",   "left_hip",     "left_knee",   radius_m=0.06),
    LinkSegment("left_shin",    "left_knee",    "left_ankle",  radius_m=0.05),
    LinkSegment("left_foot",    "left_ankle",   "left_ankle",  radius_m=0.08),
    LinkSegment("right_thigh",  "right_hip",    "right_knee",  radius_m=0.06),
    LinkSegment("right_shin",   "right_knee",   "right_ankle", radius_m=0.05),
    LinkSegment("right_foot",   "right_ankle",  "right_ankle", radius_m=0.08),
    # Arms
    LinkSegment("left_upper_arm",  "left_shoulder",  "left_elbow", radius_m=0.06),
    LinkSegment("left_forearm",    "left_elbow",     "left_wrist", radius_m=0.05),
    LinkSegment("left_hand",       "left_wrist",     "left_wrist", radius_m=0.06),
    LinkSegment("right_upper_arm", "right_shoulder", "right_elbow", radius_m=0.06),
    LinkSegment("right_forearm",   "right_elbow",    "right_wrist", radius_m=0.05),
    LinkSegment("right_hand",      "right_wrist",    "right_wrist", radius_m=0.06),
    # Torso / head
    LinkSegment("torso", "pelvis", "neck", radius_m=0.16),
    LinkSegment("head",  "neck",  "head",  radius_m=0.11),
]

# Torso/pelvis is physically adjacent to limb roots (hips, shoulders) but
# doesn't share a joint name with them in this topology -- see module docstring.
DEFAULT_HUMANOID_ALLOWED_PAIRS: Set[Tuple[str, str]] = {
    ("torso", "left_thigh"), ("torso", "right_thigh"),
    ("torso", "left_upper_arm"), ("torso", "right_upper_arm"),
    ("torso", "head"),
}


class HumanoidCollisionChecker(JointChainCollisionChecker):
    """
    Self-collision + environment-collision checker for a bipedal humanoid.

    Requires joint_positions keyed by physical joint-center names:
    left/right_hip, left/right_knee, left/right_ankle, left/right_shoulder,
    left/right_elbow, left/right_wrist, pelvis, neck, head (Cartesian, in
    the robot's base/world frame) -- from forward kinematics, not the
    per-DoF joint angles used by HumanoidSafetyRuntime's joint-limit check.
    """

    def __init__(
        self,
        links: Optional[Sequence[LinkSegment]] = None,
        allowed_collision_pairs: Optional[Set[Tuple[str, str]]] = None,
        obstacle_radius_m: float = 0.3,
        margin_m: float = 0.05,
    ) -> None:
        merged_allowed = set(DEFAULT_HUMANOID_ALLOWED_PAIRS)
        merged_allowed |= (allowed_collision_pairs or set())
        super().__init__(
            links or DEFAULT_HUMANOID_LINKS,
            allowed_collision_pairs=merged_allowed,
            obstacle_radius_m=obstacle_radius_m,
            margin_m=margin_m,
        )
