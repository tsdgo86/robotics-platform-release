"""
Joint-Chain Collision Checker — Concrete BaseCollisionChecker
================================================================
Generic implementation of BaseCollisionChecker for any robot that can be
described as a set of rigid links (capsules) between named joints. Robot-
specific subclasses (ArmCollisionChecker, HumanoidCollisionChecker) only
need to supply link topology (which joints, which radius) -- the distance
math and fail-closed behavior live here, once.

Fail-closed policy: if a link's joint positions are missing from the
supplied data, that link is reported as COLLISION_DATA_MISSING rather
than silently treated as clear. A trajectory/pose is never approved
"safe" on the basis of absent data.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, FrozenSet, List, Optional, Sequence, Set, Tuple

from robot_base.safety.base_collision_checker import BaseCollisionChecker
from robot_base.safety.collision_geometry import (
    LinkSegment,
    Point3,
    PoseSnapshot,
    point_segment_distance,
    segment_distance,
)

logger = logging.getLogger(__name__)

# One obstacle: {"id": str, "position": Point3, "radius_m": float (optional)}
Obstacle = Dict[str, Any]

# One trajectory waypoint:
#   {"joint_positions": {joint_name: Point3, ...}, "obstacles": [Obstacle, ...]}
# "obstacles" is optional (omit or [] for self-collision-only checking).
Waypoint = Dict[str, Any]


class JointChainCollisionChecker(BaseCollisionChecker):
    """
    Capsule-based self-collision + environment-collision checker for a
    kinematic chain described as a list of LinkSegment.

    NOTE: This class does not compute forward kinematics itself. Callers
    supply joint Cartesian positions -- robot_base.core.kinematics
    (compute_joint_positions + DEFAULT_ARM_CHAIN/DEFAULT_HUMANOID_CHAIN)
    can now produce those from joint angles, though the chain link offsets
    are placeholders, not real URDF measurements. robot_base/config is
    still empty (no URDF loader).
    """

    def __init__(
        self,
        links: Sequence[LinkSegment],
        allowed_collision_pairs: Optional[Set[Tuple[str, str]]] = None,
        obstacle_radius_m: float = 0.3,
        margin_m: float = 0.05,
    ) -> None:
        self._links: List[LinkSegment] = list(links)
        self._allowed: Set[FrozenSet[str]] = self._auto_adjacent_pairs(self._links)
        for a, b in (allowed_collision_pairs or set()):
            self._allowed.add(frozenset((a, b)))
        self._obstacle_radius_m = obstacle_radius_m
        self._margin_m = margin_m
        self._check_count = 0

    @staticmethod
    def _auto_adjacent_pairs(links: Sequence[LinkSegment]) -> Set[FrozenSet[str]]:
        """Links sharing a joint are physically adjacent -- always excluded."""
        pairs: Set[FrozenSet[str]] = set()
        for i, li in enumerate(links):
            joints_i = {li.joint_a, li.joint_b}
            for lj in links[i + 1:]:
                if joints_i & {lj.joint_a, lj.joint_b}:
                    pairs.add(frozenset((li.name, lj.name)))
        return pairs

    # ── Detailed checks (violation strings) ───────────────────────────────────

    def check_self_collision(self, joint_positions: PoseSnapshot) -> List[str]:
        violations: List[str] = []
        resolved: List[Tuple[LinkSegment, Point3, Point3]] = []
        missing: List[str] = []

        for link in self._links:
            pa = joint_positions.get(link.joint_a)
            pb = joint_positions.get(link.joint_b)
            if pa is None or pb is None:
                missing.append(link.name)
                continue
            resolved.append((link, pa, pb))

        for name in missing:
            violations.append(f"COLLISION_DATA_MISSING link={name}")

        for i in range(len(resolved)):
            link_i, pa_i, pb_i = resolved[i]
            for j in range(i + 1, len(resolved)):
                link_j, pa_j, pb_j = resolved[j]
                if frozenset((link_i.name, link_j.name)) in self._allowed:
                    continue
                dist = segment_distance(pa_i, pb_i, pa_j, pb_j)
                min_dist = link_i.radius_m + link_j.radius_m + self._margin_m
                if dist < min_dist:
                    violations.append(
                        f"SELF_COLLISION {link_i.name}<->{link_j.name} "
                        f"dist={dist:.3f}m min={min_dist:.3f}m"
                    )
        return violations

    def check_environment_collision(
        self,
        joint_positions: PoseSnapshot,
        obstacles: Sequence[Obstacle],
    ) -> List[str]:
        violations: List[str] = []
        for link in self._links:
            pa = joint_positions.get(link.joint_a)
            pb = joint_positions.get(link.joint_b)
            if pa is None or pb is None:
                continue  # already reported by check_self_collision
            for obs in obstacles:
                pos = obs.get("position")
                if pos is None:
                    continue
                obs_r = obs.get("radius_m", self._obstacle_radius_m)
                dist = point_segment_distance(pos, pa, pb)
                min_dist = link.radius_m + obs_r + self._margin_m
                if dist < min_dist:
                    violations.append(
                        f"ENV_COLLISION link={link.name} obstacle={obs.get('id', '?')} "
                        f"dist={dist:.3f}m min={min_dist:.3f}m"
                    )
        return violations

    def check_pose(
        self,
        joint_positions: PoseSnapshot,
        obstacles: Optional[Sequence[Obstacle]] = None,
    ) -> Tuple[bool, List[str]]:
        """Full check for one pose. Returns (collision_free, violations)."""
        self._check_count += 1
        if not joint_positions:
            return False, ["NO_POSE_DATA"]
        violations = self.check_self_collision(joint_positions)
        if obstacles:
            violations += self.check_environment_collision(joint_positions, obstacles)
        return len(violations) == 0, violations

    # ── BaseCollisionChecker interface ────────────────────────────────────────

    async def validate_collision_free(self, trajectory: Any) -> bool:
        """
        trajectory: Sequence[Waypoint], each a dict with:
          - "joint_positions": {joint_name: (x, y, z), ...}  (required)
          - "obstacles": [{"id": str, "position": (x,y,z), "radius_m": float}, ...] (optional)

        Fails closed: an empty trajectory, or any waypoint without
        joint_positions, is NOT collision-free.
        """
        ok, _ = await self.validate_collision_free_detailed(trajectory)
        return ok

    async def validate_collision_free_detailed(
        self, trajectory: Any
    ) -> Tuple[bool, List[str]]:
        """Same as validate_collision_free but returns per-waypoint violations."""
        if not trajectory:
            return False, ["EMPTY_TRAJECTORY"]

        all_violations: List[str] = []
        for idx, waypoint in enumerate(trajectory):
            joint_positions = waypoint.get("joint_positions") if isinstance(waypoint, dict) else None
            if not joint_positions:
                all_violations.append(f"waypoint[{idx}]: NO_POSE_DATA")
                continue
            obstacles = waypoint.get("obstacles") or []
            ok, violations = self.check_pose(joint_positions, obstacles)
            all_violations.extend(f"waypoint[{idx}]: {v}" for v in violations)

        return len(all_violations) == 0, all_violations

    # ── Diagnostics ───────────────────────────────────────────────────────────

    def get_status(self) -> Dict[str, Any]:
        return {
            "link_count":      len(self._links),
            "allowed_pairs":   len(self._allowed),
            "check_count":     self._check_count,
            "margin_m":        self._margin_m,
        }
