from abc import ABC, abstractmethod
from typing import Any
from robot_base.core.base_state import BaseState


class BaseController(ABC):
    """Interface for robot controller."""

    @abstractmethod
    async def send_command(self, motion_command: Any) -> None:
        pass

    @abstractmethod
    async def monitor_execution_feedback(self) -> BaseState:
        pass

    @abstractmethod
    async def emergency_stop(self) -> None:
        pass
