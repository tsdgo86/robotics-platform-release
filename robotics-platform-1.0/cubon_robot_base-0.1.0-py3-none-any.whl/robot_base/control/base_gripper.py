from abc import ABC, abstractmethod


class BaseGripper(ABC):
    """Interface for End-Effector / Gripper controller."""

    @abstractmethod
    async def open_gripper(self) -> None:
        pass

    @abstractmethod
    async def close_gripper(self) -> None:
        pass
