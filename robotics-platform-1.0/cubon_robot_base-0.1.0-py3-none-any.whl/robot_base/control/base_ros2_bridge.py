from abc import ABC, abstractmethod


class BaseROS2Bridge(ABC):
    """Interface for ROS 2 Control Bridge."""

    @abstractmethod
    async def connect_controllers(self) -> bool:
        pass

    @abstractmethod
    async def publish_joint_trajectory(self, trajectory: str) -> None:
        pass
