"""
URDF Loader — Real Robot Geometry into a KinematicChain + Collision Links
============================================================================
Parses a PLAIN URDF file (<link>/<joint> XML) into:
  - a KinematicChain, for robot_base.core.kinematics.compute_joint_positions
  - a joint_limits dict (radians), same shape as ArmSafetyConfig/
    HumanoidSafetyConfig.joint_limits
  - a list of LinkSegment, for robot_base.safety's collision checkers, with
    radii derived from each link's <visual><geometry> (cylinder/sphere
    radius used directly; box approximated as half its smallest
    cross-section dimension -- a documented approximation, not exact)

This replaces guessed placeholder dimensions (arm_kinematic_chain.py /
humanoid_kinematic_chain.py, arm_collision_checker.py /
humanoid_collision_checker.py) with real measurements WHEN a real URDF is
available -- see robot_base/tests for a test that uses this against an
actual robot description when one is present on disk, and skips otherwise.

Does NOT expand xacro macros (<xacro:...> tags) -- only static URDF XML.
A .xacro file must be pre-processed (e.g. via the `xacro` CLI/ROS package,
which is not available outside a ROS install) into plain URDF first.

Only revolute/continuous/fixed joints are supported, matching what
compute_joint_positions already models -- prismatic/planar/floating raise
NotImplementedError rather than being silently mishandled. A nonzero
<origin rpy="..."> also raises NotImplementedError: JointSpec's origin is
translation-only today (see robot_base/core/kinematics.py) -- a rotated
joint origin would be silently wrong if just dropped, so it isn't.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from robot_base.core.kinematics import JointSpec, KinematicChain
from robot_base.safety.collision_geometry import LinkSegment

_EPS = 1e-6
_SUPPORTED_JOINT_TYPES = {"revolute", "continuous", "fixed"}
_UNLIMITED = (-3.14159265, 3.14159265)


@dataclass
class ParsedUrdf:
    chain: KinematicChain
    joint_limits: Dict[str, Tuple[float, float]]
    link_segments: List[LinkSegment]
    root_link: str


def _parse_xyz(s: Optional[str]) -> Tuple[float, float, float]:
    if not s:
        return (0.0, 0.0, 0.0)
    x, y, z = (float(v) for v in s.split())
    return (x, y, z)


def _link_radius(link_elem: Optional[ET.Element], default_radius_m: float) -> float:
    if link_elem is None:
        return default_radius_m
    visual = link_elem.find("visual")
    if visual is None:
        return default_radius_m
    geom = visual.find("geometry")
    if geom is None:
        return default_radius_m
    cyl = geom.find("cylinder")
    if cyl is not None:
        return float(cyl.get("radius"))
    sph = geom.find("sphere")
    if sph is not None:
        return float(sph.get("radius"))
    box = geom.find("box")
    if box is not None:
        x, y, _z = (float(v) for v in box.get("size").split())
        return min(x, y) / 2.0
    return default_radius_m


def load_urdf_chain(path: str, default_link_radius_m: float = 0.05) -> ParsedUrdf:
    tree = ET.parse(path)
    root = tree.getroot()
    if root.tag != "robot":
        raise ValueError(f"'{path}' is not a URDF file (root tag is <{root.tag}>, expected <robot>)")

    links = {l.get("name"): l for l in root.findall("link")}
    joints = list(root.findall("joint"))

    child_links = {j.find("child").get("link") for j in joints}
    root_links = set(links.keys()) - child_links
    if len(root_links) != 1:
        raise ValueError(
            f"'{path}': expected exactly one root link (no parent joint), found {sorted(root_links)}"
        )
    root_link = next(iter(root_links))

    # link name -> name of the joint that "creates" it (positions its
    # origin). The root link has no creating joint -- represented as a
    # synthetic fixed JointSpec named after itself, at the chain origin.
    link_to_joint: Dict[str, str] = {root_link: root_link}
    joint_specs: List[JointSpec] = [
        JointSpec(root_link, None, (0.0, 0.0, 0.0), joint_type="fixed")
    ]
    joint_limits: Dict[str, Tuple[float, float]] = {}

    # A link's geometry occupies the space AFTER the joint that creates it,
    # extending to that link's own child joint(s) -- not the space before
    # it. Precompute link -> [its child joint names] so link_segments can
    # be built correctly regardless of file order.
    child_joints_of_link: Dict[str, List[str]] = {}
    for j in joints:
        child_joints_of_link.setdefault(j.find("parent").get("link"), []).append(j.get("name"))

    # Joints may appear in file order that doesn't match parent-before-child
    # -- resolve with a fixed-point loop (chains here are small).
    remaining = list(joints)
    while remaining:
        progressed = False
        still_remaining = []
        for j in remaining:
            parent_link = j.find("parent").get("link")
            if parent_link not in link_to_joint:
                still_remaining.append(j)
                continue

            name = j.get("name")
            jtype = j.get("type")
            if jtype not in _SUPPORTED_JOINT_TYPES:
                raise NotImplementedError(
                    f"'{path}': joint '{name}' has unsupported type '{jtype}' "
                    f"(only {sorted(_SUPPORTED_JOINT_TYPES)} are supported)"
                )

            origin = j.find("origin")
            xyz = _parse_xyz(origin.get("xyz") if origin is not None else None)
            rpy = _parse_xyz(origin.get("rpy") if origin is not None else None)
            if any(abs(v) > _EPS for v in rpy):
                raise NotImplementedError(
                    f"'{path}': joint '{name}' has a nonzero <origin rpy=\"{rpy}\">, "
                    f"but JointSpec only supports translation offsets today "
                    f"(robot_base/core/kinematics.py) -- refusing to silently drop it."
                )

            axis_elem = j.find("axis")
            axis = _parse_xyz(axis_elem.get("xyz") if axis_elem is not None else "0 0 1")

            parent_joint_name = link_to_joint[parent_link]
            joint_specs.append(
                JointSpec(
                    name, parent_joint_name, xyz, axis=axis,
                    joint_type="fixed" if jtype == "fixed" else "revolute",
                )
            )

            if jtype in ("revolute", "continuous"):
                limit = j.find("limit")
                if limit is not None and limit.get("lower") is not None and limit.get("upper") is not None:
                    joint_limits[name] = (float(limit.get("lower")), float(limit.get("upper")))
                else:
                    joint_limits[name] = _UNLIMITED

            child_link_name = j.find("child").get("link")
            link_to_joint[child_link_name] = name

            progressed = True
        if not progressed:
            unresolved = [j.get("name") for j in still_remaining]
            raise ValueError(f"'{path}': could not resolve joints {unresolved} (missing parent link?)")
        remaining = still_remaining

    # link_segments: for each joint J (creating link C), C's geometry spans
    # from J to each of C's own child joints; a leaf link (no children)
    # becomes a degenerate point AT J -- same pattern as the hand-built
    # humanoid_collision_checker.DEFAULT_HUMANOID_LINKS "hand"/"foot" spheres.
    link_segments: List[LinkSegment] = []
    for j in joints:
        name = j.get("name")
        child_link_name = j.find("child").get("link")
        radius = _link_radius(links.get(child_link_name), default_link_radius_m)
        next_joints = child_joints_of_link.get(child_link_name, [])
        if next_joints:
            for next_joint in next_joints:
                link_segments.append(
                    LinkSegment(name=f"link_{child_link_name}", joint_a=name, joint_b=next_joint, radius_m=radius)
                )
        else:
            link_segments.append(
                LinkSegment(name=f"link_{child_link_name}", joint_a=name, joint_b=name, radius_m=radius)
            )

    chain = KinematicChain(name=root.get("name", "urdf_robot"), joints=joint_specs)
    return ParsedUrdf(
        chain=chain, joint_limits=joint_limits, link_segments=link_segments, root_link=root_link
    )
