"""
Base Anomaly Generator — Synthetic Fault Injection for Scarce Fault Data (A1)
==================================================================================
A1 (xem `docs/robotis_implementation/implementation_plan_v2` mục A1):
"Train predictive-maintenance AI with limited fault-mode data." Real
fault events are rare -- this module synthesizes labeled anomalous
sequences from a fitted nominal baseline so a downstream classifier
(trained via robot_base.data.base_model_trainer.BaseModelTrainer) has
enough anomaly examples to learn from.

`StatisticalAnomalyGenerator` is a reference implementation:
dependency-free (stdlib `random`/`statistics` only, seedable for
reproducible tests), injecting well-known fault patterns (spike, drift,
stuck-at, dropout) into a stochastic nominal baseline fitted from real
data (mean/std). This is the "physics-based simulation" half of A1's
suggested tech stack -- a real GAN/Diffusion generator (the other half)
implements the same BaseAnomalyGenerator interface once a torch
environment is available.
"""

from __future__ import annotations

import logging
import random
import statistics
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)


class AnomalyType(str, Enum):
    SPIKE = "spike"          # sudden large excursion for a few samples
    DRIFT = "drift"          # slow deviation that keeps growing and persists
    STUCK_AT = "stuck_at"    # sensor freezes at one value
    DROPOUT = "dropout"      # signal drops to ~0 (sensor disconnect)


@dataclass
class SyntheticAnomalySample:
    values: List[float]
    anomaly_type: str  # "" for a pure-nominal (non-anomalous) sample
    anomaly_start_idx: Optional[int] = None
    anomaly_end_idx: Optional[int] = None
    label: int = 0  # 1 = anomalous, 0 = nominal


class BaseAnomalyGenerator(ABC):
    """Interface for synthetic (augmented) fault-data generation."""

    @abstractmethod
    def fit(self, nominal_series: List[float]) -> None:
        """Fit the nominal baseline model from real (fault-free) observations."""
        pass

    @abstractmethod
    def generate(
        self, num_samples: int, sequence_length: int, anomaly_ratio: float = 0.5
    ) -> List[SyntheticAnomalySample]:
        """Generate a labeled mix of nominal and anomalous sequences."""
        pass


class StatisticalAnomalyGenerator(BaseAnomalyGenerator):
    """
    Fits mean/stddev from a nominal series, then synthesizes new
    sequences as a bounded (mean-reverting) random walk around that
    mean -- optionally injecting one fault pattern (spike/drift/
    stuck_at/dropout) at a random position/duration, scaled by the
    fitted stddev.
    """

    def __init__(self, seed: Optional[int] = None) -> None:
        self._rng = random.Random(seed)
        self._mean: Optional[float] = None
        self._std: Optional[float] = None
        self._fitted = False

    def fit(self, nominal_series: List[float]) -> None:
        if len(nominal_series) < 2:
            raise ValueError("StatisticalAnomalyGenerator needs at least 2 nominal observations to fit")
        self._mean = statistics.fmean(nominal_series)
        self._std = statistics.pstdev(nominal_series)
        if self._std < 1e-9:
            self._std = max(abs(self._mean) * 0.01, 1e-6)  # avoid a degenerate zero-noise baseline
        self._fitted = True
        logger.info(f"[StatisticalAnomalyGenerator] Fitted: mean={self._mean:.3f} std={self._std:.3f}")

    def _nominal_sequence(self, length: int) -> List[float]:
        assert self._mean is not None and self._std is not None
        value = self._mean
        seq: List[float] = []
        for _ in range(length):
            value += self._rng.gauss(0, self._std * 0.2)
            value = self._mean + (value - self._mean) * 0.9  # mean-reverting, avoids unbounded walk
            seq.append(value)
        return seq

    def _inject_anomaly(self, seq: List[float], anomaly_type: AnomalyType) -> Tuple[int, int]:
        assert self._std is not None
        length = len(seq)
        duration = max(1, min(length, self._rng.randint(max(1, length // 10), max(1, length // 3))))
        start = self._rng.randint(0, max(0, length - duration))
        end = start + duration

        if anomaly_type == AnomalyType.SPIKE:
            magnitude = self._std * self._rng.uniform(4.0, 8.0) * self._rng.choice([-1, 1])
            for i in range(start, end):
                seq[i] += magnitude
        elif anomaly_type == AnomalyType.DRIFT:
            total_drift = self._std * self._rng.uniform(3.0, 6.0) * self._rng.choice([-1, 1])
            for offset, i in enumerate(range(start, end)):
                seq[i] += total_drift * (offset + 1) / duration
            for i in range(end, length):  # real sensor drift doesn't snap back
                seq[i] += total_drift
        elif anomaly_type == AnomalyType.STUCK_AT:
            stuck_value = seq[start]
            for i in range(start, end):
                seq[i] = stuck_value
        elif anomaly_type == AnomalyType.DROPOUT:
            for i in range(start, end):
                seq[i] = 0.0

        return start, end

    def generate(
        self, num_samples: int, sequence_length: int, anomaly_ratio: float = 0.5
    ) -> List[SyntheticAnomalySample]:
        if not self._fitted:
            raise RuntimeError("fit() must be called before generate()")
        if num_samples < 1:
            raise ValueError("num_samples must be >= 1")
        if sequence_length < 4:
            raise ValueError("sequence_length must be >= 4 (need room to inject a fault pattern)")
        if not (0.0 <= anomaly_ratio <= 1.0):
            raise ValueError("anomaly_ratio must be in [0, 1]")

        num_anomalous = round(num_samples * anomaly_ratio)
        anomaly_types = list(AnomalyType)
        samples: List[SyntheticAnomalySample] = []

        for i in range(num_samples):
            seq = self._nominal_sequence(sequence_length)
            if i < num_anomalous:
                anomaly_type = anomaly_types[i % len(anomaly_types)]
                start, end = self._inject_anomaly(seq, anomaly_type)
                samples.append(SyntheticAnomalySample(
                    values=seq, anomaly_type=anomaly_type.value,
                    anomaly_start_idx=start, anomaly_end_idx=end, label=1,
                ))
            else:
                samples.append(SyntheticAnomalySample(values=seq, anomaly_type="", label=0))

        self._rng.shuffle(samples)
        logger.info(
            f"[StatisticalAnomalyGenerator] Generated {num_samples} samples "
            f"({num_anomalous} anomalous, {num_samples - num_anomalous} nominal)"
        )
        return samples
