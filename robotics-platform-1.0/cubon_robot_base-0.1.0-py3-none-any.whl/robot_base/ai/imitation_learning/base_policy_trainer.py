"""
Base Policy Trainer — Imitation Learning Model Interface
==============================================================
Interface cho bước 3 của pipeline Video-to-Action (xem
`docs/robotis_implementation/implementation_plan_v2` mục 2 và mục 5
"Open Questions"): huấn luyện policy điều khiển từ tập
`DemonstrationEpisode` đã ánh xạ (video hoặc teleop). Concrete
implementation thật cho ACT (Action Chunking with Transformers) hoặc
Diffusion Policy (H1 tech stack: PyTorch, Robomimic) sẽ implement ABC
này trong `robotis_physical_ai`/`factory_hacks` -- robot_base KHÔNG phụ
thuộc torch.

`NearestNeighborPolicyTrainer` là baseline behavior-cloning phi tham số
(k=1 nearest-neighbor trên joint-space), dependency-free, dùng để:
1. Test end-to-end pipeline (ingestion -> retargeting -> train -> predict)
   mà không cần cài ML stack nặng.
2. Làm baseline so sánh trong "Training method comparison report"
   (deliverable của H1) trước khi đầu tư ACT/Diffusion Policy.
"""

from __future__ import annotations

import json
import logging
import math
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from robot_base.ai.imitation_learning.demonstration import DemonstrationEpisode

logger = logging.getLogger(__name__)


@dataclass
class PolicyTrainingConfig:
    algorithm: str = "nearest_neighbor"  # "act" | "diffusion_policy" | "nearest_neighbor" | ...
    epochs: int = 100
    batch_size: int = 32
    learning_rate: float = 1e-4
    chunk_size: int = 1  # ACT-style action-chunking horizon
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PolicyArtifact:
    model_name: str
    version: str
    algorithm: str
    metrics: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    # Opaque model payload -- format depends on `algorithm`. For real
    # ACT/DiffusionPolicy trainers this would typically be a checkpoint
    # file path rather than an in-memory object.
    payload: Any = None


class BasePolicyTrainer(ABC):
    """Interface for training + serving an imitation-learning policy."""

    @abstractmethod
    async def train(
        self, episodes: List[DemonstrationEpisode], config: PolicyTrainingConfig
    ) -> PolicyArtifact:
        pass

    @abstractmethod
    async def predict(self, artifact: PolicyArtifact, observation: Dict[str, float]) -> Dict[str, float]:
        """Given a current observation (e.g. joint state), return the predicted action (joint target)."""
        pass

    @abstractmethod
    async def save(self, artifact: PolicyArtifact, path: str) -> None:
        pass

    @abstractmethod
    async def load(self, path: str) -> PolicyArtifact:
        pass


ObservationActionPair = Tuple[Dict[str, float], Dict[str, float]]


def _euclidean_distance(a: Dict[str, float], b: Dict[str, float]) -> float:
    """Distance over keys common to both dicts. Infinite if no overlap (never matched)."""
    common = set(a) & set(b)
    if not common:
        return math.inf
    return math.sqrt(sum((a[k] - b[k]) ** 2 for k in common))


class NearestNeighborPolicyTrainer(BasePolicyTrainer):
    """
    Non-parametric behavior-cloning baseline: "training" stores every
    consecutive (state_t, action_t+1) pair from the demonstration
    episodes; "predicting" returns the action of the stored pair whose
    state is closest (Euclidean, over overlapping joint names) to the
    query observation.
    """

    def _extract_pairs(self, episodes: List[DemonstrationEpisode]) -> List[ObservationActionPair]:
        pairs: List[ObservationActionPair] = []
        for episode in episodes:
            frames = episode.frames
            for i in range(len(frames) - 1):
                obs = frames[i].robot_joint_targets
                action = frames[i + 1].robot_joint_targets
                if obs and action:
                    pairs.append((dict(obs), dict(action)))
        return pairs

    async def train(
        self, episodes: List[DemonstrationEpisode], config: PolicyTrainingConfig
    ) -> PolicyArtifact:
        pairs = self._extract_pairs(episodes)
        logger.info(f"[NearestNeighborPolicyTrainer] Trained on {len(pairs)} pairs from {len(episodes)} episode(s)")
        return PolicyArtifact(
            model_name=config.extra.get("model_name", "nn_baseline"),
            version=config.extra.get("version", str(int(time.time()))),
            algorithm="nearest_neighbor",
            metrics={"num_pairs": len(pairs), "num_episodes": len(episodes)},
            payload=pairs,
        )

    async def predict(self, artifact: PolicyArtifact, observation: Dict[str, float]) -> Dict[str, float]:
        pairs: List[ObservationActionPair] = artifact.payload or []
        if not pairs:
            raise ValueError("PolicyArtifact has no training pairs -- was it trained on non-empty episodes?")

        best_action: Optional[Dict[str, float]] = None
        best_distance = math.inf
        for obs, action in pairs:
            dist = _euclidean_distance(obs, observation)
            if dist < best_distance:
                best_distance, best_action = dist, action

        if best_action is None or math.isinf(best_distance):
            raise ValueError("No training pair shares an observation key with the query -- cannot predict")
        return dict(best_action)

    async def save(self, artifact: PolicyArtifact, path: str) -> None:
        data = {
            "model_name": artifact.model_name,
            "version": artifact.version,
            "algorithm": artifact.algorithm,
            "metrics": artifact.metrics,
            "created_at": artifact.created_at,
            "payload": [[obs, action] for obs, action in (artifact.payload or [])],
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f)

    async def load(self, path: str) -> PolicyArtifact:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        payload: List[ObservationActionPair] = [(pair[0], pair[1]) for pair in data.get("payload", [])]
        return PolicyArtifact(
            model_name=data["model_name"],
            version=data["version"],
            algorithm=data["algorithm"],
            metrics=data.get("metrics", {}),
            created_at=data.get("created_at", time.time()),
            payload=payload,
        )
