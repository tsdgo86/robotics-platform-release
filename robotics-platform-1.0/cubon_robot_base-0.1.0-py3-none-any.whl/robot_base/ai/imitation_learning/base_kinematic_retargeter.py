"""
Base Kinematic Retargeter — Human Motion → Robot Joint Space
==================================================================
Interface cho bước 2 của pipeline Video-to-Action (xem
`docs/robotis_implementation/implementation_plan_v2` mục 2): ánh xạ
chuyển động người (từ Human Pose Estimation -- MediaPipe/SMPL/...) sang
góc khớp robot (Humanoid hoặc Arm).

`AnalyticLimbRetargeter` là reference implementation dependency-free
(pure Python, không cần pinocchio/MoveIt) dùng hình học vector cơ bản
(góc giữa 2 đoạn xương qua tích vô hướng) để suy ra góc khớp gần đúng
từ 3 keypoint liên tiếp (vai-khuỷu-cổ tay, hông-gối-mắt cá). Đây CHỦ ĐÍCH
là một baseline đơn giản, không phải giải pháp retargeting chính xác --
mục 5 "Open Questions" của implementation_plan_v2 đã nêu rõ việc tích
hợp thư viện retargeting chuẩn (pinocchio/MoveIt) là quyết định cần
người dùng xác nhận trước.

Quy ước góc:
- Góc khuỷu tay/đầu gối (elbow/knee) là góc TRONG tại khớp, đo bằng
  vector từ khớp đến 2 khớp lân cận (vd elbow->shoulder, elbow->wrist):
  pi rad = tay/chân duỗi thẳng, 0 rad = gập hết cỡ. Đây là góc thô, có
  thể lệch so với "0 rad" tham chiếu thật của robot -- cần hiệu chỉnh
  offset theo robot cụ thể trước khi dùng làm training target thật.
- Góc vai/hông (shoulder_pitch/hip_pitch) là góc nâng (elevation) của
  đoạn xương trên (upper arm / thigh) so với trục thẳng đứng hướng
  xuống (0,0,-1) -- xấp xỉ 1-DOF, KHÔNG tách được roll/yaw từ 3 điểm.

Tên khớp xuất ra khớp chính xác với robot_base.core.humanoid_kinematic_chain
.DEFAULT_HUMANOID_CHAIN (left_shoulder_pitch, left_elbow, left_hip_pitch,
left_knee, ...) để RetargetedFrame.joint_angles có thể feed thẳng vào
compute_joint_positions()/HumanoidSafetyRuntime mà không cần mapping.
"""

from __future__ import annotations

import logging
import math
from abc import ABC, abstractmethod
from typing import List, Optional, Tuple

from robot_base.ai.imitation_learning.demonstration import HumanPoseFrame, RetargetedFrame

logger = logging.getLogger(__name__)

Point3 = Tuple[float, float, float]

DOWN_AXIS: Point3 = (0.0, 0.0, -1.0)


class BaseKinematicRetargeter(ABC):
    """Interface for human-pose -> robot-joint-space retargeting."""

    @abstractmethod
    def retarget(self, pose: HumanPoseFrame) -> RetargetedFrame:
        """Map one human pose frame to one robot joint-angle target."""
        pass

    def retarget_episode(self, poses: List[HumanPoseFrame]) -> List[RetargetedFrame]:
        """Retarget a whole sequence -- default implementation loops retarget()."""
        return [self.retarget(p) for p in poses]


# ── Pure-Python vector helpers (no numpy dependency, matches robot_base.core.kinematics) ──

def _sub(a: Point3, b: Point3) -> Point3:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _dot(a: Point3, b: Point3) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _norm(a: Point3) -> float:
    return math.sqrt(_dot(a, a))


def _angle_between(a: Point3, b: Point3) -> Optional[float]:
    """Angle in radians between two vectors, or None if either is ~zero-length."""
    na, nb = _norm(a), _norm(b)
    if na < 1e-9 or nb < 1e-9:
        return None
    cos_theta = _dot(a, b) / (na * nb)
    cos_theta = max(-1.0, min(1.0, cos_theta))  # clamp for float error
    return math.acos(cos_theta)


class AnalyticLimbRetargeter(BaseKinematicRetargeter):
    """
    Geometric baseline retargeter for a 2-limb-pair humanoid (arms +
    legs), keyed off 3-point limb chains (shoulder-elbow-wrist,
    hip-knee-ankle) per side.

    Missing keypoints for a limb (occlusion) simply omit that limb's
    joints from the output frame -- no NaN/guessed values.
    """

    def __init__(self, sides: Tuple[str, ...] = ("left", "right")) -> None:
        self._sides = sides

    def retarget(self, pose: HumanPoseFrame) -> RetargetedFrame:
        joint_angles = {}
        for side in self._sides:
            joint_angles.update(self._retarget_arm(side, pose))
            joint_angles.update(self._retarget_leg(side, pose))
        return RetargetedFrame(timestamp=pose.timestamp, joint_angles=joint_angles)

    def _retarget_arm(self, side: str, pose: HumanPoseFrame) -> dict:
        return self._retarget_limb_pair(
            pose,
            proximal=f"{side}_shoulder", mid=f"{side}_elbow", distal=f"{side}_wrist",
            elevation_key=f"{side}_shoulder_pitch", flexion_key=f"{side}_elbow",
        )

    def _retarget_leg(self, side: str, pose: HumanPoseFrame) -> dict:
        return self._retarget_limb_pair(
            pose,
            proximal=f"{side}_hip", mid=f"{side}_knee", distal=f"{side}_ankle",
            elevation_key=f"{side}_hip_pitch", flexion_key=f"{side}_knee",
        )

    def _retarget_limb_pair(
        self, pose: HumanPoseFrame, proximal: str, mid: str, distal: str,
        elevation_key: str, flexion_key: str,
    ) -> dict:
        kp = pose.keypoints
        if proximal not in kp or mid not in kp:
            return {}  # can't compute even the elevation angle

        upper_segment = _sub(kp[mid], kp[proximal])  # proximal -> mid (e.g. shoulder -> elbow)
        elevation = _angle_between(upper_segment, DOWN_AXIS)
        result = {}
        if elevation is not None:
            result[elevation_key] = elevation

        if distal in kp:
            v_to_proximal = _sub(kp[proximal], kp[mid])  # mid -> proximal
            v_to_distal = _sub(kp[distal], kp[mid])      # mid -> distal
            flexion = _angle_between(v_to_proximal, v_to_distal)
            if flexion is not None:
                result[flexion_key] = flexion

        return result
