"""
Base Video Processor — Video Ingestion & Frame Extraction
==============================================================
Interface cho bước 1 của pipeline Video-to-Action (xem
`docs/robotis_implementation/implementation_plan_v2` mục 2): nhận video
từ camera hoặc data lake, trích xuất frame để đưa vào Human Pose
Estimation (bước 2, BaseKinematicRetargeter).

Platform này KHÔNG decode video (không phụ thuộc opencv/ffmpeg trong
core) -- một concrete implementation thật (robotis_physical_ai, hoặc
factory_hacks) sẽ decode video thật và implement BaseVideoProcessor.
`FrameManifestVideoProcessor` dưới đây là reference implementation
dependency-free: nó ingest một MANIFEST frame đã được trích xuất sẵn
(vd. bằng ffmpeg ở bước tiền xử lý ngoài platform) thay vì tự decode --
đủ để test toàn bộ pipeline (ingestion -> retargeting -> training) mà
không cần cài opencv.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class VideoFrame:
    """One extracted frame -- a reference (path/URI), not a decoded array."""
    index: int
    timestamp_s: float
    image_ref: str
    metadata: Dict[str, Any] = field(default_factory=dict)


class BaseVideoProcessor(ABC):
    """Interface for video ingestion + frame extraction."""

    @abstractmethod
    async def load(self, source: str) -> None:
        """Open/prepare a video source (file path, URI, or data-lake key)."""
        pass

    @abstractmethod
    async def extract_frames(self) -> List[VideoFrame]:
        """Return extracted frames in timestamp order."""
        pass

    @abstractmethod
    async def close(self) -> None:
        """Release any resources held by load()."""
        pass


class FrameManifestVideoProcessor(BaseVideoProcessor):
    """
    Dependency-free BaseVideoProcessor backed by a pre-extracted frame
    manifest: a list of {"timestamp_s": float, "image_ref": str} dicts
    (e.g. produced by an external `ffmpeg -vf fps=...` extraction step).

    Usage
    -----
    processor = FrameManifestVideoProcessor()
    await processor.load(manifest_path_or_key)  # no-op here; manifest is
                                                  # supplied directly via
                                                  # set_manifest() in tests/
                                                  # simple pipelines
    processor.set_manifest([{"timestamp_s": 0.0, "image_ref": "f0.jpg"}, ...])
    frames = await processor.extract_frames()
    """

    def __init__(self) -> None:
        self._source: Optional[str] = None
        self._manifest: List[Dict[str, Any]] = []
        self._loaded = False

    def set_manifest(self, manifest: List[Dict[str, Any]]) -> None:
        """Directly supply the frame manifest (bypasses load())."""
        self._manifest = list(manifest)

    async def load(self, source: str) -> None:
        self._source = source
        self._loaded = True
        logger.info(f"[FrameManifestVideoProcessor] Loaded source='{source}'")

    async def extract_frames(self) -> List[VideoFrame]:
        if not self._loaded and not self._manifest:
            raise RuntimeError("load() must be called (or set_manifest() used) before extract_frames()")
        frames = [
            VideoFrame(
                index=i,
                timestamp_s=float(entry["timestamp_s"]),
                image_ref=str(entry["image_ref"]),
                metadata=dict(entry.get("metadata", {})),
            )
            for i, entry in enumerate(sorted(self._manifest, key=lambda e: e["timestamp_s"]))
        ]
        return frames

    async def close(self) -> None:
        self._loaded = False
        self._source = None
