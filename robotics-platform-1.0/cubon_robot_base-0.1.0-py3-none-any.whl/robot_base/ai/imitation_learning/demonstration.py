"""
Demonstration DTOs — Video/Teleop-to-Action Dataset Schema
==============================================================
DTO chung cho toàn bộ pipeline Imitation Learning (Video-to-Action) mô
tả trong `docs/robotis_implementation/implementation_plan_v2` mục 2:
video ingestion -> kinematic retargeting -> policy training, và cho
`robot_base/teleoperation` (thu thập dữ liệu qua teleop thay vì video).

Một `DemonstrationEpisode` là một lần trình diễn (video một người thao
tác, hoặc một phiên teleop) đã được chuẩn hoá thành chuỗi
`DemonstrationFrame` -- input trực tiếp cho `BasePolicyTrainer.train()`.

`sensor_data` trên mỗi frame (force/torque/motion trajectory) phục vụ
đồng thời checklist H-067 (thu thập dữ liệu AI) và yêu cầu H3 ("quantify
expert know-how... force, torque, motion trajectory").
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field

Point3 = Tuple[float, float, float]


class HumanPoseFrame(BaseModel):
    """
    3D human keypoints at one timestamp, from a Human Pose Estimation
    model (MediaPipe/SMPL/...) -- input to BaseKinematicRetargeter.

    keypoints: keypoint name -> (x, y, z) in a consistent reference
    frame (e.g. hip-centered, meters). Expected names for the shipped
    AnalyticLimbRetargeter: {side}_shoulder, {side}_elbow, {side}_wrist,
    {side}_hip, {side}_knee, {side}_ankle for side in (left, right).
    Not all keypoints need be present every frame (occlusion) -- missing
    limbs are simply skipped by the retargeter.
    """
    timestamp: float
    keypoints: Dict[str, Point3]
    language_instruction: Optional[str] = None  # VLM text prompt paired with this frame


class RetargetedFrame(BaseModel):
    """Output of BaseKinematicRetargeter.retarget() -- robot joint-space target."""
    timestamp: float
    joint_angles: Dict[str, float]  # radians, keyed by robot joint name


class DemonstrationFrame(BaseModel):
    """
    One synchronized sample in a demonstration episode. Produced either
    by BaseKinematicRetargeter (video source) or by
    robot_base.teleoperation.TeleopDataCollector (teleop source).
    """
    timestamp: float
    robot_joint_targets: Dict[str, float] = Field(default_factory=dict)
    human_pose: Optional[HumanPoseFrame] = None
    image_ref: Optional[str] = None          # path/URI to the associated camera frame
    language_instruction: Optional[str] = None
    sensor_data: Dict[str, Any] = Field(default_factory=dict)  # force_n, torque_nm, end_effector_pose, ...


class DemonstrationEpisode(BaseModel):
    """One full demonstration (one video clip, or one teleop session)."""
    episode_id: str
    robot_id: str
    task_name: str
    source: str = "teleop"  # teleop | video | sim
    frames: List[DemonstrationFrame] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)

    def duration_s(self) -> float:
        if len(self.frames) < 2:
            return 0.0
        return self.frames[-1].timestamp - self.frames[0].timestamp

    def to_json(self) -> str:
        return self.model_dump_json()
