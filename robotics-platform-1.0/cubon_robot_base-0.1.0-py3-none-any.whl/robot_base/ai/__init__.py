"""robot_base.ai -- AI capability modules shared across robots (imitation learning, ...)."""
