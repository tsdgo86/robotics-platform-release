from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from robot_base.core.base_event import BaseEvent


class BaseDriftMonitor(ABC):
    """Monitor model drift & trigger retraining."""

    @abstractmethod
    async def calculate_current_metrics(self, recent_events: List[BaseEvent]) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def detect_model_drift(self) -> bool:
        pass

    @abstractmethod
    async def recommend_retraining(self) -> Optional[str]:
        pass
