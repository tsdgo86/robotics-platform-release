from abc import ABC, abstractmethod
from typing import Dict, Any, List
from robot_base.core.base_event import BaseEvent


class BaseDataEngine(ABC):
    """MLOps Data Engine -- shared across all 4 robots."""

    @abstractmethod
    async def log_event(self, event: BaseEvent) -> None:
        """Log event."""
        pass

    @abstractmethod
    async def collect_sensor_sample(self, sample: Dict[str, Any]) -> None:
        """Collect sensor data for training."""
        pass

    @abstractmethod
    async def create_dataset_version(self, version_name: str) -> str:
        pass

    @abstractmethod
    async def register_model(self, model_name: str, version: str, metrics: Dict[str, Any]) -> None:
        pass

    @abstractmethod
    async def evaluate_model(self, model_name: str, test_dataset: str) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def prepare_model_update(self, model_name: str) -> bool:
        """Prepare OTA model update."""
        pass
