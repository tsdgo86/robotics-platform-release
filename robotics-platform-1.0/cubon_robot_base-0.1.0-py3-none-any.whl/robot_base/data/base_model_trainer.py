from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from robot_base.core.base_event import BaseEvent


class BaseModelTrainer(ABC):
    """Base for training policy / vision model."""

    @abstractmethod
    async def train(self, dataset_id: str, config: Dict[str, Any]) -> str:
        """Return model_version_id."""
        pass

    @abstractmethod
    async def evaluate(self, model_id: str, validation_set: str) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def export_model(self, model_id: str, target_format: str) -> str:
        """Export to ONNX, TensorRT, etc."""
        pass


class BaseDriftMonitor(ABC):
    """Monitor model drift & trigger retraining."""

    @abstractmethod
    async def calculate_current_metrics(self, recent_events: List[BaseEvent]) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def detect_model_drift(self) -> bool:
        pass

    @abstractmethod
    async def recommend_retraining(self) -> Optional[str]:
        pass


class BaseDatasetManager(ABC):
    """Dataset versioning and metadata management."""

    @abstractmethod
    async def get_dataset_uri(self, dataset_id: str) -> str:
        pass
