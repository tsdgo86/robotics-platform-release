from abc import ABC, abstractmethod


class BaseDatasetManager(ABC):
    """Dataset versioning and metadata management."""

    @abstractmethod
    async def get_dataset_uri(self, dataset_id: str) -> str:
        pass
