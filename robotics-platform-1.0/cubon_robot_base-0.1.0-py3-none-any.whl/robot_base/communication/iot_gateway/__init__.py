from robot_base.communication.iot_gateway.opcua_conversion import opcua_values_to_metrics
from robot_base.communication.iot_gateway.modbus_conversion import (
    RegisterSpec,
    decode_register_value,
    decode_registers,
)
from robot_base.communication.iot_gateway.mqtt_conversion import (
    DEFAULT_TOPIC_TEMPLATE,
    sensor_data_to_mqtt_payload,
    mqtt_payload_to_sensor_data,
)

__all__ = [
    "opcua_values_to_metrics",
    "RegisterSpec",
    "decode_register_value",
    "decode_registers",
    "DEFAULT_TOPIC_TEMPLATE",
    "sensor_data_to_mqtt_payload",
    "mqtt_payload_to_sensor_data",
]

# NOTE: the live client classes (opcua_client.OPCUAGatewayClient,
# modbus_client.ModbusGatewayClient, mqtt_bridge.MQTTBridge) are
# intentionally NOT imported here -- they require external SDKs
# (asyncua / pymodbus / paho-mqtt respectively) that most of this
# platform's tests and tooling run without. Import them directly from
# their modules on a host/container that has the SDK installed. Mirrors
# robot_base/communication/dds/__init__.py's handling of the rclpy Node
# bridges.
