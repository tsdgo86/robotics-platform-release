"""
OPC-UA Gateway Client — Legacy PLC/IPC Connectivity (D1)
=============================================================
Polls a fixed set of OPC-UA node IDs on an interval and exposes the
latest reading as a metrics dict (ready for
robot_base.core.health_monitor.HealthMonitor.record_many() or
forwarding upstream via mqtt_bridge.MQTTBridge.publish_telemetry()).

REQUIRES `asyncua` (pip install asyncua). NOT imported from
robot_base.communication.iot_gateway.__init__ (see NOTE there) --
mirrors how robot_base/communication/dds/ros2_joint_state_bridge.py
requires rclpy and is imported directly from its module, not the
package __init__. This module has NOT been run against a real OPC-UA
server in this session -- review it against your actual server/gateway
(e.g. Kepware, Ignition, or a native OPC-UA-capable PLC) before trusting
it in production.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Dict, Optional

from asyncua import Client  # type: ignore[import-not-found]

from robot_base.communication.iot_gateway.opcua_conversion import opcua_values_to_metrics

logger = logging.getLogger(__name__)

DEFAULT_POLL_INTERVAL_S = 1.0


class OPCUAGatewayClient:
    """
    node_ids: {platform_name: opcua_node_id_string}, e.g.
        {"oven_temperature_c": "ns=2;s=Channel1.Device1.Temp"}
    Raw values are read keyed by platform_name already, so no further
    name_map is needed at the opcua_values_to_metrics() call site.
    """

    def __init__(
        self,
        endpoint_url: str,
        node_ids: Dict[str, str],
        poll_interval_s: float = DEFAULT_POLL_INTERVAL_S,
    ) -> None:
        self._endpoint_url = endpoint_url
        self._node_ids = node_ids
        self._poll_interval_s = poll_interval_s
        self._client: Optional[Client] = None
        self._latest: Dict[str, float] = {}
        self._latest_wall_time: float = 0.0

    async def connect(self) -> None:
        self._client = Client(url=self._endpoint_url)
        await self._client.connect()
        logger.info(f"[OPCUAGatewayClient] Connected to {self._endpoint_url}")

    async def disconnect(self) -> None:
        if self._client is not None:
            await self._client.disconnect()
            self._client = None

    async def poll_once(self) -> Dict[str, float]:
        if self._client is None:
            raise RuntimeError("connect() must be called before poll_once()")
        raw_values: Dict[str, Any] = {}
        for platform_name, node_id in self._node_ids.items():
            node = self._client.get_node(node_id)
            raw_values[platform_name] = await node.read_value()
        self._latest = opcua_values_to_metrics(raw_values)
        self._latest_wall_time = time.time()
        return dict(self._latest)

    async def run(self) -> None:
        """Background polling loop -- cancel the task to stop."""
        try:
            while True:
                await self.poll_once()
                await asyncio.sleep(self._poll_interval_s)
        except asyncio.CancelledError:
            pass

    def get_latest(self) -> Dict[str, float]:
        return dict(self._latest)
