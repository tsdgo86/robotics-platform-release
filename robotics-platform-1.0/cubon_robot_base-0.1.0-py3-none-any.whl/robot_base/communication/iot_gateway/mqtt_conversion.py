"""
MQTT Payload Conversion — Pure, paho-mqtt-independent
============================================================
D1 ("Low-Cost Connectivity for Non-IPC Legacy Equipment") -- final leg
of the "PLC legacy -> edge gateway (RPi/ESP32) -> MQTT/Node-RED ->
server" chain from implementation_plan_v2 mục D1. This module only
builds/parses the MQTT topic + JSON payload -- no network I/O, no
paho-mqtt import, so it's unit testable on the host. See mqtt_bridge.py
for the actual paho-mqtt client (NOTE: not exported from __init__.py,
requires `paho-mqtt` installed).
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

DEFAULT_TOPIC_TEMPLATE = "robotics/{robot_id}/telemetry"


def sensor_data_to_mqtt_payload(
    topic_template: str,
    robot_id: str,
    sensor_data: Dict[str, Any],
    timestamp: Optional[float] = None,
) -> Tuple[str, bytes]:
    """
    Build (topic, payload_bytes) for publishing `sensor_data` for
    `robot_id`. topic_template must contain a `{robot_id}` placeholder
    (e.g. DEFAULT_TOPIC_TEMPLATE).
    """
    topic = topic_template.format(robot_id=robot_id)
    envelope = {
        "robot_id": robot_id,
        "timestamp": timestamp if timestamp is not None else time.time(),
        "data": sensor_data,
    }
    payload = json.dumps(envelope).encode("utf-8")
    return topic, payload


def mqtt_payload_to_sensor_data(payload: bytes) -> Dict[str, Any]:
    """
    Parse an MQTT message payload (JSON, as produced by
    sensor_data_to_mqtt_payload or a compatible edge device) back into
    a plain dict.

    Returns {} on malformed payload (fail-soft, logged) rather than
    raising -- this is telemetry ingestion from a flaky edge gateway,
    not a safety-critical path; one corrupt message should not crash
    the subscriber loop.
    """
    try:
        decoded = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        logger.warning(f"[MQTTConversion] Malformed payload, dropped: {e}")
        return {}
    if not isinstance(decoded, dict):
        logger.warning(f"[MQTTConversion] Payload is not a JSON object, dropped: {decoded!r}")
        return {}
    return decoded
