"""
MQTT Bridge — Edge Gateway Uplink (D1)
===========================================
Publishes telemetry (from OPCUAGatewayClient/ModbusGatewayClient, or
directly from HealthMonitor) to an MQTT broker, and/or subscribes to
inbound command topics -- the final leg of the "legacy PLC -> edge
gateway (Raspberry Pi/ESP32) -> MQTT/Node-RED -> server" chain from
implementation_plan_v2 mục D1.

REQUIRES `paho-mqtt` (pip install paho-mqtt). NOT imported from
robot_base.communication.iot_gateway.__init__ (see NOTE there). This
module has NOT been run against a real broker in this session -- review
it before trusting it in production.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional

import paho.mqtt.client as mqtt  # type: ignore[import-not-found]

from robot_base.communication.iot_gateway.mqtt_conversion import (
    DEFAULT_TOPIC_TEMPLATE,
    mqtt_payload_to_sensor_data,
    sensor_data_to_mqtt_payload,
)

logger = logging.getLogger(__name__)

DEFAULT_MQTT_PORT = 1883

OnMessageCallback = Callable[[str, Dict[str, Any]], None]


class MQTTBridge:
    def __init__(
        self,
        broker_host: str,
        broker_port: int = DEFAULT_MQTT_PORT,
        topic_template: str = DEFAULT_TOPIC_TEMPLATE,
        on_message: Optional[OnMessageCallback] = None,
    ) -> None:
        self._broker_host = broker_host
        self._broker_port = broker_port
        self._topic_template = topic_template
        self._on_message = on_message
        self._client = mqtt.Client()
        self._client.on_message = self._handle_message

    def connect(self) -> None:
        self._client.connect(self._broker_host, self._broker_port)
        self._client.loop_start()
        logger.info(f"[MQTTBridge] Connected to {self._broker_host}:{self._broker_port}")

    def disconnect(self) -> None:
        self._client.loop_stop()
        self._client.disconnect()

    def publish_telemetry(self, robot_id: str, sensor_data: Dict[str, Any]) -> None:
        topic, payload = sensor_data_to_mqtt_payload(self._topic_template, robot_id, sensor_data)
        self._client.publish(topic, payload)

    def subscribe(self, topic: str) -> None:
        self._client.subscribe(topic)

    def _handle_message(self, _client: Any, _userdata: Any, msg: Any) -> None:
        data = mqtt_payload_to_sensor_data(msg.payload)
        if self._on_message is not None:
            self._on_message(msg.topic, data)
