"""
Modbus Gateway Client — Legacy PLC Connectivity (D1)
=========================================================
Polls holding registers from a Modbus TCP PLC (the cheapest, most
common protocol for genuinely legacy Non-IPC equipment -- the D1
challenge's primary target) and decodes them via
modbus_conversion.decode_registers() according to a configured
RegisterSpec map.

REQUIRES `pymodbus` (pip install pymodbus). NOT imported from
robot_base.communication.iot_gateway.__init__ (see NOTE there). This
module has NOT been run against a real Modbus PLC in this session --
review it against your actual PLC (register addressing/byte order vary
by vendor) before trusting it in production.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Dict, Optional

from pymodbus.client import AsyncModbusTcpClient  # type: ignore[import-not-found]

from robot_base.communication.iot_gateway.modbus_conversion import RegisterSpec, decode_registers

logger = logging.getLogger(__name__)

DEFAULT_MODBUS_PORT = 502
DEFAULT_POLL_INTERVAL_S = 1.0


class ModbusGatewayClient:
    def __init__(
        self,
        host: str,
        register_map: Dict[str, RegisterSpec],
        port: int = DEFAULT_MODBUS_PORT,
        unit_id: int = 1,
        poll_interval_s: float = DEFAULT_POLL_INTERVAL_S,
    ) -> None:
        self._host = host
        self._port = port
        self._unit_id = unit_id
        self._register_map = register_map
        self._poll_interval_s = poll_interval_s
        self._client: Optional[AsyncModbusTcpClient] = None
        self._latest: Dict[str, float] = {}

    async def connect(self) -> None:
        self._client = AsyncModbusTcpClient(self._host, port=self._port)
        await self._client.connect()
        logger.info(f"[ModbusGatewayClient] Connected to {self._host}:{self._port}")

    async def disconnect(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    async def poll_once(self) -> Dict[str, float]:
        if self._client is None:
            raise RuntimeError("connect() must be called before poll_once()")
        raw: Dict[int, int] = {}
        for spec in self._register_map.values():
            result = await self._client.read_holding_registers(
                spec.address, count=spec.register_count, slave=self._unit_id
            )
            if result.isError():
                logger.warning(f"[ModbusGatewayClient] Read error at address={spec.address}: {result}")
                continue
            for i, reg_value in enumerate(result.registers):
                raw[spec.address + i] = reg_value
        self._latest = decode_registers(raw, self._register_map)
        return dict(self._latest)

    async def run(self) -> None:
        """Background polling loop -- cancel the task to stop."""
        try:
            while True:
                await self.poll_once()
                await asyncio.sleep(self._poll_interval_s)
        except asyncio.CancelledError:
            pass

    def get_latest(self) -> Dict[str, float]:
        return dict(self._latest)
