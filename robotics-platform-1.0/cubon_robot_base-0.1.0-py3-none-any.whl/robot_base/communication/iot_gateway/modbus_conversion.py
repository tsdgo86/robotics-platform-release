"""
Modbus Register Decoding — Pure, pymodbus-independent
============================================================
D1 ("Low-Cost Connectivity for Non-IPC Legacy Equipment") yêu cầu đọc
dữ liệu từ PLC Modbus legacy -- Modbus chỉ trả về các thanh ghi 16-bit
thô (holding/input registers), không có kiểu dữ liệu; bên đọc phải tự
biết cách decode (uint16, int16, hay float32 gộp 2 thanh ghi theo
IEEE-754) theo tài liệu của từng PLC.

Module này chỉ decode giá trị thô -> Python value, dùng `struct` (thư
viện chuẩn, không cần pymodbus) nên unit test được trên host bình
thường. Việc đọc thanh ghi qua mạng thật nằm ở modbus_client.py (cần
pymodbus, xem NOTE trong __init__.py) -- theo đúng pattern tách
"conversion thuần" / "bridge cần SDK ngoài" đã dùng cho
robot_base/communication/dds (joint_state_conversion.py vs
ros2_joint_state_bridge.py).
"""

from __future__ import annotations

import logging
import struct
from dataclasses import dataclass
from typing import Dict, Literal

logger = logging.getLogger(__name__)

Encoding = Literal["uint16", "int16", "float32"]


@dataclass(frozen=True)
class RegisterSpec:
    """
    One tag in a PLC's register map.

    address        : starting Modbus register address (0-based, per the
                      PLC's documentation -- Modbus addressing conventions
                      vary by vendor, this module does not attempt to
                      guess/offset it).
    encoding        : "uint16" | "int16" (1 register) | "float32" (2
                      registers, IEEE-754).
    byte_order      : "big" | "little" -- byte order WITHIN each 16-bit
                      register (most PLCs: big-endian/"AB").
    word_order      : "big" | "little" -- order of the two registers for
                      float32 (big = high word first/"ABCD", common on
                      Siemens/Modicon; little = low word first/"CDAB",
                      common on Schneider/some Allen-Bradley).
    scale           : multiply the decoded raw value by this (e.g. PLC
                      stores tenths-of-a-degree as int16 -> scale=0.1).
    """
    address: int
    encoding: Encoding = "uint16"
    byte_order: Literal["big", "little"] = "big"
    word_order: Literal["big", "little"] = "big"
    scale: float = 1.0

    @property
    def register_count(self) -> int:
        return 2 if self.encoding == "float32" else 1


def decode_register_value(registers: list, spec: RegisterSpec) -> float:
    """
    Decode `spec.register_count` raw 16-bit register values (ints, as
    returned by a Modbus read) into a Python float, per `spec.encoding`.
    """
    if len(registers) != spec.register_count:
        raise ValueError(
            f"RegisterSpec expects {spec.register_count} register(s) for "
            f"encoding='{spec.encoding}', got {len(registers)}"
        )

    endian = ">" if spec.byte_order == "big" else "<"

    if spec.encoding == "uint16":
        raw = struct.pack(f"{endian}H", registers[0] & 0xFFFF)
        value = struct.unpack(f"{endian}H", raw)[0]
    elif spec.encoding == "int16":
        raw = struct.pack(f"{endian}H", registers[0] & 0xFFFF)
        value = struct.unpack(f"{endian}h", raw)[0]
    elif spec.encoding == "float32":
        words = registers if spec.word_order == "big" else list(reversed(registers))
        raw = struct.pack(f"{endian}HH", words[0] & 0xFFFF, words[1] & 0xFFFF)
        value = struct.unpack(f"{endian}f", raw)[0]
    else:
        raise ValueError(f"Unsupported encoding: {spec.encoding}")

    return float(value) * spec.scale


def decode_registers(
    raw: Dict[int, int], register_map: Dict[str, RegisterSpec]
) -> Dict[str, float]:
    """
    Decode a flat {register_address: raw_value} read into
    {tag_name: decoded_value} per `register_map`.

    Tags whose required addresses are not all present in `raw` are
    skipped (not raised) -- a partial Modbus read (e.g. timeout mid-poll)
    should degrade to fewer metrics, not fail the whole batch. This is
    telemetry data (feeds HealthMonitor), not a safety check, so
    fail-soft is the right default here (contrast with
    robot_base.safety's fail-closed convention for actual safety gates).
    """
    result: Dict[str, float] = {}
    for tag_name, spec in register_map.items():
        addresses = range(spec.address, spec.address + spec.register_count)
        if not all(addr in raw for addr in addresses):
            logger.warning(f"[ModbusConversion] Incomplete read for tag '{tag_name}' -- skipped")
            continue
        registers = [raw[addr] for addr in addresses]
        try:
            result[tag_name] = decode_register_value(registers, spec)
        except (struct.error, ValueError) as e:
            logger.warning(f"[ModbusConversion] Failed to decode tag '{tag_name}': {e}")
    return result
