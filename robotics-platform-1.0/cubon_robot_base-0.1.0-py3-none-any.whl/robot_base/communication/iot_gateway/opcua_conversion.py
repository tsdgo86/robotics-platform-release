"""
OPC-UA Value Conversion — Pure, asyncua-independent
==========================================================
D1 ("Low-Cost Connectivity for Non-IPC Legacy Equipment") -- OPC-UA
nodes carry arbitrary variant types (bool/int/float/string/...) plus a
per-node quality/StatusCode. This module converts a raw
{tag_name: value} read (as returned by an OPC-UA client) into the flat
Dict[str, float] metrics shape robot_base.core.health_monitor.HealthMonitor
.record_many() expects -- so a legacy PLC's OPC-UA tags can feed
HealthMonitor directly.

Kept dependency-free (no asyncua) so it's unit testable on the host --
see opcua_client.py for the actual asyncua-based polling client (NOTE:
not exported from __init__.py, requires `asyncua` installed), mirroring
the split already used in robot_base/communication/dds (conversion vs
rclpy bridge).
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

GOOD_QUALITY = "Good"


def _to_float(value: Any) -> Optional[float]:
    """bool -> 0.0/1.0, int/float -> float, everything else -> None (not representable)."""
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if isinstance(value, (int, float)):
        return float(value)
    return None


def opcua_values_to_metrics(
    values: Dict[str, Any],
    quality: Optional[Dict[str, str]] = None,
    name_map: Optional[Dict[str, str]] = None,
) -> Dict[str, float]:
    """
    values    : {tag_name: raw_value} as read from OPC-UA nodes.
    quality   : optional {tag_name: quality_string} (OPC-UA StatusCode
                severity, e.g. "Good"/"Bad"/"Uncertain"). Tags with
                quality other than "Good" are excluded -- telemetry from
                a node the server itself flagged as untrustworthy should
                not silently enter the health/metrics pipeline.
    name_map  : optional {opcua_tag_name: platform_name} translation.

    Returns only numeric-convertible values. Non-numeric OPC-UA values
    (e.g. an enum string, a struct) are skipped with a warning -- they
    aren't representable in HealthMonitor's flat float metrics shape.
    """
    result: Dict[str, float] = {}
    for tag_name, raw_value in values.items():
        q = quality.get(tag_name) if quality else None
        if q is not None and q != GOOD_QUALITY:
            logger.warning(f"[OPCUAConversion] Tag '{tag_name}' has quality={q} -- skipped")
            continue

        numeric = _to_float(raw_value)
        if numeric is None:
            logger.warning(f"[OPCUAConversion] Tag '{tag_name}' value {raw_value!r} is not numeric -- skipped")
            continue

        translated = name_map.get(tag_name, tag_name) if name_map else tag_name
        result[translated] = numeric
    return result
