"""
ROS2 JointState Bridge — Real joint_positions for the Safety Runtimes
=========================================================================
ArmSafetyValidator/HumanoidSafetyRuntime's self-collision check
(_check_self_collision) and joint-limit checks have been ready to consume
sensor_data["joint_positions"] since they were written, but nothing in the
platform ever produced that data from a real robot -- it only existed in
tests as hand-written dicts.

This node subscribes to /joint_states (sensor_msgs/msg/JointState, the
standard ROS2 topic published by robot_state_publisher / ros2_control's
joint_state_broadcaster on virtually every ROS2 robot) and exposes the
latest reading as a sensor_data-shaped dict.

REQUIRES a ROS2 environment (rclpy, sensor_msgs) -- this module cannot be
imported or run outside one. It is meant to run inside the robotis-ai
container built from infrastructure/docker/Dockerfile.robotis (ROS2
Jazzy), not on the host Python used for the rest of this repo's tests.
Only joint_state_conversion.py's pure functions are unit tested in
robot_base/tests -- this file has NOT been executed against a live ROS2
graph in this session; review it against a real /joint_states publisher
before trusting it in production.
"""

from __future__ import annotations

import time
from typing import Any, Dict, Optional

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import JointState

from robot_base.communication.dds.joint_state_conversion import (
    joint_state_msg_to_sensor_data,
)

DEFAULT_JOINT_STATES_TOPIC = "/joint_states"
DEFAULT_STALE_TIMEOUT_S = 2.0  # matches ArmSafetyValidator._check_sensor_validity


class JointStateBridge(Node):
    """
    Subscribes to /joint_states and exposes the latest reading as a
    sensor_data dict compatible with ArmSafetyValidator/HumanoidSafetyRuntime.

    Usage (inside a running ROS2 process):

        rclpy.init()
        bridge = JointStateBridge(name_map=URDF_TO_PLATFORM_JOINT_NAMES)
        # spin in a background thread/executor, or rclpy.spin(bridge) if
        # this is the only node in the process
        ...
        sensor_data = {**other_sensor_data, **bridge.get_sensor_data()}
        result = await skill_runtime.execute(request, sensor_data=sensor_data)

    This class does not call SkillRuntime itself -- wiring a continuous
    sensor-read -> skill-execution loop is a separate orchestration
    decision (factory_hacks' BrainAgent currently takes sensor_data
    per-call, not from a live subscription), not part of this driver.

    name_map: real URDF joint names almost certainly differ from the
    platform's placeholder names (arm_safety_validator.DEFAULT_JOINT_LIMITS
    / humanoid_safety_runtime.DEFAULT_JOINT_LIMITS keys). Pass a
    {urdf_name: platform_name} dict to translate; unmapped joints pass
    through unchanged, which the safety checks will then simply not find
    a limit/link for -- fail-closed (missing data), not silently ignored
    for FK's strict mode, though _check_joint_limits (lenient by design)
    will skip them.
    """

    def __init__(
        self,
        topic: str = DEFAULT_JOINT_STATES_TOPIC,
        name_map: Optional[Dict[str, str]] = None,
        stale_timeout_s: float = DEFAULT_STALE_TIMEOUT_S,
        node_name: str = "joint_state_bridge",
    ) -> None:
        super().__init__(node_name)
        self._name_map = name_map
        self._stale_timeout_s = stale_timeout_s
        self._latest: Optional[Dict[str, Any]] = None
        self._latest_wall_time: float = 0.0
        self._message_count: int = 0

        self._subscription = self.create_subscription(
            JointState, topic, self._on_joint_state, qos_profile_sensor_data,
        )
        self.get_logger().info(f"JointStateBridge subscribed to '{topic}'")

    def _on_joint_state(self, msg: JointState) -> None:
        data = joint_state_msg_to_sensor_data(
            list(msg.name),
            list(msg.position),
            list(msg.velocity),
            list(msg.effort),
            name_map=self._name_map,
        )
        data["timestamp"] = time.time()
        self._latest = data
        self._latest_wall_time = time.time()
        self._message_count += 1

    def get_sensor_data(self) -> Dict[str, Any]:
        """
        Latest joint_positions/joint_velocities/joint_torques + timestamp,
        ready to merge into sensor_data.

        Returns {} if no message has arrived yet, or the latest one is
        older than stale_timeout_s -- never holds onto or fabricates data
        past its freshness window. The safety runtimes already fail
        closed on missing joint_positions, so an empty dict here correctly
        propagates into "insufficient data" rather than a silently stale
        "safe" reading.
        """
        if self._latest is None:
            return {}
        age = time.time() - self._latest_wall_time
        if age > self._stale_timeout_s:
            self.get_logger().warning(
                f"JointStateBridge: latest reading is {age:.1f}s old "
                f"(stale_timeout={self._stale_timeout_s}s) -- discarding"
            )
            return {}
        return dict(self._latest)

    def get_status(self) -> Dict[str, Any]:
        return {
            "message_count": self._message_count,
            "has_data": self._latest is not None,
            "age_s": (time.time() - self._latest_wall_time) if self._latest else None,
        }
