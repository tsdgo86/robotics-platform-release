"""
Image Message Conversion — Pure, ROS2-independent
======================================================
Converts sensor_msgs/msg/Image's raw byte buffer into a numpy array, using
the same manual reshape cv_bridge normally does -- avoided here so this
module doesn't need the cv_bridge ROS package (which brings its own OpenCV
binding requirements) on top of rclpy.

Unlike joint_state_conversion.py / imu_conversion.py, there is currently NO
consumer of raw camera frames anywhere in robot_base/safety -- the
checklist's camera items (H-019/020/021: head/chest/wrist depth cameras)
and factory_hacks' INSPECT_ZONE/DETECT_PPE skills expect a higher-level
"perception_adapter" object with detect_objects()/read_sensors() methods,
which is a separate, not-yet-built AI/perception pipeline, not a raw
sensor_data dict key. This module and ros2_image_bridge.py only deliver
the raw decoded frame + basic metadata (camera_online, width, height) --
they do NOT run any detection and do not claim to.
"""

from __future__ import annotations

from typing import Any, Dict

import numpy as np

# sensor_msgs/msg/Image encoding -> channel count, for the encodings this
# module supports. Anything else raises NotImplementedError rather than
# guessing a channel count and silently misinterpreting the byte buffer.
_ENCODING_CHANNELS: Dict[str, int] = {
    "rgb8": 3, "bgr8": 3, "rgba8": 4, "bgra8": 4,
    "mono8": 1, "8UC1": 1, "8UC3": 3, "8UC4": 4,
}


def image_msg_to_array(
    data: bytes, height: int, width: int, encoding: str, step: int
) -> np.ndarray:
    """
    data/height/width/encoding/step: the corresponding fields of a
    sensor_msgs/msg/Image message. `step` is the row stride in bytes,
    which may exceed width * channels (row padding) -- handled by
    reshaping to (height, step) first and slicing off the padding, the
    same technique cv_bridge uses internally.
    """
    if encoding not in _ENCODING_CHANNELS:
        raise NotImplementedError(
            f"Unsupported image encoding '{encoding}' "
            f"(supported: {sorted(_ENCODING_CHANNELS)})"
        )
    channels = _ENCODING_CHANNELS[encoding]
    expected_bytes = height * step
    arr = np.frombuffer(data, dtype=np.uint8)
    if arr.size < expected_bytes:
        raise ValueError(
            f"Image buffer too small: got {arr.size} bytes, "
            f"expected at least {expected_bytes} (height={height} * step={step})"
        )
    arr = arr[:expected_bytes].reshape(height, step)
    arr = arr[:, : width * channels].reshape(height, width, channels)
    if channels == 1:
        arr = arr.reshape(height, width)
    return arr


def image_msg_to_sensor_data(
    data: bytes, height: int, width: int, encoding: str, step: int
) -> Dict[str, Any]:
    """
    Returns {"camera_online": True, "camera_frame": <ndarray>, "camera_width",
    "camera_height", "camera_encoding"} -- NOT a "frames" list or any
    perception result. Wiring this into INSPECT_ZONE/DETECT_PPE's expected
    perception_adapter shape is separate, not-yet-built work.
    """
    array = image_msg_to_array(data, height, width, encoding, step)
    return {
        "camera_online": True,
        "camera_frame": array,
        "camera_width": width,
        "camera_height": height,
        "camera_encoding": encoding,
    }
