"""
IMU Message Conversion — Pure, ROS2-independent
====================================================
Converts sensor_msgs/msg/Imu's orientation quaternion + angular velocity +
linear acceleration into the sensor_data dict shape
HumanoidSafetyRuntime._check_balance already expects: "imu_roll_deg",
"imu_pitch_deg", "fall_detected" -- that check has been ready to consume
this since humanoid_safety_runtime.py was written, but nothing produced
real IMU data.

Kept dependency-free (no rclpy) on purpose, same split as
joint_state_conversion.py -- see ros2_imu_bridge.py for the actual rclpy
Node, which imports this module.
"""

from __future__ import annotations

import math
from typing import Any, Dict, Tuple

DEFAULT_FALL_TILT_DEG = 60.0  # well beyond HumanoidSafetyConfig.max_tilt_deg (25deg)


def quaternion_to_roll_pitch_yaw_deg(
    x: float, y: float, z: float, w: float
) -> Tuple[float, float, float]:
    """
    Standard ZYX (roll-pitch-yaw) Tait-Bryan extraction from a unit
    quaternion, in degrees. Matches the convention used by
    tf_transformations.euler_from_quaternion / ROS REP-103 (X forward,
    Y left, Z up): roll = rotation about X, pitch = about Y, yaw = about Z.
    """
    # roll (x-axis rotation)
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)

    # pitch (y-axis rotation) -- clamp for numerical safety at the poles
    sinp = 2.0 * (w * y - z * x)
    sinp = max(-1.0, min(1.0, sinp))
    pitch = math.asin(sinp)

    # yaw (z-axis rotation)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)

    return (math.degrees(roll), math.degrees(pitch), math.degrees(yaw))


def imu_msg_to_sensor_data(
    orientation_xyzw: Tuple[float, float, float, float],
    angular_velocity_xyz: Tuple[float, float, float] = (0.0, 0.0, 0.0),
    linear_acceleration_xyz: Tuple[float, float, float] = (0.0, 0.0, 0.0),
    fall_tilt_deg: float = DEFAULT_FALL_TILT_DEG,
) -> Dict[str, Any]:
    """
    orientation_xyzw: (x, y, z, w) from sensor_msgs/msg/Imu.orientation.
    angular_velocity_xyz / linear_acceleration_xyz: (x, y, z) from the
    message's respective fields, in the message's native units
    (rad/s, m/s^2) -- passed through unconverted.

    fall_detected is a SIMPLE orientation-threshold heuristic (tilt beyond
    fall_tilt_deg on either axis), not true fall detection -- real fall
    detection typically also uses acceleration-spike/free-fall detection
    and possibly gyro-rate analysis. This is intentionally conservative
    and documented as such, not a claim of full fall-detection coverage.
    """
    roll_deg, pitch_deg, yaw_deg = quaternion_to_roll_pitch_yaw_deg(*orientation_xyzw)
    ax, ay, az = angular_velocity_xyz
    lx, ly, lz = linear_acceleration_xyz
    return {
        "imu_roll_deg": roll_deg,
        "imu_pitch_deg": pitch_deg,
        "imu_yaw_deg": yaw_deg,
        "imu_angular_velocity": {"x": ax, "y": ay, "z": az},
        "imu_linear_acceleration": {"x": lx, "y": ly, "z": lz},
        "fall_detected": abs(roll_deg) > fall_tilt_deg or abs(pitch_deg) > fall_tilt_deg,
    }
