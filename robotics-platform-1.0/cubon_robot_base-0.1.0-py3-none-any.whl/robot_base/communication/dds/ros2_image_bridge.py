"""
ROS2 Image Bridge — Real Camera Frames (raw only, no perception)
======================================================================
Subscribes to a camera topic (sensor_msgs/msg/Image) and exposes the
latest decoded frame + basic metadata via get_sensor_data(). This does
NOT run object detection, PPE detection, or any inference -- there is no
consumer for that in robot_base/safety today, and factory_hacks'
INSPECT_ZONE/DETECT_PPE skills expect a "perception_adapter" object
(detect_objects()/read_sensors()), which is a separate AI pipeline this
driver does not attempt to be.

The checklist (H-019/020/021) describes THREE cameras (head, chest,
wrist) -- a real deployment needs one ImageBridge instance per camera
topic, each with its own node_name, not a single instance handling all
three.

REQUIRES a ROS2 environment (rclpy, sensor_msgs) -- same caveat as
ros2_joint_state_bridge.py / ros2_imu_bridge.py: cannot be imported or run
outside one. Only image_conversion.py's pure functions are unit tested in
robot_base/tests -- this file has NOT been executed against a live ROS2
graph or a real camera publisher in this session.
"""

from __future__ import annotations

import time
from typing import Any, Dict, Optional

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image

from robot_base.communication.dds.image_conversion import image_msg_to_sensor_data

DEFAULT_IMAGE_TOPIC = "/camera/image_raw"
DEFAULT_STALE_TIMEOUT_S = 2.0


class ImageBridge(Node):
    """
    Subscribes to a camera topic and exposes the latest decoded frame.

    Usage (inside a running ROS2 process, one instance per camera):

        rclpy.init()
        head_cam = ImageBridge(topic="/head_camera/image_raw", node_name="head_camera_bridge")
        # spin in a background thread/executor
        ...
        frame_data = head_cam.get_sensor_data()  # {} if no fresh frame

    This class does not run detection and does not call SkillRuntime --
    it is a raw sensor source only.
    """

    def __init__(
        self,
        topic: str = DEFAULT_IMAGE_TOPIC,
        stale_timeout_s: float = DEFAULT_STALE_TIMEOUT_S,
        node_name: str = "image_bridge",
    ) -> None:
        super().__init__(node_name)
        self._stale_timeout_s = stale_timeout_s
        self._latest: Optional[Dict[str, Any]] = None
        self._latest_wall_time: float = 0.0
        self._message_count: int = 0
        self._decode_error_count: int = 0

        self._subscription = self.create_subscription(
            Image, topic, self._on_image, qos_profile_sensor_data,
        )
        self.get_logger().info(f"ImageBridge subscribed to '{topic}'")

    def _on_image(self, msg: Image) -> None:
        try:
            data = image_msg_to_sensor_data(
                bytes(msg.data), msg.height, msg.width, msg.encoding, msg.step,
            )
        except (NotImplementedError, ValueError) as e:
            self._decode_error_count += 1
            self.get_logger().error(f"ImageBridge: failed to decode frame: {e}")
            return
        data["timestamp"] = time.time()
        self._latest = data
        self._latest_wall_time = time.time()
        self._message_count += 1

    def get_sensor_data(self) -> Dict[str, Any]:
        """
        Latest camera_online/camera_frame/camera_width/camera_height +
        timestamp, ready to merge into sensor_data.

        Returns {} if no frame has arrived/decoded yet, or the latest one
        is older than stale_timeout_s -- never returns a stale frame
        silently labeled camera_online=True.
        """
        if self._latest is None:
            return {}
        age = time.time() - self._latest_wall_time
        if age > self._stale_timeout_s:
            self.get_logger().warning(
                f"ImageBridge: latest frame is {age:.1f}s old "
                f"(stale_timeout={self._stale_timeout_s}s) -- discarding"
            )
            return {}
        return dict(self._latest)

    def get_status(self) -> Dict[str, Any]:
        return {
            "message_count": self._message_count,
            "decode_error_count": self._decode_error_count,
            "has_data": self._latest is not None,
            "age_s": (time.time() - self._latest_wall_time) if self._latest else None,
        }
