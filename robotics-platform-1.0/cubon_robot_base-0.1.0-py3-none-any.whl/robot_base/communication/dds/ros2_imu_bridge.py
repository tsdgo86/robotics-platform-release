"""
ROS2 IMU Bridge — Real Balance Data for HumanoidSafetyRuntime
==================================================================
HumanoidSafetyRuntime._check_balance() has been ready to consume
sensor_data["imu_roll_deg"] / "imu_pitch_deg" / "fall_detected" since it
was written, but nothing in the platform ever produced them from a real
sensor -- same situation joint_states/ros2_joint_state_bridge.py fixed for
joint_positions.

Subscribes to a standard IMU topic (sensor_msgs/msg/Imu; "/imu/data" is
the common convention used by imu_filter_madgwick, imu_complementary_filter,
and most IMU driver packages -- override `topic` if the robot uses
something else) and exposes the latest reading as a sensor_data-shaped dict.

REQUIRES a ROS2 environment (rclpy, sensor_msgs) -- see
ros2_joint_state_bridge.py's docstring for the same caveat: this cannot be
imported or run outside one (only inside e.g. the robotis-ai container).
Only imu_conversion.py's pure functions are unit tested in robot_base/tests
-- this file has NOT been executed against a live ROS2 graph in this
session; review it against a real IMU publisher before trusting it in
production.
"""

from __future__ import annotations

import time
from typing import Any, Dict, Optional

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Imu

from robot_base.communication.dds.imu_conversion import (
    DEFAULT_FALL_TILT_DEG,
    imu_msg_to_sensor_data,
)

DEFAULT_IMU_TOPIC = "/imu/data"
DEFAULT_STALE_TIMEOUT_S = 1.0  # tighter than joint_states -- balance is more time-critical


class ImuBridge(Node):
    """
    Subscribes to an IMU topic and exposes the latest reading as a
    sensor_data dict compatible with HumanoidSafetyRuntime.

    Usage (inside a running ROS2 process):

        rclpy.init()
        bridge = ImuBridge()
        # spin in a background thread/executor, or rclpy.spin(bridge) if
        # this is the only node in the process
        ...
        sensor_data = {**other_sensor_data, **bridge.get_sensor_data()}
        result = await skill_runtime.execute(request, sensor_data=sensor_data)

    Same orchestration caveat as JointStateBridge: this class does not
    call SkillRuntime itself, and factory_hacks' BrainAgent currently
    takes sensor_data per-call rather than from a live subscription.
    """

    def __init__(
        self,
        topic: str = DEFAULT_IMU_TOPIC,
        fall_tilt_deg: float = DEFAULT_FALL_TILT_DEG,
        stale_timeout_s: float = DEFAULT_STALE_TIMEOUT_S,
        node_name: str = "imu_bridge",
    ) -> None:
        super().__init__(node_name)
        self._fall_tilt_deg = fall_tilt_deg
        self._stale_timeout_s = stale_timeout_s
        self._latest: Optional[Dict[str, Any]] = None
        self._latest_wall_time: float = 0.0
        self._message_count: int = 0

        self._subscription = self.create_subscription(
            Imu, topic, self._on_imu, qos_profile_sensor_data,
        )
        self.get_logger().info(f"ImuBridge subscribed to '{topic}'")

    def _on_imu(self, msg: Imu) -> None:
        q = msg.orientation
        av = msg.angular_velocity
        la = msg.linear_acceleration
        data = imu_msg_to_sensor_data(
            (q.x, q.y, q.z, q.w),
            (av.x, av.y, av.z),
            (la.x, la.y, la.z),
            fall_tilt_deg=self._fall_tilt_deg,
        )
        data["timestamp"] = time.time()
        self._latest = data
        self._latest_wall_time = time.time()
        self._message_count += 1

    def get_sensor_data(self) -> Dict[str, Any]:
        """
        Latest imu_roll_deg/imu_pitch_deg/imu_yaw_deg/fall_detected +
        timestamp, ready to merge into sensor_data.

        Returns {} if no message has arrived yet, or the latest one is
        older than stale_timeout_s -- fails closed, same reasoning as
        JointStateBridge.get_sensor_data(): HumanoidSafetyRuntime already
        treats missing balance data as "can't verify, no violation raised
        by that check", which is a real gap (see _check_balance's
        docstring) -- but silently holding a stale reading past its
        freshness window and presenting it as current would be worse: a
        fall that happened after the last received message must not read
        as "still upright".
        """
        if self._latest is None:
            return {}
        age = time.time() - self._latest_wall_time
        if age > self._stale_timeout_s:
            self.get_logger().warning(
                f"ImuBridge: latest reading is {age:.2f}s old "
                f"(stale_timeout={self._stale_timeout_s}s) -- discarding"
            )
            return {}
        return dict(self._latest)

    def get_status(self) -> Dict[str, Any]:
        return {
            "message_count": self._message_count,
            "has_data": self._latest is not None,
            "age_s": (time.time() - self._latest_wall_time) if self._latest else None,
        }
