"""
JointState Message Conversion — Pure, ROS2-independent
==========================================================
Converts the field shape of sensor_msgs/msg/JointState (parallel name/
position/velocity/effort arrays) into the sensor_data dict shape
ArmSafetyValidator/HumanoidSafetyRuntime already expect: "joint_positions"
(radians), "joint_velocities" (rad/s), "joint_torques" (N*m, from the
message's "effort" field -- effort is generic in ROS2, N for prismatic
joints, N*m for revolute; both robots here are revolute-only).

Kept dependency-free (no rclpy) on purpose so it can be unit tested without
a ROS2 installation -- see ros2_joint_state_bridge.py for the actual rclpy
Node, which imports this module.

Per the sensor_msgs/msg/JointState spec, velocity and effort arrays MAY be
shorter than name/position or empty entirely if the publisher doesn't
populate them -- this function does not assume all three are always full.
"""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional, Sequence


def joint_state_msg_to_sensor_data(
    name: Sequence[str],
    position: Sequence[float] = (),
    velocity: Sequence[float] = (),
    effort: Sequence[float] = (),
    name_map: Optional[Mapping[str, str]] = None,
) -> Dict[str, Any]:
    """
    name/position/velocity/effort: the four parallel arrays from a
    sensor_msgs/msg/JointState message (velocity/effort may be shorter
    than name/position, or empty -- per the ROS2 message spec, not every
    publisher fills them).

    name_map: optional {urdf_joint_name: platform_joint_name} translation.
    A real robot's URDF almost certainly does not use the platform's
    placeholder joint names (arm_safety_validator.DEFAULT_JOINT_LIMITS /
    humanoid_safety_runtime.DEFAULT_JOINT_LIMITS keys, e.g. "joint_1" or
    "left_hip_pitch") -- without a mapping, joint-limit and self-collision
    checks simply won't find matching keys for an unmapped joint and will
    skip/flag it as missing data (fail-closed), never silently wrong.

    Returns only the keys for which data was actually present -- callers
    should merge this into an existing sensor_data dict, not replace it.
    """
    def translate(n: str) -> str:
        return name_map.get(n, n) if name_map else n

    result: Dict[str, Any] = {}
    if position:
        result["joint_positions"] = {
            translate(n): p for n, p in zip(name, position)
        }
    if velocity:
        result["joint_velocities"] = {
            translate(n): v for n, v in zip(name, velocity)
        }
    if effort:
        result["joint_torques"] = {
            translate(n): e for n, e in zip(name, effort)
        }
    return result
