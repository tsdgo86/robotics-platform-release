from abc import ABC, abstractmethod
from typing import Dict, Any


class BaseDigitalTwin(ABC):
    """Interface for simulation & validation."""

    @abstractmethod
    async def load_environment(self, env_id: str) -> None:
        pass

    @abstractmethod
    async def run_scenario(self, scenario: Any) -> Dict[str, Any]:
        """Run scenario in simulation before real-world."""
        pass

    @abstractmethod
    async def validate_path_before_execution(self, plan: Any) -> bool:
        pass

    @abstractmethod
    async def generate_simulation_report(self) -> Dict[str, Any]:
        pass
