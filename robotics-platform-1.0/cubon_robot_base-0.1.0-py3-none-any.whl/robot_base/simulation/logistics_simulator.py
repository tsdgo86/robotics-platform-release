"""
Discrete-Event Logistics Simulator — What-If Scenario Engine
===================================================================
Khả năng "Simulate" trong D2 (xem
`docs/robotis_implementation/implementation_plan_v2` mục D2): mô phỏng
một chuỗi trạm xử lý (station, vd pick -> pack -> ship) để đánh giá kịch
bản what-if (thêm nhân sự, đổi throughput) trước khi áp dụng thật.

Với service time xác định (deterministic) và lịch đến cố định, kết quả
mô phỏng có thể tính trực tiếp theo thứ tự item (mỗi item chọn server
rảnh sớm nhất tại mỗi trạm) mà không cần event-queue tổng quát -- tương
đương một discrete-event simulation thật (không có tính ngẫu nhiên nào
cần xen kẽ sự kiện), nhưng deterministic nên test được chính xác. Không
phải DES engine tổng quát -- chỉ đủ cho mạng hàng đợi tuyến tính
(linear queueing network) điển hình của logistics/production line. Cho
mô phỏng phức tạp hơn (routing động, resource sharing chéo trạm), dùng
SimPy/AnyLogic thật như tech stack D2 đề xuất.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import List

logger = logging.getLogger(__name__)


@dataclass
class StationSpec:
    name: str
    num_servers: int
    service_time_s: float  # deterministic processing duration per item


@dataclass
class SimulationResult:
    scenario_name: str
    throughput_items_per_hour: float
    avg_wait_time_s: float
    max_busy_servers: int  # proxy for congestion: peak servers busy at any arrival, across stations
    completed_items: int
    total_time_s: float


class DiscreteEventLogisticsSimulator:
    """Simulates `num_items` items flowing through a linear sequence of stations."""

    def __init__(self, stations: List[StationSpec]) -> None:
        if not stations:
            raise ValueError("At least one station is required")
        for s in stations:
            if s.num_servers < 1:
                raise ValueError(f"Station '{s.name}' must have at least 1 server")
            if s.service_time_s <= 0:
                raise ValueError(f"Station '{s.name}' service_time_s must be > 0")
        self._stations = stations

    def run(
        self,
        num_items: int,
        arrival_interval_s: float,
        scenario_name: str = "baseline",
    ) -> SimulationResult:
        if num_items < 1:
            raise ValueError("num_items must be >= 1")
        if arrival_interval_s <= 0:
            raise ValueError("arrival_interval_s must be > 0")

        server_free_at: List[List[float]] = [[0.0] * s.num_servers for s in self._stations]
        max_busy_servers = 0
        wait_times: List[float] = []
        completion_time = 0.0

        for i in range(num_items):
            arrival_time = i * arrival_interval_s
            entry_time = arrival_time
            for idx, station in enumerate(self._stations):
                servers = server_free_at[idx]
                earliest_idx = min(range(len(servers)), key=lambda j: servers[j])
                start_time = max(entry_time, servers[earliest_idx])
                wait = start_time - entry_time
                if idx == 0:
                    wait_times.append(wait)
                busy = sum(1 for t in servers if t > entry_time)
                max_busy_servers = max(max_busy_servers, busy)
                finish_time = start_time + station.service_time_s
                servers[earliest_idx] = finish_time
                entry_time = finish_time
            completion_time = max(completion_time, entry_time)

        throughput = (num_items / completion_time) * 3600.0 if completion_time > 0 else 0.0
        avg_wait = sum(wait_times) / len(wait_times) if wait_times else 0.0

        result = SimulationResult(
            scenario_name=scenario_name,
            throughput_items_per_hour=throughput,
            avg_wait_time_s=avg_wait,
            max_busy_servers=max_busy_servers,
            completed_items=num_items,
            total_time_s=completion_time,
        )
        logger.info(
            f"[DiscreteEventLogisticsSimulator] scenario='{scenario_name}' "
            f"throughput={throughput:.1f}/hr avg_wait={avg_wait:.1f}s"
        )
        return result
