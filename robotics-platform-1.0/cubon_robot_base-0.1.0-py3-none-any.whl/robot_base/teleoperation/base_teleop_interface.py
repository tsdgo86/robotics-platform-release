"""
Base Teleop Interface — Teleoperation Input Device Abstraction
====================================================================
Interface chung cho mọi nguồn nhập teleoperation (bàn phím, VR/hand
tracking qua Vuer, leader-arm, joystick, ...). Không gắn với thiết bị cụ
thể nào -- các adapter thật (vd. Vuer web teleop nêu trong
`docs/robotis_implementation/IMPLEMENTATION_PLAN.md` mục 8.1) implement
ABC này trong repo robot cụ thể.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class TeleopCommand:
    """One teleop input sample."""
    timestamp: float
    joint_targets: Dict[str, float] = field(default_factory=dict)
    gripper_command: Optional[float] = None  # 0.0 = open .. 1.0 = closed; None if not applicable
    source: str = "unknown"  # keyboard | vr | leader_arm | vuer_hand_tracking | ...
    metadata: Dict[str, Any] = field(default_factory=dict)


class BaseTeleopInterface(ABC):
    """Interface for a teleoperation input device/bridge."""

    @abstractmethod
    async def connect(self) -> None:
        pass

    @abstractmethod
    async def disconnect(self) -> None:
        pass

    @abstractmethod
    async def read_command(self) -> Optional[TeleopCommand]:
        """Return the latest teleop command, or None if none available since the last read."""
        pass

    @abstractmethod
    def is_connected(self) -> bool:
        pass
