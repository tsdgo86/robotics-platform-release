"""
Teleop Data Collector — Standardized Demonstration Data Collection
========================================================================
Framework thu thập dữ liệu demonstration qua teleoperation -- đáp ứng
yêu cầu H1 ("designing a DENSO data collection framework for robot
training", Deso challenge) và tương đương `teleop_data_collector.py` đã
thiết kế trong `docs/robotis_implementation/IMPLEMENTATION_PLAN.md` mục
8.2, nhưng đặt ở tầng robot_base để dùng chung cho cả
robot_arm_pick_place, humanoid_physical_ai, robotis_physical_ai -- thay
vì viết riêng cho từng repo.

Mỗi frame (joint targets hiện tại, ảnh camera nếu có, sensor_data
force/torque/pose, ngôn ngữ chỉ dẫn nếu có) được ghi thành một
DemonstrationFrame, gom thành DemonstrationEpisode -- CÙNG schema với
output của BaseKinematicRetargeter (nguồn video, xem
robot_base.ai.imitation_learning), nên BasePolicyTrainer.train() nhận
dữ liệu từ cả 2 nguồn (video và teleop) mà không cần phân biệt.

sensor_data trên mỗi frame phục vụ trực tiếp yêu cầu H3 ("quantify
expert know-how... force, torque, motion trajectory").
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, Optional

from robot_base.ai.imitation_learning.demonstration import DemonstrationEpisode, DemonstrationFrame

logger = logging.getLogger(__name__)


class TeleopDataCollector:
    """
    Buffers synchronized teleop demonstration frames into episodes.

    Usage
    -----
    collector = TeleopDataCollector()
    collector.start_episode("ep_001", robot_id="arm_01", task_name="pick_bolt")
    collector.record_frame(
        joint_positions={"joint_1": 0.1, ...},
        image_ref="camera/frame_0001.jpg",
        sensor_data={"force_n": 12.3, "torque_nm": 1.1},
    )
    ...
    episode = collector.end_episode()
    TeleopDataCollector.export_episode(episode, "episode_001.json")
    """

    def __init__(self) -> None:
        self._current: Optional[DemonstrationEpisode] = None

    def start_episode(
        self,
        episode_id: str,
        robot_id: str,
        task_name: str,
        source: str = "teleop",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        if self._current is not None:
            raise RuntimeError(
                f"Episode '{self._current.episode_id}' still open -- call end_episode() first"
            )
        self._current = DemonstrationEpisode(
            episode_id=episode_id,
            robot_id=robot_id,
            task_name=task_name,
            source=source,
            metadata=metadata or {},
        )
        logger.info(f"[TeleopDataCollector] Started episode '{episode_id}' (robot={robot_id}, task={task_name})")

    def record_frame(
        self,
        timestamp: Optional[float] = None,
        joint_positions: Optional[Dict[str, float]] = None,
        image_ref: Optional[str] = None,
        language_instruction: Optional[str] = None,
        sensor_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        if self._current is None:
            raise RuntimeError("No open episode -- call start_episode() first")
        frame = DemonstrationFrame(
            timestamp=timestamp if timestamp is not None else time.time(),
            robot_joint_targets=joint_positions or {},
            image_ref=image_ref,
            language_instruction=language_instruction,
            sensor_data=sensor_data or {},
        )
        self._current.frames.append(frame)

    def end_episode(self) -> DemonstrationEpisode:
        if self._current is None:
            raise RuntimeError("No open episode to end")
        episode = self._current
        self._current = None
        logger.info(
            f"[TeleopDataCollector] Ended episode '{episode.episode_id}' "
            f"({len(episode.frames)} frames, {episode.duration_s():.2f}s)"
        )
        return episode

    def is_collecting(self) -> bool:
        return self._current is not None

    def current_frame_count(self) -> int:
        return len(self._current.frames) if self._current else 0

    @staticmethod
    def export_episode(episode: DemonstrationEpisode, path: str) -> None:
        """
        Serialize an episode to JSON -- a generic interchange format.
        Conversion to LeRobot's HF-dataset layout (per
        docs/robotis_implementation/IMPLEMENTATION_PLAN.md mục 9.1,
        `convert_to_lerobot.py`) is a downstream, robot-specific step,
        not part of this shared collector.
        """
        with open(path, "w", encoding="utf-8") as f:
            f.write(episode.to_json())

    @staticmethod
    def load_episode(path: str) -> DemonstrationEpisode:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return DemonstrationEpisode.model_validate(data)
