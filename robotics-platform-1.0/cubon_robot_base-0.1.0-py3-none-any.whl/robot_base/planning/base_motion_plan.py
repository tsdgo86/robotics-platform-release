from abc import ABC
from pydantic import BaseModel
from typing import List, Dict, Any


class BaseMotionPlan(BaseModel, ABC):
    """Base DTO for Motion Plans."""
    plan_id: str
    target_pose: Dict[str, Any]
    waypoints: List[Dict[str, Any]] = []


class BaseTrajectory(BaseModel, ABC):
    """Base DTO for Time-parameterized Trajectories."""
    trajectory_id: str
    joint_names: List[str] = []
    points: List[Dict[str, Any]] = []
