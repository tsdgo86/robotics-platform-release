from abc import ABC, abstractmethod
from typing import Any, Dict


class BasePlanner(ABC):
    """Interface for motion & task planning."""

    @abstractmethod
    async def create_plan(self, task: Any, world_state: Any) -> Any:
        """Create plan from task & current world state."""
        pass

    @abstractmethod
    async def validate_plan(self, plan: Any, collision_checker: Any) -> bool:
        """Validate plan before execution."""
        pass

    @abstractmethod
    async def optimize_trajectory(self, plan: Any) -> Any:
        """Time-parameterize & optimize."""
        pass
