from abc import ABC, abstractmethod
from typing import Any


class BaseTrajectoryPlanner(ABC):
    """Interface for Trajectory Generation and Time Parameterization."""

    @abstractmethod
    async def time_parameterize(self, motion_plan: Any) -> Any:
        pass
