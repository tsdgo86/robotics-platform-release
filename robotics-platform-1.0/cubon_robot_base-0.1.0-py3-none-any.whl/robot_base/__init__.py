"""
robot_base: Core architecture framework for Robotics Unified Platform.
"""
__version__ = "0.1.0"
