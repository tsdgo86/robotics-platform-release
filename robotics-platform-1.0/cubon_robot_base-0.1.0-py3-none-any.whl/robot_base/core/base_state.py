from typing import Dict, Any
from pydantic import BaseModel


class BaseState(BaseModel):
    """Base State -- robot state, world state, sensor state."""
    timestamp: str
    robot_id: str

    def snapshot(self) -> Dict[str, Any]:
        return self.model_dump()
