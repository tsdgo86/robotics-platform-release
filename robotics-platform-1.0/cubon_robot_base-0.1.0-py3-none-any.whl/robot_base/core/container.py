import asyncio
from typing import Optional, List
from dependency_injector import containers, providers
from robot_base.core.base_task import BaseTask
from robot_base.core.base_event import BaseEvent


class TaskQueue:
    """Task Queue for Base Orchestrator."""

    def __init__(self):
        self._queue: asyncio.Queue[BaseTask] = asyncio.Queue()

    async def enqueue(self, task: BaseTask) -> None:
        await self._queue.put(task)

    async def dequeue(self) -> Optional[BaseTask]:
        try:
            return await asyncio.wait_for(self._queue.get(), timeout=0.1)
        except asyncio.TimeoutError:
            return None


class EventBus:
    """Internal Event Bus for Pub/Sub messaging."""

    def __init__(self):
        self._history: List[BaseEvent] = []

    async def publish(self, event: BaseEvent) -> None:
        self._history.append(event)

    def get_events(self) -> List[BaseEvent]:
        return self._history
