"""
Default 6-DOF Arm Kinematic Chain
====================================
Revolute joint names (joint_1..joint_6) match arm_safety_validator's
DEFAULT_JOINT_LIMITS exactly, so sensor_data["joint_positions"] (already
used for the joint-limit check) can be fed directly into compute_joint_positions()
without a name-mapping layer.

Link offsets (origin_xyz) are placeholders for a generic mid-size 6-DOF arm
in its home pose (fully extended upward) -- NOT measurements from a real
robot. Replace with real values once a URDF is available.
"""

from __future__ import annotations

from robot_base.core.kinematics import JointSpec, KinematicChain

DEFAULT_ARM_CHAIN = KinematicChain(
    name="arm_6dof",
    joints=[
        JointSpec("joint_1",      None,      (0.0, 0.0, 0.05), axis=(0, 0, 1)),  # base yaw
        JointSpec("joint_2",      "joint_1", (0.0, 0.0, 0.10), axis=(0, 1, 0)),  # shoulder pitch
        JointSpec("joint_3",      "joint_2", (0.0, 0.0, 0.25), axis=(0, 1, 0)),  # elbow pitch (upper arm 0.25m)
        JointSpec("joint_4",      "joint_3", (0.0, 0.0, 0.20), axis=(0, 0, 1)),  # forearm roll (forearm 0.20m)
        JointSpec("joint_5",      "joint_4", (0.0, 0.0, 0.15), axis=(0, 1, 0)),  # wrist pitch
        JointSpec("joint_6",      "joint_5", (0.0, 0.0, 0.14), axis=(0, 0, 1)),  # wrist roll
        JointSpec("end_effector", "joint_6", (0.0, 0.0, 0.15), joint_type="fixed"),  # TCP offset
    ],
)
