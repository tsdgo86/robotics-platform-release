"""
Time Sync Service — Cross-Component Clock Offset Tracking
=============================================================
Theo dõi lệch đồng hồ (clock offset) giữa các nguồn thời gian phân tán
trong platform -- ví dụ giữa container ROS 2 Humble (ROS_DOMAIN_ID=1,
Unitree G1) và container Jazzy (ROS_DOMAIN_ID=2, ROBOTIS AI Worker) nối
qua Zenoh bridge (xem `docs/robotis_implementation/IMPLEMENTATION_PLAN.md`
mục 10), hoặc giữa robot và một reference clock (NTP/host).

Hỗ trợ 2 cách ghi nhận offset:
1. `record_round_trip_sample()` -- kiểu NTP 4-timestamp, tự tính offset
   + round-trip delay từ 1 lần request/response.
2. `record_offset_sample()` -- caller tự tính offset (nếu dùng giao thức
   đồng bộ khác) và chỉ ghi nhận kết quả.

TimeSyncService CHỈ đo lường và báo cáo (giống HealthMonitor) -- nó
không tự trigger an toàn. Dữ liệu `is_synced()` / `check_all_synced()`
nên được orchestrator/safety runtime của robot cụ thể tham khảo để
quyết định có từ chối task cần đồng bộ chặt (ví dụ fleet-coordinated
motion) hay không.

Checklist mapping: H-025, A-029 (đồng bộ thời gian).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

DEFAULT_MAX_OFFSET_S = 0.05       # 50 ms  -- max acceptable clock skew
DEFAULT_MAX_ROUND_TRIP_S = 0.2    # 200 ms -- above this, sample is noisy/untrusted
DEFAULT_WINDOW_SIZE = 20


@dataclass
class TimeSyncConfig:
    max_offset_s: float = DEFAULT_MAX_OFFSET_S
    max_round_trip_s: float = DEFAULT_MAX_ROUND_TRIP_S
    window_size: int = DEFAULT_WINDOW_SIZE


@dataclass
class OffsetSample:
    offset_s: float
    round_trip_s: Optional[float] = None
    time: float = field(default_factory=time.time)
    trusted: bool = True


class TimeSyncService:
    """
    Tracks clock offset per named source using a rolling sample window.

    Usage (NTP-style round trip)
    -----------------------------
    t0 = time.time()                          # local send
    # ... request/response with remote source ...
    offset = svc.record_round_trip_sample("jazzy_container", t0, t1, t2, t3)

    Usage (pre-computed offset)
    -----------------------------
    svc.record_offset_sample("g1_humble", offset_s=0.012)
    svc.is_synced("g1_humble")                # True if within max_offset_s
    """

    def __init__(self, config: Optional[TimeSyncConfig] = None) -> None:
        self._config = config or TimeSyncConfig()
        self._samples: Dict[str, List[OffsetSample]] = {}
        self._alert_log: List[Dict[str, Any]] = []

    # ── Recording ─────────────────────────────────────────────────────────────

    def record_round_trip_sample(
        self, source: str, t0: float, t1: float, t2: float, t3: float
    ) -> float:
        """
        NTP-style 4-timestamp exchange.
        t0 = local send time, t1 = remote receive time,
        t2 = remote send time, t3 = local receive time.
        Returns the computed offset in seconds (positive => remote clock
        ahead of local).
        """
        offset_s = ((t1 - t0) + (t2 - t3)) / 2.0
        round_trip_s = (t3 - t0) - (t2 - t1)
        self.record_offset_sample(source, offset_s, round_trip_s=round_trip_s, timestamp=t3)
        return offset_s

    def record_offset_sample(
        self,
        source: str,
        offset_s: float,
        round_trip_s: Optional[float] = None,
        timestamp: Optional[float] = None,
    ) -> None:
        trusted = round_trip_s is None or round_trip_s <= self._config.max_round_trip_s
        if not trusted:
            logger.warning(
                f"[TimeSync] Untrusted sample source={source} "
                f"round_trip={round_trip_s * 1000:.1f}ms "
                f"(max={self._config.max_round_trip_s * 1000:.0f}ms) -- kept but excluded from offset estimate"
            )

        samples = self._samples.setdefault(source, [])
        samples.append(OffsetSample(
            offset_s=offset_s,
            round_trip_s=round_trip_s,
            time=timestamp if timestamp is not None else time.time(),
            trusted=trusted,
        ))
        if len(samples) > self._config.window_size:
            samples.pop(0)

        if trusted:
            self._check_drift(source, offset_s)

    # ── Query ─────────────────────────────────────────────────────────────────

    def get_offset(self, source: str) -> Optional[float]:
        """
        Median offset (seconds) across trusted samples in the rolling
        window for `source` -- median is more robust to a single noisy/
        delayed round trip than a mean would be. Returns None if no
        trusted samples exist yet.
        """
        samples = [s.offset_s for s in self._samples.get(source, []) if s.trusted]
        if not samples:
            return None
        values = sorted(samples)
        mid = len(values) // 2
        if len(values) % 2 == 1:
            return values[mid]
        return (values[mid - 1] + values[mid]) / 2.0

    def corrected_time(self, source: Optional[str] = None, local_time: Optional[float] = None) -> float:
        """Local time adjusted by the known offset for `source` (or raw local time if source is None/unknown)."""
        local_time = local_time if local_time is not None else time.time()
        if source is None:
            return local_time
        offset = self.get_offset(source)
        return local_time if offset is None else local_time + offset

    def is_synced(self, source: str) -> bool:
        """True when `source` has a trusted offset estimate within max_offset_s."""
        offset = self.get_offset(source)
        return offset is not None and abs(offset) <= self._config.max_offset_s

    def check_all_synced(self) -> List[str]:
        """Names of all known sources currently NOT within max_offset_s (or with no trusted sample yet)."""
        return [name for name in self._samples if not self.is_synced(name)]

    # ── Diagnostics ───────────────────────────────────────────────────────────

    def _check_drift(self, source: str, offset_s: float) -> None:
        if abs(offset_s) <= self._config.max_offset_s:
            return
        entry = {"time": time.time(), "source": source, "offset_s": offset_s}
        self._alert_log.append(entry)
        if len(self._alert_log) > 200:
            self._alert_log.pop(0)
        logger.warning(
            f"[TimeSync] DRIFT source={source} offset={offset_s * 1000:.1f}ms "
            f"(max={self._config.max_offset_s * 1000:.0f}ms)"
        )

    def get_status(self) -> Dict[str, Any]:
        return {
            "sources": {
                name: {
                    "offset_s": self.get_offset(name),
                    "synced": self.is_synced(name),
                    "sample_count": len(samples),
                    "last_round_trip_s": samples[-1].round_trip_s if samples else None,
                }
                for name, samples in self._samples.items()
            },
            "desynced_sources": self.check_all_synced(),
            "drift_alerts_total": len(self._alert_log),
            "last_drift_alert": self._alert_log[-1] if self._alert_log else None,
        }
