"""
Forward Kinematics — Joint Angles → Cartesian Joint Positions
=================================================================
robot_base có 2 chỗ cần vị trí Cartesian của từng joint (không phải góc
radian): ArmCollisionChecker/HumanoidCollisionChecker (self-collision,
env-collision) yêu cầu joint_positions dạng {joint_name: (x,y,z)}. Trước
module này, không có gì trong platform tính được vị trí đó từ góc khớp --
robot_base/core và robot_base/config hoàn toàn rỗng.

Module này KHÔNG parse URDF/XACRO. Kinematic chain được khai báo trực
tiếp bằng Python (JointSpec: parent, offset gốc, trục quay) -- tương
đương phần <origin>/<axis> của URDF <joint> nhưng không cần parser XML.
Kích thước link (origin_xyz) trong arm_kinematic_chain.py/
humanoid_kinematic_chain.py là placeholder hợp lý, KHÔNG phải số đo từ
robot thật -- cần thay bằng giá trị thật khi có URDF chính thức.

Hỗ trợ joint_type "revolute" (quay quanh 1 trục cục bộ theo góc joint)
và "fixed" (offset cứng, không góc -- dùng cho các "joint ảo" như
end_effector/head chỉ đại diện một điểm trên link cha).

Không hỗ trợ prismatic/continuous multi-axis -- đủ cho các checklist
hiện tại (Arm 6-DOF revolute, Humanoid revolute mỗi trục).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

Point3 = Tuple[float, float, float]
Matrix3 = Tuple[Tuple[float, float, float], Tuple[float, float, float], Tuple[float, float, float]]

IDENTITY_R: Matrix3 = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))


class MissingJointAngleError(ValueError):
    """Raised in strict mode when a revolute joint's angle is not supplied."""


@dataclass(frozen=True)
class JointSpec:
    """
    One joint in a kinematic chain.

    name       : joint name -- for revolute joints, must match the key used
                 in sensor_data["joint_positions"] (angles, radians) for
                 joint-limit checks (ArmSafetyValidator/HumanoidSafetyRuntime).
    parent     : name of the parent joint, or None for the chain root.
    origin_xyz : translation offset from the parent joint's frame, applied
                 BEFORE this joint's own rotation (i.e. the rigid link
                 length/offset leading up to this joint).
    axis       : unit rotation axis, expressed in the parent-aligned frame
                 (ignored for "fixed" joints).
    joint_type : "revolute" | "fixed"
    """
    name:       str
    parent:     Optional[str]
    origin_xyz: Point3
    axis:       Point3 = (0.0, 0.0, 1.0)
    joint_type: str = "revolute"


@dataclass
class KinematicChain:
    """An ordered set of joints forming a tree (each joint has at most one parent)."""
    name:   str
    joints: List[JointSpec] = field(default_factory=list)

    def __post_init__(self) -> None:
        names = [j.name for j in self.joints]
        if len(names) != len(set(names)):
            raise ValueError(f"KinematicChain '{self.name}': duplicate joint names")
        by_name = {j.name: j for j in self.joints}
        for j in self.joints:
            if j.parent is not None and j.parent not in by_name:
                raise ValueError(
                    f"KinematicChain '{self.name}': joint '{j.name}' has unknown parent '{j.parent}'"
                )
        self._by_name: Dict[str, JointSpec] = by_name

    def joint_names(self) -> List[str]:
        return [j.name for j in self.joints]

    def revolute_joint_names(self) -> List[str]:
        return [j.name for j in self.joints if j.joint_type == "revolute"]

    def get(self, name: str) -> JointSpec:
        return self._by_name[name]


# ── Matrix / vector helpers (pure Python -- no numpy dependency) ────────────

def _mat_vec(m: Matrix3, v: Point3) -> Point3:
    return (
        m[0][0] * v[0] + m[0][1] * v[1] + m[0][2] * v[2],
        m[1][0] * v[0] + m[1][1] * v[1] + m[1][2] * v[2],
        m[2][0] * v[0] + m[2][1] * v[1] + m[2][2] * v[2],
    )


def _mat_mat(a: Matrix3, b: Matrix3) -> Matrix3:
    return tuple(
        tuple(sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3))
        for i in range(3)
    )  # type: ignore[return-value]


def _vec_add(a: Point3, b: Point3) -> Point3:
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def rotation_about_axis(axis: Point3, angle_rad: float) -> Matrix3:
    """Rodrigues' rotation formula -- rotation matrix for `angle_rad` about a unit `axis`."""
    norm = math.sqrt(axis[0] ** 2 + axis[1] ** 2 + axis[2] ** 2)
    if norm < 1e-9:
        return IDENTITY_R
    ux, uy, uz = axis[0] / norm, axis[1] / norm, axis[2] / norm
    c = math.cos(angle_rad)
    s = math.sin(angle_rad)
    t = 1.0 - c
    return (
        (t * ux * ux + c,      t * ux * uy - s * uz, t * ux * uz + s * uy),
        (t * ux * uy + s * uz, t * uy * uy + c,      t * uy * uz - s * ux),
        (t * ux * uz - s * uy, t * uy * uz + s * ux, t * uz * uz + c),
    )


@dataclass
class Frame:
    """Rigid transform: rotation (parent->this frame) + world-frame position."""
    rotation: Matrix3
    position: Point3


def _child_frame(parent: Frame, joint: JointSpec, angle_rad: float) -> Frame:
    # Translate along the parent's orientation, then apply this joint's own rotation.
    world_offset = _mat_vec(parent.rotation, joint.origin_xyz)
    position = _vec_add(parent.position, world_offset)
    if joint.joint_type == "fixed":
        rotation = parent.rotation
    else:
        local_r = rotation_about_axis(joint.axis, angle_rad)
        rotation = _mat_mat(parent.rotation, local_r)
    return Frame(rotation=rotation, position=position)


def compute_joint_positions(
    chain: KinematicChain,
    joint_angles: Dict[str, float],
    strict: bool = False,
    base_frame: Optional[Frame] = None,
) -> Dict[str, Point3]:
    """
    Forward kinematics: joint angles (radians) -> Cartesian joint positions,
    in the chain's base frame (base_frame defaults to identity at origin).

    strict=False (default): revolute joints missing from joint_angles use
    angle 0.0 (the chain's neutral/rest pose) -- lenient, general-purpose FK.

    strict=True: raises MissingJointAngleError listing every missing
    revolute joint instead of silently assuming 0.0. Safety-critical
    callers (collision checking) should use strict=True and treat the
    error the same as "insufficient pose data" -- never fall back to a
    guessed neutral pose for a safety decision.
    """
    if strict:
        missing = [n for n in chain.revolute_joint_names() if n not in joint_angles]
        if missing:
            raise MissingJointAngleError(
                f"KinematicChain '{chain.name}': missing angles for joints {missing}"
            )

    base = base_frame or Frame(rotation=IDENTITY_R, position=(0.0, 0.0, 0.0))
    frames: Dict[str, Frame] = {}
    positions: Dict[str, Point3] = {}

    # joints is a list; resolve in declaration order but allow forward
    # references by processing until all parents are resolved (simple
    # fixed-point loop -- chains here are small, this is O(n^2) worst case
    # which is fine).
    remaining = list(chain.joints)
    while remaining:
        progressed = False
        still_remaining = []
        for joint in remaining:
            parent_frame = base if joint.parent is None else frames.get(joint.parent)
            if joint.parent is not None and parent_frame is None:
                still_remaining.append(joint)
                continue
            angle = joint_angles.get(joint.name, 0.0) if joint.joint_type == "revolute" else 0.0
            frame = _child_frame(parent_frame, joint, angle)
            frames[joint.name] = frame
            positions[joint.name] = frame.position
            progressed = True
        if not progressed:
            unresolved = [j.name for j in still_remaining]
            raise ValueError(f"KinematicChain '{chain.name}': could not resolve joints {unresolved} (cycle?)")
        remaining = still_remaining

    return positions
