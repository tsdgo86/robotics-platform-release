from abc import ABC, abstractmethod
from pydantic import BaseModel


class BaseTask(BaseModel, ABC):
    """Base Task DTO -- all concrete robot tasks inherit from this."""
    task_id: str
    task_type: str
    priority: int = 5
    source: str = "hri"  # hri | fleet | scheduler | api

    @abstractmethod
    def is_valid(self) -> bool:
        """Validate task-specific business rules."""
        pass
