from typing import Dict, Any
from pydantic import BaseModel


class BaseEvent(BaseModel):
    """Base Event DTO -- used for event bus & data engine."""
    event_id: str
    event_type: str
    timestamp: str
    robot_id: str
    payload: Dict[str, Any]

    def to_json(self) -> str:
        return self.model_dump_json()
