from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
from pydantic import BaseModel
import asyncio
import time
from dependency_injector import containers

from robot_base.core.base_task import BaseTask
from robot_base.core.base_event import BaseEvent
from robot_base.core.base_state import BaseState


class BaseConfig(BaseModel):
    """Base configuration for all robots."""
    robot_id: str
    environment: str = "simulation"  # simulation | production
    log_level: str = "INFO"
    safety_enabled: bool = True
    mlflow_tracking_uri: Optional[str] = None


class BaseRobotApplication(ABC):
    """
    Abstract Orchestrator -- the heart of every robot.
    Each concrete robot inherits and implements lifecycle methods.
    """

    def __init__(self, config: BaseConfig):
        self.config = config
        self._container = self._build_container()
        self._event_bus = self._container.event_bus()
        self._data_engine = self._container.data_engine()
        self._safety = self._container.safety_runtime()
        self._initialized = False

    @abstractmethod
    def _build_container(self) -> containers.Container:
        """Define DI container with specific services."""
        pass

    @abstractmethod
    async def initialize_modules(self) -> None:
        """Initialize hardware, sensors, models."""
        pass

    @abstractmethod
    async def execute_task(self, task: BaseTask) -> BaseEvent:
        """End-to-end task execution flow."""
        pass

    @abstractmethod
    async def shutdown(self) -> None:
        """Graceful shutdown."""
        pass

    async def run(self, max_loops: Optional[int] = None) -> None:
        """Main lifecycle loop."""
        await self.initialize_modules()
        self._initialized = True
        loop_count = 0
        try:
            while True:
                if max_loops is not None and loop_count >= max_loops:
                    break
                task = await self._acquire_next_task()
                if task and task.is_valid():
                    if await self._safety.approve_action(task):
                        event = await self.execute_task(task)
                        await self._data_engine.log_event(event)
                    else:
                        await self._handle_safety_rejection(task)
                loop_count += 1
                await asyncio.sleep(0.01)
        except asyncio.CancelledError:
            pass
        finally:
            await self.shutdown()

    async def _acquire_next_task(self) -> Optional[BaseTask]:
        """Fetch task from queue -- can be overridden."""
        return await self._container.task_queue().dequeue()

    async def _handle_safety_rejection(self, task: BaseTask) -> None:
        event = BaseEvent(
            event_id=f"rej_{task.task_id}",
            event_type="safety_rejection",
            timestamp=str(time.time()),
            robot_id=self.config.robot_id,
            payload={"task_id": task.task_id, "reason": "safety_check_failed"}
        )
        await self._data_engine.log_event(event)
