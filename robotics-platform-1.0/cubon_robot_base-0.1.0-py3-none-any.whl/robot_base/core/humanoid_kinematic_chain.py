"""
Default Humanoid Kinematic Chain
===================================
Revolute joint names match humanoid_safety_runtime's DEFAULT_JOINT_LIMITS
exactly (left/right hip_pitch/hip_roll/hip_yaw, knee, ankle_pitch/ankle_roll,
shoulder_pitch/shoulder_roll/shoulder_yaw, elbow, wrist_pitch/wrist_roll/
wrist_yaw, waist_pitch/roll/yaw, neck_pitch/yaw), so sensor_data["joint_positions"]
(already used for the joint-limit check) can be fed directly into
compute_joint_positions() without a name-mapping layer.

Multi-DOF joints (hip, shoulder, wrist, waist, neck) are modeled as a
series of single-axis revolute joints at zero offset from each other,
followed by a zero-offset "fixed" joint that exposes the combined
position under the anchor name HumanoidCollisionChecker expects
(e.g. left_hip_pitch -> left_hip_roll -> left_hip_yaw -> "left_hip").

Link offsets (origin_xyz) are placeholders for a generic biped in a
neutral standing pose -- NOT measurements from a real robot (no URDF
exists yet). They reproduce the same neutral-pose geometry already
validated as collision-free in robot_base/tests/test_collision_checker.py.
"""

from __future__ import annotations

from robot_base.core.kinematics import JointSpec, KinematicChain

_PELVIS_HEIGHT_M   = 0.9
_TORSO_HEIGHT_M    = 0.5
_HEAD_OFFSET_M     = 0.18
_HIP_LATERAL_M     = 0.12
_THIGH_LENGTH_M    = 0.4
_SHIN_LENGTH_M     = 0.4
_ANKLE_SPLAY_M     = 0.02   # slight outward lean, foot stance wider than hips
_SHOULDER_LATERAL_M = 0.22
_SHOULDER_DROP_M    = 0.1   # shoulder sits below the torso-top/neck attachment
_UPPER_ARM_LENGTH_M = 0.25
_FOREARM_LENGTH_M   = 0.25


def _arm_joints(side: str, sign: float) -> list[JointSpec]:
    lateral = sign * _SHOULDER_LATERAL_M
    reach = sign * _UPPER_ARM_LENGTH_M
    reach2 = sign * _FOREARM_LENGTH_M
    return [
        JointSpec(f"{side}_shoulder_pitch", "torso_top", (lateral, 0.0, -_SHOULDER_DROP_M), axis=(0, 1, 0)),
        JointSpec(f"{side}_shoulder_roll",  f"{side}_shoulder_pitch", (0.0, 0.0, 0.0), axis=(1, 0, 0)),
        JointSpec(f"{side}_shoulder_yaw",   f"{side}_shoulder_roll",  (0.0, 0.0, 0.0), axis=(0, 0, 1)),
        JointSpec(f"{side}_shoulder",       f"{side}_shoulder_yaw",   (0.0, 0.0, 0.0), joint_type="fixed"),
        JointSpec(f"{side}_elbow",          f"{side}_shoulder",       (reach, 0.0, 0.0), axis=(0, 1, 0)),
        JointSpec(f"{side}_wrist_pitch",    f"{side}_elbow",          (reach2, 0.0, 0.0), axis=(0, 1, 0)),
        JointSpec(f"{side}_wrist_roll",     f"{side}_wrist_pitch",    (0.0, 0.0, 0.0), axis=(1, 0, 0)),
        JointSpec(f"{side}_wrist_yaw",      f"{side}_wrist_roll",     (0.0, 0.0, 0.0), axis=(0, 0, 1)),
        JointSpec(f"{side}_wrist",          f"{side}_wrist_yaw",      (0.0, 0.0, 0.0), joint_type="fixed"),
    ]


def _leg_joints(side: str, sign: float) -> list[JointSpec]:
    lateral = sign * _HIP_LATERAL_M
    splay = sign * _ANKLE_SPLAY_M
    return [
        JointSpec(f"{side}_hip_pitch", "pelvis", (lateral, 0.0, 0.0), axis=(0, 1, 0)),
        JointSpec(f"{side}_hip_roll",  f"{side}_hip_pitch", (0.0, 0.0, 0.0), axis=(1, 0, 0)),
        JointSpec(f"{side}_hip_yaw",   f"{side}_hip_roll",  (0.0, 0.0, 0.0), axis=(0, 0, 1)),
        JointSpec(f"{side}_hip",       f"{side}_hip_yaw",   (0.0, 0.0, 0.0), joint_type="fixed"),
        JointSpec(f"{side}_knee",      f"{side}_hip",       (splay, 0.0, -_THIGH_LENGTH_M), axis=(0, 1, 0)),
        JointSpec(f"{side}_ankle_pitch", f"{side}_knee",       (0.0, 0.0, -_SHIN_LENGTH_M), axis=(0, 1, 0)),
        JointSpec(f"{side}_ankle_roll",  f"{side}_ankle_pitch", (0.0, 0.0, 0.0), axis=(1, 0, 0)),
        JointSpec(f"{side}_ankle",       f"{side}_ankle_roll",  (0.0, 0.0, 0.0), joint_type="fixed"),
    ]


DEFAULT_HUMANOID_CHAIN = KinematicChain(
    name="humanoid_biped",
    joints=[
        JointSpec("pelvis", None, (0.0, 0.0, _PELVIS_HEIGHT_M), joint_type="fixed"),

        JointSpec("waist_pitch", "pelvis",      (0.0, 0.0, 0.0), axis=(0, 1, 0)),
        JointSpec("waist_roll",  "waist_pitch", (0.0, 0.0, 0.0), axis=(1, 0, 0)),
        JointSpec("waist_yaw",   "waist_roll",  (0.0, 0.0, _TORSO_HEIGHT_M), axis=(0, 0, 1)),
        JointSpec("torso_top",   "waist_yaw",   (0.0, 0.0, 0.0), joint_type="fixed"),

        JointSpec("neck_yaw",   "torso_top", (0.0, 0.0, 0.0), axis=(0, 0, 1)),
        JointSpec("neck_pitch", "neck_yaw",  (0.0, 0.0, 0.0), axis=(0, 1, 0)),
        JointSpec("neck",       "neck_pitch", (0.0, 0.0, 0.0), joint_type="fixed"),
        JointSpec("head",       "neck",       (0.0, 0.0, _HEAD_OFFSET_M), joint_type="fixed"),

        *_arm_joints("left", +1.0),
        *_arm_joints("right", -1.0),
        *_leg_joints("left", +1.0),
        *_leg_joints("right", -1.0),
    ],
)
