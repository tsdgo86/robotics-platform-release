"""
Health Monitor — System Telemetry Aggregation
=================================================
Thu thập telemetry (CPU, RAM, battery, temperature, network latency,
hoặc bất kỳ metric tuỳ chỉnh nào) từ các thành phần runtime và tổng hợp
thành một trạng thái sức khỏe hệ thống duy nhất (OK / DEGRADED /
CRITICAL) để phục vụ dashboard/telemetry pipeline.

HealthMonitor CHỈ báo cáo -- nó không tự trigger e-stop hay chặn hành
động. Việc đó thuộc về BaseSafetyRuntime (per-robot) và
robot_base.safety.watchdog_monitor.WatchdogMonitor (liveness). Ba module
này độc lập và có thể compose với nhau: ví dụ orchestrator có thể theo
dõi `health_monitor.overall_level()` và chủ động từ chối nhận task mới
khi CRITICAL, mà không cần HealthMonitor biết gì về an toàn.

Checklist mapping: H-029, H-045 (giám sát sức khỏe hệ thống / telemetry).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class HealthLevel(str, Enum):
    OK = "OK"
    DEGRADED = "DEGRADED"
    CRITICAL = "CRITICAL"


@dataclass
class MetricThreshold:
    warn_above: Optional[float] = None
    critical_above: Optional[float] = None
    warn_below: Optional[float] = None
    critical_below: Optional[float] = None


# Conservative defaults for common platform metrics -- override/extend via
# HealthMonitorConfig.thresholds for robot-specific metrics.
DEFAULT_THRESHOLDS: Dict[str, MetricThreshold] = {
    "cpu_pct":            MetricThreshold(warn_above=80.0, critical_above=95.0),
    "memory_pct":          MetricThreshold(warn_above=80.0, critical_above=95.0),
    "battery_soc_pct":     MetricThreshold(warn_below=20.0, critical_below=10.0),
    "temperature_c":       MetricThreshold(warn_above=60.0, critical_above=75.0),
    "network_latency_ms":  MetricThreshold(warn_above=200.0, critical_above=1000.0),
}


@dataclass
class HealthMonitorConfig:
    thresholds: Dict[str, MetricThreshold] = field(default_factory=lambda: dict(DEFAULT_THRESHOLDS))
    window_size: int = 100


@dataclass
class MetricSample:
    value: float
    time: float = field(default_factory=time.time)


class HealthMonitor:
    """
    Rolling telemetry aggregator with per-metric warn/critical thresholds.

    Usage
    -----
    health = HealthMonitor()
    health.record("battery_soc_pct", 18.0)
    health.record("temperature_c", 42.0)
    health.overall_level()   # HealthLevel.DEGRADED (battery below warn_below)
    """

    def __init__(self, config: Optional[HealthMonitorConfig] = None) -> None:
        self._config = config or HealthMonitorConfig()
        self._samples: Dict[str, List[MetricSample]] = {}
        self._alert_log: List[Dict[str, Any]] = []

    # ── Recording ─────────────────────────────────────────────────────────────

    def record(self, metric: str, value: float, timestamp: Optional[float] = None) -> None:
        samples = self._samples.setdefault(metric, [])
        samples.append(MetricSample(value=value, time=timestamp if timestamp is not None else time.time()))
        if len(samples) > self._config.window_size:
            samples.pop(0)
        level = self._evaluate_metric(metric, value)
        if level is not HealthLevel.OK:
            self._log_alert(metric, value, level)

    def record_many(self, metrics: Dict[str, float], timestamp: Optional[float] = None) -> None:
        for name, value in metrics.items():
            self.record(name, value, timestamp)

    # ── Evaluation ────────────────────────────────────────────────────────────

    def _evaluate_metric(self, metric: str, value: float) -> HealthLevel:
        th = self._config.thresholds.get(metric)
        if th is None:
            return HealthLevel.OK
        if th.critical_above is not None and value > th.critical_above:
            return HealthLevel.CRITICAL
        if th.critical_below is not None and value < th.critical_below:
            return HealthLevel.CRITICAL
        if th.warn_above is not None and value > th.warn_above:
            return HealthLevel.DEGRADED
        if th.warn_below is not None and value < th.warn_below:
            return HealthLevel.DEGRADED
        return HealthLevel.OK

    def latest(self, metric: str) -> Optional[float]:
        samples = self._samples.get(metric)
        return samples[-1].value if samples else None

    def overall_level(self) -> HealthLevel:
        """Worst level across the latest sample of every tracked metric."""
        worst = HealthLevel.OK
        for metric, samples in self._samples.items():
            if not samples:
                continue
            level = self._evaluate_metric(metric, samples[-1].value)
            if level is HealthLevel.CRITICAL:
                return HealthLevel.CRITICAL
            if level is HealthLevel.DEGRADED:
                worst = HealthLevel.DEGRADED
        return worst

    # ── Diagnostics ───────────────────────────────────────────────────────────

    def _log_alert(self, metric: str, value: float, level: HealthLevel) -> None:
        entry = {"time": time.time(), "metric": metric, "value": value, "level": level.value}
        self._alert_log.append(entry)
        if len(self._alert_log) > 200:
            self._alert_log.pop(0)
        logger.warning(f"[HealthMonitor] [{level.value}] {metric}={value}")

    def get_report(self) -> Dict[str, Any]:
        return {
            "overall_level": self.overall_level().value,
            "metrics": {name: samples[-1].value for name, samples in self._samples.items() if samples},
            "alerts_total": len(self._alert_log),
            "last_alert": self._alert_log[-1] if self._alert_log else None,
        }

    def get_status(self) -> Dict[str, Any]:
        return self.get_report()
