"""
Impact Propagation Engine — Rule-Based Incident Impact/Cause (D3)
========================================================================
Given an incident starting at one node with a severity, propagate
impact through BaseGraphStore edges with per-hop decay (edge.weight),
producing a per-node impact score and recommended department actions --
D3's "Link Production-Chain Data & Predict Incident Impact/Cause" (xem
`docs/robotis_implementation/implementation_plan_v2` mục D3).

Đây là baseline "rule + ML" ở dạng rule-based propagation with decay --
tường minh (explainable), không cần dữ liệu huấn luyện, đủ để so sánh
trước khi thêm một model ML thật vào cùng kiến trúc (tech stack D3 đề
xuất Rule + Machine Learning).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List

from robot_base.knowledge.base_graph_store import BaseGraphStore

logger = logging.getLogger(__name__)

DEFAULT_MIN_IMPACT_THRESHOLD = 0.05
DEFAULT_MAX_HOPS = 10
URGENT_IMPACT_THRESHOLD = 0.5
MODERATE_IMPACT_THRESHOLD = 0.2


@dataclass
class ImpactPropagationResult:
    origin_node: str
    initial_severity: float
    impact_scores: Dict[str, float] = field(default_factory=dict)  # node_id -> propagated impact
    affected_paths: Dict[str, List[str]] = field(default_factory=dict)  # node_id -> path from origin


class ImpactPropagationEngine:
    def __init__(
        self,
        graph: BaseGraphStore,
        min_impact_threshold: float = DEFAULT_MIN_IMPACT_THRESHOLD,
        max_hops: int = DEFAULT_MAX_HOPS,
    ) -> None:
        self._graph = graph
        self._min_impact_threshold = min_impact_threshold
        self._max_hops = max_hops

    def propagate(self, origin_node: str, severity: float) -> ImpactPropagationResult:
        if self._graph.get_node(origin_node) is None:
            raise ValueError(f"Unknown origin node '{origin_node}'")
        if not (0.0 < severity <= 1.0):
            raise ValueError("severity must be in (0, 1]")

        impact_scores: Dict[str, float] = {origin_node: severity}
        affected_paths: Dict[str, List[str]] = {origin_node: [origin_node]}

        # BFS with decay -- a node is only re-queued if a stronger impact
        # arrives via a different path than previously recorded.
        frontier = [(origin_node, severity, [origin_node])]
        hops = 0
        while frontier and hops < self._max_hops:
            next_frontier = []
            for node_id, node_impact, path in frontier:
                for edge in self._graph.get_neighbors(node_id):
                    propagated = node_impact * edge.weight
                    if propagated < self._min_impact_threshold:
                        continue
                    existing = impact_scores.get(edge.target, 0.0)
                    if propagated > existing:
                        new_path = path + [edge.target]
                        impact_scores[edge.target] = propagated
                        affected_paths[edge.target] = new_path
                        next_frontier.append((edge.target, propagated, new_path))
            frontier = next_frontier
            hops += 1

        logger.info(
            f"[ImpactPropagationEngine] origin='{origin_node}' severity={severity} "
            f"-> {len(impact_scores) - 1} node(s) affected"
        )
        return ImpactPropagationResult(
            origin_node=origin_node,
            initial_severity=severity,
            impact_scores=impact_scores,
            affected_paths=affected_paths,
        )

    def recommend_department_actions(self, result: ImpactPropagationResult) -> List[str]:
        actions: List[str] = []
        ranked = sorted(
            (item for item in result.impact_scores.items() if item[0] != result.origin_node),
            key=lambda kv: -kv[1],
        )
        for node_id, impact in ranked:
            path_str = " -> ".join(result.affected_paths[node_id])
            if impact >= URGENT_IMPACT_THRESHOLD:
                actions.append(f"URGENT: notify '{node_id}' -- high impact ({impact:.2f}) via {path_str}")
            elif impact >= MODERATE_IMPACT_THRESHOLD:
                actions.append(f"MONITOR: '{node_id}' -- moderate impact ({impact:.2f}) via {path_str}")
        if not actions:
            actions.append("NO_ACTION: incident impact does not propagate meaningfully beyond origin")
        return actions
