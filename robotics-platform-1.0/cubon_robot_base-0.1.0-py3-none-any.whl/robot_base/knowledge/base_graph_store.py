"""
Base Graph Store — Production-Chain Relationship Graph (D3)
==================================================================
Interface lưu trữ graph liên kết production-chain (node: department/
machine/process, edge: quan hệ phụ thuộc có trọng số) -- nền tảng cho D3
(xem `docs/robotis_implementation/implementation_plan_v2` mục D3:
"Link Production-Chain Data & Predict Incident Impact/Cause").

`InMemoryGraphStore` là reference implementation dependency-free (dict
adjacency, không cần Neo4j). Adapter Neo4j/RDF thật (tech stack D3 đề
xuất) implement lại BaseGraphStore.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class GraphEdge:
    """A directed relationship between two nodes."""
    source: str
    target: str
    relation: str
    weight: float = 1.0  # impact propagation factor, typically in [0, 1]
    metadata: Dict[str, Any] = field(default_factory=dict)


class BaseGraphStore(ABC):
    """Interface for a production-chain relationship graph."""

    @abstractmethod
    def add_node(
        self, node_id: str, labels: Optional[List[str]] = None, properties: Optional[Dict[str, Any]] = None
    ) -> None:
        pass

    @abstractmethod
    def add_edge(self, edge: GraphEdge) -> None:
        pass

    @abstractmethod
    def get_neighbors(self, node_id: str) -> List[GraphEdge]:
        """Outgoing edges from `node_id`."""
        pass

    @abstractmethod
    def get_node(self, node_id: str) -> Optional[Dict[str, Any]]:
        pass


class InMemoryGraphStore(BaseGraphStore):
    """Dict-based adjacency-list graph store -- no external database required."""

    def __init__(self) -> None:
        self._nodes: Dict[str, Dict[str, Any]] = {}
        self._edges: Dict[str, List[GraphEdge]] = {}

    def add_node(
        self, node_id: str, labels: Optional[List[str]] = None, properties: Optional[Dict[str, Any]] = None
    ) -> None:
        self._nodes[node_id] = {"labels": labels or [], "properties": properties or {}}
        self._edges.setdefault(node_id, [])

    def add_edge(self, edge: GraphEdge) -> None:
        if edge.source not in self._nodes:
            raise ValueError(f"Unknown source node '{edge.source}' -- call add_node() first")
        if edge.target not in self._nodes:
            raise ValueError(f"Unknown target node '{edge.target}' -- call add_node() first")
        self._edges[edge.source].append(edge)

    def get_neighbors(self, node_id: str) -> List[GraphEdge]:
        return list(self._edges.get(node_id, []))

    def get_node(self, node_id: str) -> Optional[Dict[str, Any]]:
        return self._nodes.get(node_id)

    def get_all_node_ids(self) -> List[str]:
        return list(self._nodes.keys())
