"""
PPE Perception Adapter — Concrete BasePerception for factory_hacks skills
============================================================================
factory_hacks.skills.humanoid_skills.inspect_zone_executor calls
context.config.get("perception_adapter") and expects .read_sensors() /
.detect_objects(sensor_data) -- robot_base.perception.BasePerception has
declared exactly this contract since it was written, with zero
implementations. This is the first one.

Wires together:
  - a camera source: anything exposing get_sensor_data() -> Dict[str, Any]
    (e.g. robot_base.communication.dds.ros2_image_bridge.ImageBridge) --
    NOT imported directly here, so this module stays importable without
    rclpy, same reasoning as communication/dds's own pure/rclpy split.
  - a pluggable BasePPEDetector (base_ppe_detector.py) that actually
    produces detections -- defaults to NullPPEDetector; read that class's
    docstring before using this adapter for anything safety-relevant.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from robot_base.perception.base_perception import BasePerception
from robot_base.perception.base_ppe_detector import BasePPEDetector, NullPPEDetector


class PPEPerceptionAdapter(BasePerception):
    """
    camera_source: anything exposing get_sensor_data() -> Dict[str, Any]
    with (at least) "camera_online": bool and "camera_frame": <frame>.
    Pass a real ImageBridge instance in a live deployment; None disables
    sensing (read_sensors() always returns {}).

    detector: BasePPEDetector. Defaults to NullPPEDetector -- see its
    docstring before relying on this for a real compliance decision.

    min_confidence: detections below this are dropped inside
    detect_objects() itself, not left for the caller to filter -- same
    reject-before-it-can-be-misused convention as
    ArmSafetyValidator.MIN_CONFIDENCE.
    """

    def __init__(
        self,
        camera_source: Optional[Any] = None,
        detector: Optional[BasePPEDetector] = None,
        min_confidence: float = 0.6,
    ) -> None:
        self._camera_source = camera_source
        self._detector = detector or NullPPEDetector()
        self._min_confidence = min_confidence
        self._read_count = 0
        self._detect_count = 0

    async def read_sensors(self) -> Dict[str, Any]:
        """
        Latest camera_source.get_sensor_data() output (camera_online/
        camera_frame/... -- see image_conversion.py), or {} if no
        camera_source is configured or it has no fresh frame. Never
        fabricates a frame.
        """
        self._read_count += 1
        if self._camera_source is None:
            return {}
        data = self._camera_source.get_sensor_data()
        return data or {}

    async def detect_objects(self, sensor_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        sensor_data: output of read_sensors() (or equivalent) -- must have
        "camera_online": True and a non-None "camera_frame" to run
        detection. Returns [] (not an error) otherwise -- callers must
        not read [] as "verified clear"; see NullPPEDetector's docstring
        for exactly why that distinction matters for DETECT_PPE.
        """
        self._detect_count += 1
        if not sensor_data.get("camera_online") or sensor_data.get("camera_frame") is None:
            return []
        detections = await self._detector.detect(sensor_data["camera_frame"])
        return [d for d in detections if d.get("confidence", 1.0) >= self._min_confidence]

    async def validate_detection_confidence(self, detections: List[Dict[str, Any]]) -> bool:
        """True if every detection meets min_confidence (vacuously true for [])."""
        return all(d.get("confidence", 1.0) >= self._min_confidence for d in detections)

    def get_status(self) -> Dict[str, Any]:
        return {
            "read_count": self._read_count,
            "detect_count": self._detect_count,
            "detector": type(self._detector).__name__,
            "has_camera_source": self._camera_source is not None,
        }
