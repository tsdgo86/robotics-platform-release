from abc import ABC, abstractmethod
from typing import List, Dict, Any
from robot_base.core.base_state import BaseState


class BaseObjectDetector(ABC):
    """Interface for Object Detector / Pose Estimator."""

    @abstractmethod
    async def estimate_object_pose(self, detection: Dict[str, Any]) -> Dict[str, Any]:
        pass
