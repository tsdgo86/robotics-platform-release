from abc import ABC, abstractmethod


class BaseSensorAdapter(ABC):
    """Interface for Hardware Sensor Adapters."""

    @abstractmethod
    async def connect(self) -> bool:
        pass

    @abstractmethod
    async def disconnect(self) -> None:
        pass
