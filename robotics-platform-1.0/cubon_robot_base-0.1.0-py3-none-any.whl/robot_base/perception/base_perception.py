from abc import ABC, abstractmethod
from typing import List, Dict, Any
from robot_base.core.base_state import BaseState


class BasePerception(ABC):
    """Interface for all perception systems."""

    @abstractmethod
    async def read_sensors(self) -> BaseState:
        """Read data from all sensors."""
        pass

    @abstractmethod
    async def detect_objects(self, sensor_data: BaseState) -> List[Dict[str, Any]]:
        """Detect & classify objects."""
        pass

    @abstractmethod
    async def validate_detection_confidence(self, detections: List[Dict[str, Any]]) -> bool:
        pass
