"""
Base PPE Detector — Pluggable Detection Backend
==================================================
Abstract interface for whatever actually looks at pixels and decides
"helmet present" / "no_helmet" / "safety_vest" / "no_vest" / "person".
PPEPerceptionAdapter (ppe_perception_adapter.py) calls this per frame --
it does not implement detection itself.

No real trained model ships with this repo. NullPPEDetector below is a
structural placeholder (always returns no detections) so the pipeline is
runnable/testable end-to-end -- it is NOT a real detector and must not be
mistaken for one; see its own docstring for why that specifically matters
here (DETECT_PPE treats zero detections as "compliant").
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


class BasePPEDetector(ABC):
    """Interface for a PPE-compliance object detector."""

    @abstractmethod
    async def detect(self, frame: Any) -> List[Dict[str, Any]]:
        """
        frame: whatever the configured camera source produces (e.g. a
        numpy array from robot_base.communication.dds.ros2_image_bridge.
        ImageBridge).

        Returns a list of {"label": str, "confidence": float, ...}.
        Expected labels, matching factory_hacks.skills.humanoid_skills'
        PPE_LABELS/MISSING_PPE_LABELS: "person"/"worker" for headcount,
        and "helmet"/"no_helmet"/"safety_vest"/"no_vest"/"barefoot"/
        "no_ppe"/... for compliance. A real model must emit the NEGATIVE
        classes (no_helmet, no_vest, ...) directly -- DETECT_PPE does not
        derive "missing" from mere absence of a positive label.
        """
        raise NotImplementedError


class NullPPEDetector(BasePPEDetector):
    """
    Always returns no detections. Exists ONLY to keep
    PPEPerceptionAdapter / INSPECT_ZONE / DETECT_PPE runnable end-to-end
    without a real model plugged in (wiring/integration tests, local dev).

    DANGER: DETECT_PPE's existing logic treats zero detections as
    workers_detected=0, violations=[], compliant=True. Using this
    detector anywhere near production means EVERY inspection silently
    reports "compliant" regardless of reality -- it is a safe default to
    START a wiring path from, not a safe default to LEAVE in place. Logs
    a warning on every call so this cannot go unnoticed.
    """

    async def detect(self, frame: Any) -> List[Dict[str, Any]]:
        logger.warning(
            "[NullPPEDetector] No real PPE detection model is configured -- "
            "returning zero detections. DETECT_PPE will report 'compliant' "
            "for this frame regardless of actual conditions."
        )
        return []
