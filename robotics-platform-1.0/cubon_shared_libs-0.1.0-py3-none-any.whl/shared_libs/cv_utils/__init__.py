# OpenCV & Vision utility helpers
