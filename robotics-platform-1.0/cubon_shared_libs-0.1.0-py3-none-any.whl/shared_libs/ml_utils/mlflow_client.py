import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class MLflowClient:
    """
    A simulated MLflow client for experiment tracking across the robot fleet.
    In a production environment, this would wrap the actual 'mlflow' Python package.
    """

    def __init__(self, tracking_uri: Optional[str] = None):
        self.tracking_uri = tracking_uri or "http://localhost:5000"
        self._active_run_id: Optional[str] = None
        logger.info(f"Initialized MLflowClient with tracking URI: {self.tracking_uri}")

    def set_experiment(self, experiment_name: str) -> None:
        """Set the active MLflow experiment."""
        logger.info(f"[MLflow] Setting experiment to '{experiment_name}'")

    def start_run(self, run_name: Optional[str] = None) -> str:
        """Start a new MLflow run."""
        self._active_run_id = "sim-run-id-12345"
        name = run_name or "default_run"
        logger.info(f"[MLflow] Started run '{name}' with ID '{self._active_run_id}'")
        return self._active_run_id

    def end_run(self) -> None:
        """End the active MLflow run."""
        logger.info(f"[MLflow] Ended run '{self._active_run_id}'")
        self._active_run_id = None

    def log_metric(self, key: str, value: float, step: Optional[int] = None) -> None:
        """Log a metric."""
        step_info = f" (step: {step})" if step is not None else ""
        logger.info(f"[MLflow] Logged metric: {key} = {value}{step_info}")

    def log_param(self, key: str, value: Any) -> None:
        """Log a parameter."""
        logger.info(f"[MLflow] Logged param: {key} = {value}")

    def log_metrics(self, metrics: Dict[str, float], step: Optional[int] = None) -> None:
        """Log multiple metrics."""
        for key, value in metrics.items():
            self.log_metric(key, value, step)
