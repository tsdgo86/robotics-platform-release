"""
Dynamic package/package_dir mapping for shared_libs.

This pyproject.toml lives inside the package directory itself (shared_libs/
cv_utils, shared_libs/ml_utils, ... are siblings of this file), instead of
the conventional nested <project-root>/shared_libs/ layout that setuptools/
poetry package discovery assumes. Rather than moving files into a nested
directory, this maps each real subpackage found in "." onto the
"shared_libs.*" import name -- a prefix mapping pyproject.toml's declarative
packages.find cannot express on its own. See robot_base/setup.py for the
same pattern.
"""
from setuptools import setup, find_packages

_subpackages = find_packages(where=".", exclude=["tests", "tests.*"])

setup(
    packages=["shared_libs"] + [f"shared_libs.{name}" for name in _subpackages],
    package_dir={
        "shared_libs": ".",
        **{f"shared_libs.{name}": name.replace(".", "/") for name in _subpackages},
    },
)
