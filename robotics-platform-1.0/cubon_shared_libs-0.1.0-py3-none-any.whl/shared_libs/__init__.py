"""shared_libs: Domain-agnostic shared utility modules."""
__version__ = "0.1.0"
