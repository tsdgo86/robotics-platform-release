import logging
from typing import Dict, Any, List
from robot_base.core.base_event import BaseEvent
from robot_base.core.base_state import BaseState

logger = logging.getLogger(__name__)

class DashboardGateway:
    """
    A unified gateway to aggregate telemetry and status updates from the entire robot fleet.
    """

    def __init__(self):
        self._connected_robots: set[str] = set()
        self._recent_events: List[BaseEvent] = []
        self._latest_states: Dict[str, BaseState] = {}
        logger.info("Initialized DashboardGateway")

    def register_robot(self, robot_id: str) -> None:
        """Register a robot with the dashboard."""
        self._connected_robots.add(robot_id)
        logger.info(f"[Dashboard] Registered robot: {robot_id}")

    def ingest_event(self, event: BaseEvent) -> None:
        """Ingest an event from a robot."""
        if event.robot_id not in self._connected_robots:
            self.register_robot(event.robot_id)
        
        self._recent_events.append(event)
        # Keep only the last 100 events
        if len(self._recent_events) > 100:
            self._recent_events.pop(0)
            
        logger.info(f"[Dashboard] Ingested event {event.event_id} from {event.robot_id} (Type: {event.event_type})")

    def update_state(self, state: BaseState) -> None:
        """Update the current state of a robot."""
        if state.robot_id not in self._connected_robots:
            self.register_robot(state.robot_id)
            
        self._latest_states[state.robot_id] = state
        logger.info(f"[Dashboard] Updated state for {state.robot_id}")

    def get_fleet_status(self) -> Dict[str, Any]:
        """Get the status of all connected robots."""
        return {
            "connected_robots": list(self._connected_robots),
            "total_events": len(self._recent_events),
            "latest_states": {
                robot_id: state.snapshot() for robot_id, state in self._latest_states.items()
            }
        }
