# Trajectory & Math helpers
