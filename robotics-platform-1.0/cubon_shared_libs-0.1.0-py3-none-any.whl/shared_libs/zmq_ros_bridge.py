"""
ZeroMQ Drop-In Replacement for ROS 2 rclpy.
Provides Node, Publisher, Subscription, and standard ROS 2 Messages.
"""
import zmq
import json
import time
import threading
from typing import Any, Callable, Dict, Optional

# ── Mock ROS 2 Messages ────────────────────────────────────────────────────────
class _MsgBase:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)
    
    def to_dict(self):
        d = {}
        for k, v in self.__dict__.items():
            if hasattr(v, 'to_dict'):
                d[k] = v.to_dict()
            else:
                d[k] = v
        return d

    @classmethod
    def from_dict(cls, data):
        obj = cls()
        for k, v in data.items():
            if hasattr(obj, k) and hasattr(getattr(obj, k), 'from_dict'):
                setattr(obj, k, getattr(obj, k).__class__.from_dict(v))
            else:
                setattr(obj, k, v)
        return obj

class Time(_MsgBase):
    def __init__(self, sec=0, nanosec=0):
        self.sec = sec
        self.nanosec = nanosec

class Header(_MsgBase):
    def __init__(self, stamp=None, frame_id=''):
        self.stamp = stamp or Time()
        self.frame_id = frame_id

class String(_MsgBase):
    def __init__(self, data=''):
        self.data = data

class Bool(_MsgBase):
    def __init__(self, data=False):
        self.data = data

class Vector3(_MsgBase):
    def __init__(self, x=0.0, y=0.0, z=0.0):
        self.x = x
        self.y = y
        self.z = z

class Point(_MsgBase):
    def __init__(self, x=0.0, y=0.0, z=0.0):
        self.x = x
        self.y = y
        self.z = z

class Quaternion(_MsgBase):
    def __init__(self, x=0.0, y=0.0, z=0.0, w=1.0):
        self.x = x
        self.y = y
        self.z = z
        self.w = w

class Twist(_MsgBase):
    def __init__(self, linear=None, angular=None):
        self.linear = linear or Vector3()
        self.angular = angular or Vector3()

class Transform(_MsgBase):
    def __init__(self, translation=None, rotation=None):
        self.translation = translation or Vector3()
        self.rotation = rotation or Quaternion()

class TransformStamped(_MsgBase):
    def __init__(self, header=None, child_frame_id='', transform=None):
        self.header = header or Header()
        self.child_frame_id = child_frame_id
        self.transform = transform or Transform()

class PointStamped(_MsgBase):
    def __init__(self, header=None, point=None):
        self.header = header or Header()
        self.point = point or Point()

class JointState(_MsgBase):
    def __init__(self, header=None, name=None, position=None, velocity=None, effort=None):
        self.header = header or Header()
        self.name = name or []
        self.position = position or []
        self.velocity = velocity or []
        self.effort = effort or []

class Imu(_MsgBase):
    def __init__(self, header=None, orientation=None, angular_velocity=None, linear_acceleration=None):
        self.header = header or Header()
        self.orientation = orientation or Quaternion()
        self.angular_velocity = angular_velocity or Vector3()
        self.linear_acceleration = linear_acceleration or Vector3()

# ── Global Context ─────────────────────────────────────────────────────────────
_context = None

def init(args=None):
    global _context
    if _context is None:
        _context = zmq.Context()

def shutdown():
    global _context
    if _context is not None:
        _context.term()
        _context = None

def ok():
    return _context is not None

# ── Mock RCLPY Classes ─────────────────────────────────────────────────────────

class Clock:
    def now(self):
        class _Time:
            def to_msg(self):
                t = time.time()
                return Time(sec=int(t), nanosec=int((t - int(t)) * 1e9))
        return _Time()

class _Logger:
    def __init__(self, name):
        self.name = name
    def info(self, msg):
        print(f"[INFO] [{self.name}]: {msg}")
    def warn(self, msg):
        print(f"[WARN] [{self.name}]: {msg}")
    def error(self, msg):
        print(f"[ERROR] [{self.name}]: {msg}")

class Publisher:
    def __init__(self, socket, topic: str):
        self.socket = socket
        self.topic = topic

    def publish(self, msg: _MsgBase):
        try:
            payload = msg.to_dict()
            message = f"{self.topic} {json.dumps(payload)}"
            self.socket.send_string(message, flags=zmq.NOBLOCK)
        except zmq.Again:
            pass  # No subscriber yet, drop message silently
        except Exception:
            pass

class Subscription:
    def __init__(self, topic: str, msg_type: type, callback: Callable):
        self.topic = topic.lstrip('/')
        self.msg_type = msg_type
        self.callback = callback

# ── Port conventions ───────────────────────────────────────────────────────────
# Two-socket, no-broker design:
#   Animator     : PUB.bind(5555),    SUB.connect(5556)
#   Orchestrator : PUB.bind(5556),    SUB.connect(5555)
#   CmdSender    : PUB.connect(5556)  (commands only, no sub needed)
#
# Each node BINDS its OWN publish port so it starts fine without a peer.
# Peers that connect() will pick up messages whenever they are ready.

class Node:
    def __init__(self, name: str):
        self.name = name
        self.logger = _Logger(name)
        self.clock = Clock()
        self._closed = False
        
        if _context is None:
            init()

        self.pub_socket = _context.socket(zmq.PUB)
        self.sub_socket = _context.socket(zmq.SUB)

        # Drop messages instead of queuing forever (prevents assertion crash)
        self.pub_socket.set_hwm(10)
        self.sub_socket.set_hwm(10)

        # Close immediately without waiting to flush pending messages
        self.pub_socket.setsockopt(zmq.LINGER, 0)
        self.sub_socket.setsockopt(zmq.LINGER, 0)

        _name = name.lower()
        if 'animator' in _name:
            self.pub_socket.bind("tcp://127.0.0.1:5555")
            self.sub_socket.connect("tcp://127.0.0.1:5556")
        elif 'cmd_sender' in _name:
            # Command-only sender: connect to Orchestrator PUB port
            self.pub_socket.connect("tcp://127.0.0.1:5556")
            # No subscriptions needed
        else:
            # Orchestrator / bridge: bind command port, listen to animator
            self.pub_socket.bind("tcp://127.0.0.1:5556")
            self.sub_socket.connect("tcp://127.0.0.1:5555")

        # Let ZMQ establish connections before first send (Pub/Sub is async)
        time.sleep(0.5)

        self.subscriptions = []
        self._timers = []

    def get_logger(self):
        return self.logger
        
    def get_clock(self):
        return self.clock

    def create_publisher(self, msg_type, topic: str, qos=10):
        topic = topic.lstrip('/')
        return Publisher(self.pub_socket, topic)

    def create_subscription(self, msg_type, topic: str, callback: Callable, qos=10):
        topic = topic.lstrip('/')
        self.sub_socket.setsockopt_string(zmq.SUBSCRIBE, topic)
        sub = Subscription(topic, msg_type, callback)
        self.subscriptions.append(sub)
        return sub

    def create_timer(self, period: float, callback: Callable):
        timer = {'period': period, 'callback': callback, 'last_run': time.time()}
        self._timers.append(timer)
        return timer

    def destroy_node(self):
        if not self._closed:
            self._closed = True
            self.pub_socket.close()
            self.sub_socket.close()


def spin_once(node: Node, timeout_sec: float = 0.1):
    if node._closed:
        return

    # Run timers
    now = time.time()
    for timer in node._timers:
        if now - timer['last_run'] >= timer['period']:
            timer['callback']()
            timer['last_run'] = now

    # Process subscriptions
    if not node.subscriptions:
        time.sleep(timeout_sec)
        return

    try:
        events = node.sub_socket.poll(timeout=int(timeout_sec * 1000))
        if events:
            message = node.sub_socket.recv_string(flags=zmq.NOBLOCK)
            parts = message.split(' ', 1)
            if len(parts) == 2:
                topic, payload_str = parts
                payload = json.loads(payload_str)
                for sub in node.subscriptions:
                    if sub.topic == topic:
                        msg_obj = sub.msg_type.from_dict(payload)
                        sub.callback(msg_obj)
    except zmq.Again:
        pass
    except zmq.ZMQError:
        pass  # Socket closed during shutdown
    except Exception as e:
        if not node._closed:
            node.get_logger().error(f"Error in spin_once: {e}")

def spin(node: Node):
    while ok():
        spin_once(node)
